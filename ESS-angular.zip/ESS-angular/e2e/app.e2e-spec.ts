import { FristappPage } from './app.po';

describe('fristapp App', () => {
  let page: FristappPage;

  beforeEach(() => {
    page = new FristappPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
