
/**
 * <h1>app-config.ts</h1>
 * @author Gobinath J
 */

export class AppConfiguration {

      public static get apiBaseUrl(): string { return 'http://172.17.0.193:8080'; }

}