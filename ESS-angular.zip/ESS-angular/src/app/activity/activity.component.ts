import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>project.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Activity-Master',
  templateUrl: './activity.component.html',
  styleUrls:  ['../activity/activity.component.css']
})

export   class   ActivityMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    public activites;
    private settings;
    private activityName = '';
    private status = '';

    constructor(toasterService: ToasterService,private  loginService: LoginService, private commonService: CommonService,private auth : AuthGuard) {
        this.toasterService = toasterService;    
    }
    
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {

      this.settings = {
      mode: 'inline',
      actions: {
        add: true,
        edit:true,
        delete:false,
        //position: 'right'
        },
      pager : {
        display : true,
        perPage:10
      },
      edit: {
        confirmSave: true,
        editButtonContent: '<span class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>',
        saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      add: {
        confirmCreate: true,
        addButtonContent: '<span class="btn btn-sm btn-primary">Add</span>',
        createButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      columns: {
        idmaster:{
          title: 'Id',
          filter: false,
          show: false,
        },
        name: {
          title: 'Activity Name',
          filter: false,
        },
        description: {
          title: 'Description',
          filter: false
        },
        activeStatus: {
          title: 'Status',
          filter: false,
        editor: {
          type: 'list',
          config: {
            list: [{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }],
          },
        },
        }
      }
    };

      let requrl= this.apiBaseUrl+'/ESS/api/Master/getActivitiesList/';
      let designationDetails = this.commonService.commonGetCall(requrl);
      designationDetails.subscribe((data) => {
          this.activites = data.json();
      },
      (error)=>{
              this.auth.canActivate();
              let dashboardDetails1 = this.commonService.commonGetCall(requrl);
              dashboardDetails1.subscribe((data) => {
                this.activites = data.json();
              },
              (error)=>{
                  console.log("error");
                 
              });
      });
    }

    onCreateConfirm(event): void {
        console.log("==>>>",event);
        let name = event.newData.name;
        let description = event.newData.description;
        let status = event.newData.activeStatus;
        if(name == '' || description == ''|| status == ''){
          this.toasterService.pop('error', 'Fields Should not be empty');
        }else{

          let createdData = {
            "name": name,
            "description": description,
            "activeStatus": status
          }
           console.log("==>>>",createdData);
          let requrl= this.apiBaseUrl+'/ESS/api/Master/saveActivity/';
          let activity = this.commonService.commonPostCall(requrl,createdData);
          let checkName;
          activity.subscribe((data) => {
            checkName=data._body ;
              if(checkName=='Failure'){
                  this.toasterService.pop('error', 'Activity Name already present'); 
                  
              }
                else{
                    this.toasterService.pop('success', 'Saved Successfully'); 
                }
          },
          (error)=>{
                   this.auth.canActivate();
                  activity = this.commonService.commonPostCall(requrl,createdData);
                  activity.subscribe((data) => {
                    checkName=data._body ;
                    if(checkName=='Failure'){
                        this.toasterService.pop('error', 'Activity Name already present'); 
                      
                    }
                      else{
                          this.toasterService.pop('success', 'Saved Successfully'); 
                            this.ngOnInit();
                      }
                  },
                  (error)=>{
                      console.log("error");
                       
                  });
          });
        }
    }

    onEditConfirm(event): void {
      let idmaster = event.newData.idmaster;
      let name = event.newData.name;
      let description = event.newData.description;
      let status = event.newData.activeStatus;
      if(name == '' || description == ''|| status == ''){
        this.toasterService.pop('error', 'Fields Should not be empty');
      }else{
        let editedData = {
          "idmaster":idmaster,
          "name": name,
          "description": description,
          "activeStatus": status
        }
        let requrl= this.apiBaseUrl+'/ESS/api/Master/updateActivity/';
        let designation = this.commonService.commonPostCall(requrl,editedData);
        designation.subscribe((data) => {
          this.ngOnInit();
          this.toasterService.pop('success', 'Saved Successfully');
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,editedData);
                designation.subscribe((data) => {
                  this.ngOnInit();
                  this.toasterService.pop('success', 'Saved Successfully');  
                },
                (error)=>{
                    console.log("error");
                });
        });
      }
    }

    searchActivity(): void{
      let searchData = {
        "name":this.activityName,
        "activeStatus": this.status
      }
      let requrl= this.apiBaseUrl+'/ESS/api/Master/searchActivity/';
      let designation = this.commonService.commonPostCall(requrl,searchData);
      designation.subscribe((data) => {
        this.activites = data.json();
      },
      (error)=>{
               this.auth.canActivate();
              designation = this.commonService.commonPostCall(requrl,searchData);
            designation.subscribe((data) => {
                this.activites = data.json();
              },
              (error)=>{
                    console.log("error");
              });
      });
    }

    reset(): void{
      this.activityName = '';
      this.status = '';
      this.searchActivity();
    }
}