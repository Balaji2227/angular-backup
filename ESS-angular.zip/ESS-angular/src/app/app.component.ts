import { Component, OnInit, Input } from '@angular/core';
import { RouterModule,Router } from '@angular/router';
import {Observable} from 'rxjs/Rx';
import { trigger, state, style, transition, animate} from '@angular/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginService, User } from  './login/login.service';

/**
 * <h1>app.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('slideInOut', [
      state('in', style({
        transform: 'translate3d(0, 0, 0)'
      })),
      state('out', style({
        transform: 'translate3d(100%, 0, 0)'
      })),
      transition('in => out', animate('400ms ease-in-out')),
      transition('out => in', animate('400ms ease-in-out'))
    ]),
  ]
})
export class AppComponent {
  title = 'ESS Application';
  public isLoggedIn;
  clock:any;
  role:any;
  public menuState:string = 'out'; 
  constructor(private router: Router, private loginService:LoginService) { }
  ngOnInit() {
    this.clock = Observable
        .interval(1000)
        .map(()=> new Date());

    if (this.loginService.checkCredentials()) {
        this.isLoggedIn = true;
        this.router.navigate(['/dashboard']);
    }else {
        this.isLoggedIn = false;
    }
  }
  logout(){
    this.loginService.logout();
    this.isLoggedIn = false;
  }

  toggleMenu() {
    this.menuState = this.menuState === 'out' ? 'in' : 'out';
  }
  
}
