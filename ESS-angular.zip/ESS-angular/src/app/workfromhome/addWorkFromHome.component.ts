import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { IMyDpOptions,IMyOptions,IMyDateModel} from "mydatepicker";
import {SelectModule,SelectItem } from 'ng2-select';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>onsiteList.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'AddWorkFromHome-Master',
  templateUrl: './addWorkFromHome.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   AddWorkFromHome  {
    
     startDat1:number;EndDat1:number;public NewDays:number;days:any;noofdays:number;hours:number;
      private dropdownList;private employeeId;private projects;public employee;private employees=[];
      public projectList;public projectName;public projectId;public countryList;public countryName;public countryId;
      private items=[]; private selected; private SelectItem;private employeeName:any;private applyLeaveFromDate;private applyLeaveToDate;private reason;
     apiBaseUrl = AppConfiguration.apiBaseUrl;
     private category: Array<any> = []
     addworkfromhome:any={hours:'',reason:'',fromDate:'',toDate:''}
    disabled: boolean = true;
    onStartDateChanged(event: IMyDateModel) {
        let d: Date = new Date(event.jsdate.getTime());
        let s = new Date(event.jsdate.getTime()).valueOf();
        this.startDat1 =s;

        // set previous of selected date
        d.setDate(d.getDate() - 1);
        
        // Get new copy of options in order the date picker detect change
        let copy: IMyOptions = this.getCopyOfEndDateOptions();
        copy.disableUntil = {year: d.getFullYear(), 
                            month: d.getMonth() + 1, 
                            day: d.getDate()};
        this.myToDatePickerOptions = copy;
        this.disabled = false;
        this.addworkfromhome.toDate = '';
    }
    onEndDateChanged(event: IMyDateModel) {
        let d:number= new Date(event.jsdate.getTime()).valueOf();
        this.EndDat1=d;
        this.dis();
    }
    getCopyOfEndDateOptions(): IMyOptions {
        return JSON.parse(JSON.stringify(this.myToDatePickerOptions));
    }
    dis()
    {
        this.days = ( this.EndDat1 - this.startDat1) / (1000 * 60 * 60 * 24);
        this.NewDays=  this.days+1; 
        this.noofdays= this.NewDays;
    }

    constructor(private router: Router, private app: AppComponent,
        private  loginService: LoginService, private commonService: CommonService,private auth : AuthGuard) { }

    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };
    public myToDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };
       
      ngOnInit() {
         let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employee=data.json();
           if(this.employee){
          for(let i=0; i<this.employee.length; i++){
              
            this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});   
            }
           }
             
         },
        (error)=>{
                 this.auth.canActivate();
                let empName1 = this.commonService.commonGetCall(requrlEmp);
                empName1.subscribe((data) => {
                this.employee=data.json();
                if(this.employee){
                 for(let i=0; i<this.employee.length; i++){
                    this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName});   
                     }
                 }
                },
                (error)=>{
                     console.log("error");
                });
          
        })

      }
       test(event){
            this.employeeName=event.id;
       }
     
      saveWorkFromHome() 
      { 
        this.employeeId=this.employeeName;
        let newFromDate=this.addworkfromhome.fromDate.date.month+"/"+this.addworkfromhome.fromDate.date.day+"/"+this.addworkfromhome.fromDate.date.year;
        let newToDate=this.addworkfromhome.toDate.date.month+"/"+this.addworkfromhome.toDate.date.day+"/"+this.addworkfromhome.toDate.date.year;
        let workfromhomedays = this.noofdays ;
        let workfromhomeReason = this.addworkfromhome.reason;
        let workfromhomeRequest = {
            "empId":this.employeeId,
            "timeIn":new Date(newFromDate).getTime(),
            "timeOut":new Date(newToDate).getTime(),
            "hoursWorked":this.addworkfromhome.hours,
            "remarks":this.addworkfromhome.reason
        }
       
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/addWorkFromHomeDetails/';
        let workFromHomeData = this.commonService.commonPostCall(requrl,workfromhomeRequest);
        workFromHomeData.subscribe((data) => {
             this.router.navigate(['/workfromhomeList',{flag:1}]);
        },
        (error)=>{
                this.auth.canActivate();

                workFromHomeData = this.commonService.commonPostCall(requrl,workfromhomeRequest);
                workFromHomeData.subscribe((data) => {
                     this.router.navigate(['/workfromhomeList',{flag:1}]);
                },
                (error)=>{
                    console.log("error");
                });
        }); 
        
            
      }

}
