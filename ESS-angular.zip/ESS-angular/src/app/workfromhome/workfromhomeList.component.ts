import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { IMyDpOptions,IMyOptions,IMyDateModel} from "mydatepicker";
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { ActivatedRoute } from '@angular/router';

/**
 * <h1>onsiteList.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'workfromhomeList-Master',
  templateUrl: './workfromhomeList.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   WorkFromHomeList  {
  apiBaseUrl = AppConfiguration.apiBaseUrl;
   empId = ''; empName = ''; country = ''; private searchFromDate; private searchToDate; project = '';  supervisor = '';searchBySupervisor = ''; status='';
    showDialog = false;public ViewWorkfromhomeDetail;public ViewWorkfromhomeDetail1;private employeeList;public countryList;private bySupervisorList;
   viewEmpId = ''; viewEmpName = ''; viewSupervisor = ''; viewFromDate:any; viewToDate:any; viewTotalDays:any;viewHoursWorked:any;private sub: any; id: number;
   viewCountry = ''; viewReason = ''; viewProject = ''; viewStatus = '';private dropdownList;private supervisors; private designations;
  constructor(private _router: Router,private  loginService: LoginService,private app: AppComponent,private route: ActivatedRoute,
    private commonService: CommonService,private excelService: ExcelService,toasterService: ToasterService,private auth : AuthGuard) { 
          this.excelService = excelService;
           this.toasterService = toasterService; 
  }
  private workfromhomeList;private settings;
   private toasterService: ToasterService;

    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
        this.id = +params['flag']; 
    });
    if(this.app.role == 'ROLE_ADMIN')
    {
    this.settings = {
      mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                     {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
  
      
      columns: {

        empId: {
          title: 'Emp Id',
          filter: false,
          editable:false
        },
        empName: {
          title: 'Emp Name',
          filter: false,
          editable:false
        },
        supervisor: {
          title: 'Supervisor',
          filter: false,
          editable:false
        },
         timeIn: {
              title: 'From Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            timeOut: {
              title: 'To Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            days: {
              title: 'Total Days',
              filter: false
            },
              hoursWorked: {
              title: 'Hours Worked',
              filter: false
            },
            attendanceStatus: {
              title: 'Status',
              filter: false
            },
      
      }
    };
    }
  else{
    this.settings = {
      mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                     {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
  
      
      columns: {

        empId: {
          title: 'Emp Id',
          filter: false,
          editable:false
        },
        empName: {
          title: 'Emp Name',
          filter: false,
          editable:false
        },
        timeIn: {
              title: 'From Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            timeOut: {
              title: 'To Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            days: {
              title: 'Total Days',
              filter: false
            },
              hoursWorked: {
              title: 'Hours Worked',
              filter: false
            },
            attendanceStatus: {
              title: 'Status',
              filter: false
            },
      
      }
    };
  }

    

  let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getAllWorkFromHomeDetails/';
        let workFromHomeDetails = this.commonService.commonGetCall(requrl);
        workFromHomeDetails.subscribe((data) => {
            this.workfromhomeList = data.json();
             if(this.id == 2){
                this.toasterService.pop('success', 'Work from home request updated successfully'); 
            }
            if(this.id == 1){
                this.toasterService.pop('success', 'Work from home request created successfully');
            }
           this.id = 0; 
        },
        (error)=>{
                this.auth.canActivate();
                let workFromHomeDetails1 = this.commonService.commonGetCall(requrl);
                workFromHomeDetails1.subscribe((data) => {
                this.workfromhomeList = data.json();
                },
                (error)=>{
                     console.log("error");
                });
        });


        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
            this.supervisors = this.dropdownList.empDet;
            this.designations = this.dropdownList.designation;
        });

          /* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })

        
  }

   searchEmployee(){ 
       
        let fromDateInTime ;
        let toDateInTime;

        if(this.searchFromDate){
        let fromDateFormat=this.searchFromDate.date.year+"/"+this.searchFromDate.date.month+"/"+this.searchFromDate.date.day;
          fromDateInTime=new Date(fromDateFormat).getTime();
        }
        
        if(this.searchToDate){
          let toDateFormat=this.searchToDate.date.year+"/"+this.searchToDate.date.month+"/"+this.searchToDate.date.day;
          toDateInTime = new Date(toDateFormat).getTime();
        }
        
        if(!this.empId){
          this.empId="";
        }
        if(!this.empName){
          this.empName="";
        }
        if(!this.status){
          this.status="";
        }
        if(!this.searchBySupervisor){
          this.searchBySupervisor="";
        }
        let searchData = {
            "empId":this.empId,
            "empName": this.empName,
            "timeIn":fromDateInTime,
            "timeOut": toDateInTime,
            "attendanceStatus": this.status,
            "supervisorEmpIds":this.searchBySupervisor
        }
          console.log("searchData==>>",searchData)
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/WorkfromhomeDetailsSearch/';
        let detail = this.commonService.commonPostCall(requrl,searchData);
        detail.subscribe((data) => {
            this.workfromhomeList = data.json();
        },
        (error)=>{
                this.auth.canActivate();
                detail = this.commonService.commonPostCall(requrl,searchData);
                detail.subscribe((data) => {
                    this.workfromhomeList = data.json();
                },
                (error)=>{
                      console.log("error");
                  
                });
           
        });
    }

    reset(){
        this.empId = ''; this.empName = ''; this.country = ''; this.searchFromDate = ''; this.searchToDate = ''; 
        this.status = ''; this.supervisor = '';this.searchBySupervisor = '';
        this.ngOnInit();
    }

   customAction(event): void{
        let action = event.action;
        let transId = event.data.transId;
        this.showDialog = true;
        if(action == 'view')
          {
            let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getWorkfromhomeDetailsById/'+transId;
            let workfromhomeDetails = this.commonService.commonGetCall(requrl);
            workfromhomeDetails.subscribe((data) => {
                this.ViewWorkfromhomeDetail = data.json();
                this.viewEmpId = this.ViewWorkfromhomeDetail.empId; this.viewEmpName = this.ViewWorkfromhomeDetail.empName; 
                this.viewSupervisor = this.ViewWorkfromhomeDetail.supervisor; 
                this.viewReason = this.ViewWorkfromhomeDetail.remarks; 
                this.viewStatus = this.ViewWorkfromhomeDetail.attendanceStatus;this.viewTotalDays = this.ViewWorkfromhomeDetail.days
                this.viewHoursWorked = this.ViewWorkfromhomeDetail.hoursWorked;
                let parsedFromDate = new Date(this.ViewWorkfromhomeDetail.timeIn);
                var month = parsedFromDate.getMonth() + 1;
	              var date = parsedFromDate.getDate();
                this.viewFromDate = (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedFromDate.getFullYear();
                let parsedToDate = new Date(this.ViewWorkfromhomeDetail.timeOut);
                var toMonth = parsedToDate.getMonth() + 1;
	              var toDate = parsedToDate.getDate();
                this.viewToDate = (toDate < 10 ? '0' + toDate : toDate)+"/"+( toMonth < 10 ? '0' + toMonth : toMonth)+"/"+parsedToDate.getFullYear();
          },
           (error)=>{
                      this.auth.canActivate();
                    let workfromhomeDetails1 = this.commonService.commonGetCall(requrl);
                    workfromhomeDetails1.subscribe((data) => {
                    this.ViewWorkfromhomeDetail1 = data.json();
                    this.ViewWorkfromhomeDetail1 = data.json();
                    this.viewEmpId = this.ViewWorkfromhomeDetail1.empId; this.viewEmpName = this.ViewWorkfromhomeDetail1.empName; 
                    this.viewSupervisor = this.ViewWorkfromhomeDetail1.supervisor;
                    this.viewReason = this.ViewWorkfromhomeDetail1.remarks; 
                    this.viewStatus = this.ViewWorkfromhomeDetail1.status;this.viewTotalDays = this.ViewWorkfromhomeDetail1.days
                    this.viewHoursWorked = this.ViewWorkfromhomeDetail1.hoursWorked;
                    let parsedFromDate = new Date(this.ViewWorkfromhomeDetail1.timeIn);
                    var month = parsedFromDate.getMonth() + 1;
                    var date = parsedFromDate.getDate();
                    this.viewFromDate = (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedFromDate.getFullYear();
                    let parsedToDate = new Date(this.ViewWorkfromhomeDetail1.timeOut);
                    var toMonth = parsedToDate.getMonth() + 1;
                    var toDate = parsedToDate.getDate();
                    this.viewToDate = (toDate < 10 ? '0' + toDate : toDate)+"/"+( toMonth < 10 ? '0' + toMonth : toMonth)+"/"+parsedToDate.getFullYear();
                    },
                     (error)=>{
                        console.log("error");
                    });
            });
            this.showDialog = true;
        }
        else{
            this._router.navigate(['/editWorkfromhome', transId]);
        }
    }

   

}
