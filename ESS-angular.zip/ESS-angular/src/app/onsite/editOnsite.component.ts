import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { IMyDpOptions,IMyOptions,IMyDateModel} from "mydatepicker";
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';


/**
 * <h1>editOnsite.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'EditOnsite-Master',
  templateUrl: './editOnsite.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   EditOnsiteMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;private employeeList;private transId;private projectList;private toasterService: ToasterService;
    private noofdays; private NewDays; private countryList; private startDat1;private startDate; private EndDat1;private days;
    private ViewOnsiteDetail; private ViewOnsiteDetail1;viewEmpId = ''; viewEmpName = ''; viewSupervisor = ''; viewFromDate:any; viewToDate:any; viewTotalDays:any;
    viewCountry = ''; viewReason = ''; viewProject = ''; viewStatus = ''
    EditOnsiteDet:any = {empName: '', viewFromDate:'', viewToDate:'', days:'', country:'', remarks:'',
        project:'',countryID:'',idmaster:'' };
    
    public myToDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };
   
    
    constructor(private router: Router,private activatedRoute: ActivatedRoute, private app: AppComponent,
        private  loginService: LoginService, private commonService: CommonService, toasterService: ToasterService,private auth : AuthGuard) {
            this.toasterService = toasterService; 
         }

    onStartDateChanged(event: IMyDateModel) {
        let d: Date = new Date(event.jsdate.getTime());

        let s = new Date(event.jsdate.getTime()).valueOf();
        this.startDat1 =s;

        // set previous of selected date
        d.setDate(d.getDate() - 1);
        
        // Get new copy of options in order the date picker detect change
        let copy: IMyOptions = this.getCopyOfEndDateOptions();
        copy.disableUntil = {year: d.getFullYear(), 
                            month: d.getMonth() + 1, 
                            day: d.getDate()};
        this.myToDatePickerOptions = copy;
      
       
    }
    onEndDateChanged(event: IMyDateModel) {
        let d:number= new Date(event.jsdate.getTime()).valueOf();
        this.EndDat1=d;
        this.dis();
    }
     getCopyOfEndDateOptions(): IMyOptions {
        return JSON.parse(JSON.stringify(this.myToDatePickerOptions));
    }
    dis()
    {   let newFromDate=this.viewFromDate.date.month+"/"+this.viewFromDate.date.day+"/"+this.viewFromDate.date.year;
        this.startDate =  new Date(newFromDate).getTime();
        this.days = ( this.EndDat1 - this.startDate) / (1000 * 60 * 60 * 24);
        this.NewDays=  this.days+1; 
        this.noofdays= this.NewDays;
    }

    ngOnInit() {

       
        let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employeeList=data.json();
        },
        (error)=>{
                this.auth.canActivate();
                let empName1 = this.commonService.commonGetCall(requrlEmp);
                empName1.subscribe((data) => {
                 this.employeeList=data.json();
                },
                (error)=>{
                    console.log("error");  
                });
        })

        let requrlproject= this.apiBaseUrl+'/ESS/api/Master/getActiveProjectList/';
        let projectDetails = this.commonService.commonGetCall(requrlproject);
        var myData = [];
        let map = new Map();
        projectDetails.subscribe((data) => {
            this.projectList = data.json();  
        },
        (error)=>{
                this.auth.canActivate();
                let dashboardDetails1 = this.commonService.commonGetCall(requrl);
                dashboardDetails1.subscribe((data) => {
                  this.projectList = data.json();
                },
                (error)=>{
                     console.log("error");  
                });
         });

        let requrlcountry= this.apiBaseUrl+'/ESS/api/Master/getCountryList/';
        let countryDetails = this.commonService.commonGetCall(requrlcountry);
        countryDetails.subscribe((data) => {
            this.countryList = data.json()
        },
        (error)=>{
                 this.auth.canActivate();
                let countryDetails1 = this.commonService.commonGetCall(requrl);
                countryDetails1.subscribe((data) => {
                this.countryList = data.json();
                },
                (error)=>{
                     console.log("error");  
                });
        });

        this.activatedRoute.params.subscribe((params: Params) => {
       this.transId = params['transId'];
        });
       let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getOnsiteDetailsById/'+this.transId;
            let onsiteDetails = this.commonService.commonGetCall(requrl);
            onsiteDetails.subscribe((data) => {
                this.EditOnsiteDet = data.json();
                let responsevalue = data.json();
                let dobFromDate = new Date(responsevalue.timeIn);
                this.viewFromDate = { date: { year: dobFromDate.getFullYear(), month: dobFromDate.getMonth()+1, day: dobFromDate.getDate() } };
                 let dobToDate = new Date(responsevalue.timeOut);
                this.viewToDate = { date: { year: dobToDate.getFullYear(), month: dobToDate.getMonth()+1, day: dobToDate.getDate() } };
                this.noofdays = this.EditOnsiteDet.days;
          },
        (error)=>{
                this.auth.canActivate();
                let employeeDetails1 = this.commonService.commonGetCall(requrl);
                employeeDetails1.subscribe((data) => {
                this.EditOnsiteDet = data.json();
                },
                (error)=>{
                     console.log("error");  
                });
           
        });
      
    }
  
    
     saveOnsiteRequest(){

        let newFromDate=this.viewFromDate.date.month+"/"+this.viewFromDate.date.day+"/"+this.viewFromDate.date.year;
        this.EditOnsiteDet.timeIn =  new Date(newFromDate).getTime();
        let newToDate=this.viewToDate.date.month+"/"+this.viewToDate.date.day+"/"+this.viewToDate.date.year;
        this.EditOnsiteDet.timeOut =  new Date(newToDate).getTime();
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/updateOnsiteDetails/';
        console.log("EditOnsiteDet",this.EditOnsiteDet)
        let editdata = this.commonService.commonPostCall(requrl,this.EditOnsiteDet);
        editdata.subscribe((data) => { 
         this.router.navigate(['/onsiteList',{flag:2}]);
        },
        (error)=>{
                this.auth.canActivate();
                editdata = this.commonService.commonPostCall(requrl,this.EditOnsiteDet);
                editdata.subscribe((data) => {
                    this.router.navigate(['/onsiteList',{flag:2}]);
                },
                (error)=>{
                    console.log("error");  
                });
            
        });
    }
    
  

}
