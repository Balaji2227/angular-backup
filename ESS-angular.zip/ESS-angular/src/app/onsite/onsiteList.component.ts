import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { ActivatedRoute } from '@angular/router';
/**
 * <h1>onsiteList.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'OnsiteList-Master',
  templateUrl: './onsiteList.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   OnsiteList  {
  apiBaseUrl = AppConfiguration.apiBaseUrl;
   empId = ''; empName = ''; country = ''; private searchFromDate; private searchToDate; project = '';  supervisor = '';searchBySupervisor = ''; status='';
    showDialog = false;public ViewOnsiteDetail;public ViewOnsiteDetail1;private employeeList;public countryList;private bySupervisorList;
   viewEmpId = ''; viewEmpName = ''; viewSupervisor = ''; viewFromDate:any; viewToDate:any; viewTotalDays:any; private sub: any; id: number;
   viewCountry = ''; viewReason = ''; viewProject = ''; viewStatus = '';private dropdownList;private supervisors; private designations;
  constructor(private _router: Router,private  loginService: LoginService,private app: AppComponent,private route: ActivatedRoute,
    private commonService: CommonService,private excelService: ExcelService,toasterService: ToasterService,private auth : AuthGuard) { 
          this.excelService = excelService;
          this.toasterService = toasterService; 
  }
  private onsiteList;private settings;
  private toasterService: ToasterService;
  public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
  };
 

  ngOnInit() {
      this.sub = this.route.params.subscribe(params => {
        this.id = +params['flag']; 
      });
     if(this.app.role == 'ROLE_ADMIN')
      {
    this.settings = {
      mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                    {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
  
      
      columns: {

        empId: {
          title: 'Emp Id',
          filter: false,
          editable:false
        },
        empName: {
          title: 'Emp Name',
          filter: false,
          editable:false
        },
        supervisor: {
          title: 'Supervisor',
          filter: false,
          editable:false
        },
          timeIn: {
              title: 'From Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            timeOut: {
              title: 'To Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            days: {
              title: 'Total Days',
              filter: false
            },
            attendanceStatus: {
              title: 'Status',
              filter: false
            },
            country: {
              title: 'Country',
              filter: false
            }

       
      
      }
    };
    }
  else{
    this.settings = {
      mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                    {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
  
      
      columns: {

        empId: {
          title: 'Emp Id',
          filter: false,
          editable:false
        },
        empName: {
          title: 'Emp Name',
          filter: false,
          editable:false
        },
        timeIn: {
              title: 'From Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            timeOut: {
              title: 'To Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            days: {
              title: 'Total Days',
              filter: false
            },
            attendanceStatus: {
              title: 'Status',
              filter: false
            },
            country: {
              title: 'Country',
              filter: false
            }
      
      }
    };

  }

    

  let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getAllOnsiteDetails/';
        let employeeDetails = this.commonService.commonGetCall(requrl);
        employeeDetails.subscribe((data) => {
            this.onsiteList = data.json();
             if(this.id == 2){
                this.toasterService.pop('success', 'Onsite request updated successfully'); 
            }
            if(this.id == 1){
                this.toasterService.pop('success', 'Onsite request created successfully');
            }
           this.id = 0; 
        },
        (error)=>{
                this.auth.canActivate();
                let employeeDetails1 = this.commonService.commonGetCall(requrl);
                employeeDetails1.subscribe((data) => {
                this.onsiteList = data.json();
                },
                (error)=>{
                    console.log("error");
                });
        });

        let requrlcountry= this.apiBaseUrl+'/ESS/api/Master/getCountryList/';
        let countryDetails = this.commonService.commonGetCall(requrlcountry);
        countryDetails.subscribe((data) => {
            this.countryList = data.json()
        },
        (error)=>{
                this.auth.canActivate();
                let countryDetails1 = this.commonService.commonGetCall(requrl);
                countryDetails1.subscribe((data) => {
                this.countryList = data.json();
                },
                (error)=>{
                this.loginService.logout();
                });
        });

        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
            this.supervisors = this.dropdownList.empDet;
            this.designations = this.dropdownList.designation;
        });

         /* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })
    

        
  }

   searchEmployee(){ 
       
        let fromDateInTime ;
        let toDateInTime;

        if(this.searchFromDate){
        let fromDateFormat=this.searchFromDate.date.year+"/"+this.searchFromDate.date.month+"/"+this.searchFromDate.date.day;
          fromDateInTime=new Date(fromDateFormat).getTime();
        }
        
        if(this.searchToDate){
          let toDateFormat=this.searchToDate.date.year+"/"+this.searchToDate.date.month+"/"+this.searchToDate.date.day;
          toDateInTime = new Date(toDateFormat).getTime();
        }
        
        if(!this.empId){
          this.empId="";
        }
        if(!this.empName){
          this.empName="";
        }
        if(!this.country){
          this.country="";
        }
        if(!this.status){
          this.status="";
        }
        if(!this.searchBySupervisor){
          this.searchBySupervisor="";
        }
        let searchData = {
            "empId":this.empId,
            "empName": this.empName,
            "country":this.country,
            "timeIn":fromDateInTime,
            "timeOut": toDateInTime,
            "attendanceStatus": this.status,
            "supervisorEmpIds":this.searchBySupervisor
        }
          console.log("searchData==>>",searchData)
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/OnsiteDetailsSearch/';
        let designation = this.commonService.commonPostCall(requrl,searchData);
        designation.subscribe((data) => {
            this.onsiteList = data.json();
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,searchData);
                designation.subscribe((data) => {
                    this.onsiteList = data.json();
                },
                (error)=>{
                  
                });
        });
    }

    reset(){
        this.empId = ''; this.empName = ''; this.country = ''; this.searchFromDate = ''; this.searchToDate = ''; 
        this.status = ''; this.searchBySupervisor = '';
        this.ngOnInit();
    }

   customAction(event): void{
        let action = event.action;
        let transId = event.data.transId;
        this.showDialog = true;
        if(action == 'view')
          {
            let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getOnsiteDetailsById/'+transId;
            let onsiteDetails = this.commonService.commonGetCall(requrl);
            onsiteDetails.subscribe((data) => {
                this.ViewOnsiteDetail = data.json();
                this.viewEmpId = this.ViewOnsiteDetail.empId; this.viewEmpName = this.ViewOnsiteDetail.empName; 
                this.viewSupervisor = this.ViewOnsiteDetail.supervisor; this.viewProject = this.ViewOnsiteDetail.project;
                this.viewCountry = this.ViewOnsiteDetail.country;this.viewReason = this.ViewOnsiteDetail.remarks; 
                this.viewStatus = this.ViewOnsiteDetail.attendanceStatus;this.viewTotalDays = this.ViewOnsiteDetail.days
                let parsedFromDate = new Date(this.ViewOnsiteDetail.timeIn);
                var month = parsedFromDate.getMonth() + 1;
	              var date = parsedFromDate.getDate();
                this.viewFromDate = (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedFromDate.getFullYear();
                let parsedToDate = new Date(this.ViewOnsiteDetail.timeOut);
                var toMonth = parsedToDate.getMonth() + 1;
	              var toDate = parsedToDate.getDate();
                this.viewToDate = (toDate < 10 ? '0' + toDate : toDate)+"/"+( toMonth < 10 ? '0' + toMonth : toMonth)+"/"+parsedToDate.getFullYear();
          },
           (error)=>{
                    this.auth.canActivate();
                    let onsiteDetails1 = this.commonService.commonGetCall(requrl);
                    onsiteDetails1.subscribe((data) => {
                    this.ViewOnsiteDetail1 = data.json();
                    this.ViewOnsiteDetail1 = data.json();
                    this.viewEmpId = this.ViewOnsiteDetail1.empId; this.viewEmpName = this.ViewOnsiteDetail1.empName; 
                    this.viewSupervisor = this.ViewOnsiteDetail1.supervisor; this.viewProject = this.ViewOnsiteDetail1.project;
                    this.viewCountry = this.ViewOnsiteDetail1.country;this.viewReason = this.ViewOnsiteDetail1.remarks; 
                    this.viewStatus = this.ViewOnsiteDetail1.status;this.viewTotalDays = this.ViewOnsiteDetail1.days
                   let parsedFromDate = new Date(this.ViewOnsiteDetail1.timeIn);
                    var month = parsedFromDate.getMonth() + 1;
                    var date = parsedFromDate.getDate();
                    this.viewFromDate = (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedFromDate.getFullYear();
                    let parsedToDate = new Date(this.ViewOnsiteDetail1.timeOut);
                    var toMonth = parsedToDate.getMonth() + 1;
                    var toDate = parsedToDate.getDate();
                    this.viewToDate = (toDate < 10 ? '0' + toDate : toDate)+"/"+( toMonth < 10 ? '0' + toMonth : toMonth)+"/"+parsedToDate.getFullYear();
                    },
                     (error)=>{
                       
                    });
            });
            this.showDialog = true;
        }
        else{
            this._router.navigate(['/editOnsite', transId]);
        }
    }

   

}
