import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { IMyDpOptions,IMyOptions,IMyDateModel} from "mydatepicker";

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>onsiteList.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'AddOnsite-Master',
  templateUrl: './addOnsite.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   AddOnsiteMaster  {
    
     startDat1:number;EndDat1:number;public NewDays:number;days:any;noofdays:number;
      private dropdownList;private employeeId;private projects;private employee;private employees;
      public projectList;public projectName;public projectId;public countryList;public countryName;public countryId;
     apiBaseUrl = AppConfiguration.apiBaseUrl;
     private category: Array<any> = []
     addonsite:any={projectId:'',reason:'',fromDate:'',countryId:'',toDate:''}
    disabled: boolean = true;
    onStartDateChanged(event: IMyDateModel) {
        let d: Date = new Date(event.jsdate.getTime());
        let s = new Date(event.jsdate.getTime()).valueOf();
        this.startDat1 =s;

        // set previous of selected date
        d.setDate(d.getDate() - 1);
        
        // Get new copy of options in order the date picker detect change
        let copy: IMyOptions = this.getCopyOfEndDateOptions();
        copy.disableUntil = {year: d.getFullYear(), 
                            month: d.getMonth() + 1, 
                            day: d.getDate()};
        this.myToDatePickerOptions = copy;
        this.disabled = false;
        this.addonsite.toDate = '';
    }
    onEndDateChanged(event: IMyDateModel) {
        let d:number= new Date(event.jsdate.getTime()).valueOf();
        this.EndDat1=d;
        this.dis();
    }
    dis()
    {
        this.days = ( this.EndDat1 - this.startDat1) / (1000 * 60 * 60 * 24);
        this.NewDays=  this.days+1; 
        this.noofdays= this.NewDays;
    }
    getCopyOfEndDateOptions(): IMyOptions {
        return JSON.parse(JSON.stringify(this.myToDatePickerOptions));
    }
    constructor(private router: Router, private app: AppComponent,
        private  loginService: LoginService, private commonService: CommonService,private auth : AuthGuard) { }

    public myDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };
    public myToDatePickerOptions: IMyDpOptions = {
      dateFormat: 'dd/mm/yyyy',
      showClearDateBtn :false,
      editableDateField : false
    };
       
      ngOnInit() {
      let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employee=data.json();
           if(this.employee){
          for(let i=0; i<this.employee.length; i++){
              
            this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});   
            }
           }
             
         },
        (error)=>{
                 this.auth.canActivate();
                let empName1 = this.commonService.commonGetCall(requrlEmp);
                empName1.subscribe((data) => {
                this.employee=data.json();
                if(this.employee){
                 for(let i=0; i<this.employee.length; i++){
                     this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});   
                     }
                 }
                },
                (error)=>{
                     console.log("error");
                });
          
        })

        let requrl= this.apiBaseUrl+'/ESS/api/Master/getActiveProjectList/';
        let projectDetails = this.commonService.commonGetCall(requrl);
        var myData = [];
        let map = new Map();
        projectDetails.subscribe((data) => {
            this.projectList = data.json();  
        },
        (error)=>{
                this.auth.canActivate();
                let dashboardDetails1 = this.commonService.commonGetCall(requrl);
                dashboardDetails1.subscribe((data) => {
                  this.projectList = data.json();
                },
                (error)=>{
                    console.log("error");
                });
        });

        let requrlcountry= this.apiBaseUrl+'/ESS/api/Master/getCountryList/';
        let countryDetails = this.commonService.commonGetCall(requrlcountry);
        countryDetails.subscribe((data) => {
            this.countryList = data.json()
        },
        (error)=>{
                this.auth.canActivate();
                let countryDetails1 = this.commonService.commonGetCall(requrl);
                countryDetails1.subscribe((data) => {
                this.countryList = data.json();
                },
                (error)=>{
                  console.log("error");
                });
          
        });

      }
     private employeeName:any;private applyLeaveFromDate;private applyLeaveToDate;private reason;
      test(event){
            this.employeeName=event.id;
       }
      saveOnsiteRequest()
      { 
       this.employeeId=this.employeeName;
        let newFromDate=this.addonsite.fromDate.date.month+"/"+this.addonsite.fromDate.date.day+"/"+this.addonsite.fromDate.date.year;
        let newToDate=this.addonsite.toDate.date.month+"/"+this.addonsite.toDate.date.day+"/"+this.addonsite.toDate.date.year;
        let onsiteDays = this.noofdays ;
        let country = this.addonsite.countryId;
        let project = this.addonsite.projectId;
        let onsiteReason = this.addonsite.reason;


     let onsiteRequest = {
            "empId":this.employeeId,
            "timeIn":new Date(newFromDate).getTime(),
            "timeOut":new Date(newToDate).getTime(),
            //"noofDays":this.noofdays,
            "countryname": country,
            "onsiteProjectID": project,
            "remarks": onsiteReason
        }

        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/addOnsiteDetails/';
        let onsiteData = this.commonService.commonPostCall(requrl,onsiteRequest);
        onsiteData.subscribe((data) => {
             this.router.navigate(['/onsiteList',{flag:1}]);
        },
        (error)=>{
               this.auth.canActivate();

                onsiteData = this.commonService.commonPostCall(requrl,onsiteRequest);
                onsiteData.subscribe((data) => {
                     this.router.navigate(['/onsiteList',{flag:1}]);
                },
                (error)=>{
                     console.log("error");
                });
        }); 
       
            
      }

}
