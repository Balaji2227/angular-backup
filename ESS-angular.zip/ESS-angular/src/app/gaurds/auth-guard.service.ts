import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { LoginService } from  '../login/login.service';
import { AppConfiguration } from '../app-config';
import { CommonService } from '../common.service';

/**
 * <h1>auth-guard.service.ts</h1>
 * @author Gobinath J
 */

@Injectable()
export class AuthGuard implements CanActivate {

    apiBaseUrl = AppConfiguration.apiBaseUrl;
   
    constructor(private router: Router, private loginService: LoginService,private commonService: CommonService) { }
    
    canActivate() {
        let ans:boolean = true;
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/validateOauthToken';
        let dashboardDetails = this.commonService.commonGetCall(requrl);
        dashboardDetails.subscribe((data) => {
             if(data.status == 200){
                ans = true;
             }
        },
        (error)=>{
            this.commonService.refereshToken().subscribe(data => {
                localStorage.setItem("access_token", data.access_token);
                localStorage.setItem("refresh_token", data.refresh_token);
                let dashboardDetails1 = this.commonService.commonGetCall(requrl);
                dashboardDetails1.subscribe((data) => {
                    if(data.status == 200){
                        ans = true;
                     }
                    else{
                        this.loginService.logout();
                        ans = false;
                     }
                },
                (error)=>{
                    this.loginService.logout();
                    ans = false;
                 });
            },
            (error)=>{
                this.loginService.logout();
                ans = false;
                
            });
        });
        console.log('Out Side : ', ans);
        return ans;
     }
}