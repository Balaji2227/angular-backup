import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'myfilter'
})
export class MyFilterPipe implements PipeTransform {
    transform(day: any[], filter: Object): any {
 
        if(filter == 1){
          return day.slice(0, 31);
        }else if(filter == 2){
          return day.slice(0, 27);
        }else if(filter == 3){
          return day.slice(0, 31);
        }
        else if(filter == 4){
          return day.slice(0, 30);
        }
          else if(filter == 5){
          return day.slice(0, 31);
          }
        else if(filter == 6){
          return day.slice(0, 30);
        }
        else if(filter == 7){
          return day.slice(0, 31);
        }
        else if(filter == 8){
          return day.slice(0, 31);
        }
        else if(filter == 9){
         return day.slice(0, 30);
        }
        else if(filter == 10){
          return day.slice(0, 31);
        }
        else if(filter == 11){
          return day.slice(0, 30);
        }
         else if(filter == 12){
          return day.slice(0, 31);
        }
          else{
          return [];
        }
    }
}