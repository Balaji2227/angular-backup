import { Component } from '@angular/core';
import { Router }  from '@angular/router';

import { AppComponent } from '../app.component';
import { AppConfiguration } from "../app-config";
import { CommonService } from '../common.service';
import { LoginService, User } from  '../login/login.service';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import {IMyDpOptions} from 'mydatepicker';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import { Customremarkrender }  from '../leave/customremarkrender.component';

/**
 * @author Prem kumar T
 */

@Component({
    moduleId: module.id,
  selector: 'Leave-Auth',
  templateUrl: './leaveauthorization.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   LeaveAuth  {
  private employeeId; private employeeName; private leaveAuthorized; private searchFromDate; private searchToDate; private leaveAvailed;
  private bySupervisorList; private searchBySupervisor;disabled: boolean = false;
    private settings;selected:any;apiBaseUrl = AppConfiguration.apiBaseUrl;private leaveAuthGridData;private toasterService: ToasterService;
    constructor(private _router: Router, private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,
      toasterService: ToasterService,private excelService: ExcelService,private auth : AuthGuard) { 
        this.toasterService = toasterService;
        this.excelService = excelService;
    }
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });
    ngOnInit() {
          this.settings = {
          selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
            },
          pager : {
            display : true,
            perPage:10
          },
          
          columns: {
            empIdIn: {
              title: 'Emp Id',
              filter: false,
              editable:false
            },
            empName: {
              title: 'Emp Name',
              filter: false,
              editable:false
            },
            applieddate: {
              title: 'Applied Date',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                let parsedDate = new Date(cell);
                var month = parsedDate.getMonth() + 1;
                var date = parsedDate.getDate();
                return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
              }
            },
            fromDate: {
              title: 'From',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                let parsedDate = new Date(cell);
                var month = parsedDate.getMonth() + 1;
                var date = parsedDate.getDate();
                return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
              }
            },
            toDate: {
              title: 'To',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                let parsedDate = new Date(cell);
                var month = parsedDate.getMonth() + 1;
                var date = parsedDate.getDate();
                return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
              }
            },
            noofDays: {
              title: 'No of Days',
              filter: false,
              editable:false
            },
            leaveSplit: {
              title: 'Leave Split Detail',
              filter: false,
              editable:false
            },
            supervisor: {
              title: 'Authorized By',
              filter: false,
              editable:false
            },
            authorised: {
              title: 'Authorized',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell=='Y'){
                  return "Yes";
                }else if(cell=='N'){
                  return "No";
                }else{
                  return "";
                }
              }
            },
            availed: {
              title: 'Availed',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell=='Y'){
                  return "Yes";
                }else if(cell=='N'){
                  return "No";
                }else{
                  return "";
                }
              }
            },
            reason: {
              title: 'Reason',
              filter: false,
              type: 'custom',
              renderComponent: Customremarkrender,
               valuePrepareFunction: (cell, row) => row,
               onComponentInitFunction(instance) {
                   instance.save.subscribe(event => {
                          let compOff = event;
                          instance.rowData.compOff =compOff;
                          
                  });
               }
            }
          }
        };
        
        let requrlGetRole= this.apiBaseUrl+'/ESS/api/emplyee/getEmployeeRole/';
        let roleDetails = this.commonService.commonGetCall(requrlGetRole);
        roleDetails.subscribe((data) => {
            this.app.role = data._body;
        },
        (error)=>{
            this.auth.canActivate();
            let roleDetails1 = this.commonService.commonGetCall(requrlGetRole);
            roleDetails1.subscribe((data) => {
              this.app.role = data.json();
            },
            (error)=>{
                console.log("error: getEmployeeRole");
            });
        })

        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getEmployeeLeaveDetailsForAuth/';
        let leaveDetails = this.commonService.commonGetCall(requrl);
        leaveDetails.subscribe((data) => {
             this.leaveAuthGridData = data.json();
        },
        (error)=>{
                this.auth.canActivate();
                let leaveDetails1 = this.commonService.commonGetCall(requrl);
                leaveDetails1.subscribe((data) => {
                  this.leaveAuthGridData = data.json();
                },
                (error)=>{
                    console.log("error");
                });
           
        })
		/* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })
    }

    onUserRowSelect(event) {
      this.selected = event.selected;
      // for(let i=0; i<=this.selected.length; i++){
      //   alert('Data('+i+')='+this.selected[i].empId);
      // }
    }

    authorizeLeave(){
        if(this.disabled == false){
          alert(this.disabled)
			/* To cancel the applied leave by an employee */
			let authFLag = 0;
			if(this.selected.length>0){
				for(let i=0; i<this.selected.length; i++){
				  if(this.selected[i].authorised == 'Y'){
					 authFLag = 1;            
				  }
				}
				if(authFLag == 0){
					let requrl= this.apiBaseUrl+'/ESS/api/emplyee/authoriseLeave/';
					let leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
					leaveAuthoriseResponseData.subscribe((data) => {
						this.ngOnInit();
						this.toasterService.pop('success', 'Leave Authorised Successfully');
						 this.disabled= true;
						setTimeout(() =>{
						this.disabled = false; 
							}, 5000);
					},
					(error)=>{
						
							 this.auth.canActivate();
							leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
							leaveAuthoriseResponseData.subscribe((data) => {
								this.ngOnInit();
								this.toasterService.pop('success', 'Leave Authorised Successfully');
								this.disabled= true;
								setTimeout(() =>{
								this.disabled = false; 
									}, 5000);
							},
							(error)=>{
								  console.log("error");
							});
					   
					});
				}else{
				  this.toasterService.pop('error', 'Leave(s) already authorised');
				  this.disabled= true;
				  setTimeout(() =>{
				  this.disabled = false; 
					  }, 5000);
				}
			}
		}
    }

    rejectLeave(){
       if(this.disabled == false){
        /* To cancel the applied leave by an employee */  
        let availFLag = 0;    
        for(let i=0; i<this.selected.length; i++){
          if(this.selected[i].availed == 'Y'){
             availFLag = 1;            
          }
        }
        if(availFLag == 0){   
            let requrl= this.apiBaseUrl+'/ESS/api/emplyee/rejectLeave/';
            let leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
            leaveAuthoriseResponseData.subscribe((data) => {
                this.ngOnInit();
                this.toasterService.pop('success', 'Leave Rejected Successfully');
                this.disabled= true;
                setTimeout(() =>{
                this.disabled = false; 
                    }, 5000);
            },
            (error)=>{
                    this.auth.canActivate();
                    leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
                    leaveAuthoriseResponseData.subscribe((data) => {
                        this.ngOnInit();
                        this.toasterService.pop('success', 'Leave Rejected Successfully');
                        this.disabled= true;
                        setTimeout(() =>{
                        this.disabled = false; 
                            }, 5000);
                    },
                    (error)=>{
                         console.log("error");
                    });
               
            });
        }else{
          this.toasterService.pop('error', 'Leave(s) already availed');
          this.disabled= true;
          setTimeout(() =>{
          this.disabled = false; 
              }, 5000);
        }
    }
    }

    searchLeaveAuthDetails(){
    //    private employeeId;private employeeName;private leaveAuthorized;private searchFromDate;private searchToDate;private leaveAvailed;
        let fromDateInTime ;
        let toDateInTime;

        if(this.searchFromDate){
        let fromDateFormat=this.searchFromDate.date.year+"/"+this.searchFromDate.date.month+"/"+this.searchFromDate.date.day;
          fromDateInTime=new Date(fromDateFormat).getTime();
        }
        
        if(this.searchToDate){
          let toDateFormat=this.searchToDate.date.year+"/"+this.searchToDate.date.month+"/"+this.searchToDate.date.day;
          toDateInTime = new Date(toDateFormat).getTime();
        }
        
        if(!this.employeeId){
          this.employeeId="";
        }
        if(!this.employeeName){
          this.employeeName="";
        }
        if(!this.leaveAuthorized){
          this.leaveAuthorized="";
        }
        if(!this.leaveAvailed){
          this.leaveAvailed="";
        }
		if(!this.searchBySupervisor){
          this.searchBySupervisor="";
        }

        let searchData ={
          "fromDate" : fromDateInTime,
          "toDate" : toDateInTime,
          "empIdIn" : this.employeeId,
          "empName" : this.employeeName,
          "authorised" : this.leaveAuthorized,
          "availed" : this.leaveAvailed,
		  "supervisorEmpIds" : this.searchBySupervisor
        }
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveAuthorisationSearch/';
        let leaveAuthSearch = this.commonService.commonPostCall(requrl,searchData);
        leaveAuthSearch.subscribe((data) => {
            this.leaveAuthGridData = data.json();
          },
          
          (error)=>{
                  this.auth.canActivate();
                  leaveAuthSearch = this.commonService.commonPostCall(requrl,searchData);
                  leaveAuthSearch.subscribe((data) => {
                    this.leaveAuthGridData = data.json();
                  },
                  (error)=>{
                       console.log("error");
                  });
              
          });
    }
    
    reset(): void{
        this.employeeId=""; this.searchFromDate = ""; this.searchToDate = "";
        this.employeeName = ""; this.leaveAuthorized = ""; this.leaveAvailed = "";this.searchBySupervisor = "";
        this.searchLeaveAuthDetails();
      }

    exportToExcel(event) {
          var exportEmployeeLeaveAuthDetails =[];
          for(var x= 0;x<this.leaveAuthGridData.length;x++){
            let parsedAppliedDate = new Date(this.leaveAuthGridData[x].applieddate);
            let exportAppliedDate = parsedAppliedDate.getDate()+"/"+(parsedAppliedDate.getMonth()+1)+"/"+parsedAppliedDate.getFullYear();
            
            let parsedFromDate = new Date(this.leaveAuthGridData[x].fromDate);
            let exportFromDate = parsedFromDate.getDate()+"/"+(parsedFromDate.getMonth()+1)+"/"+parsedFromDate.getFullYear();

            let parsedToDate = new Date(this.leaveAuthGridData[x].toDate);
            let exportToDate = parsedToDate.getDate()+"/"+(parsedToDate.getMonth()+1)+"/"+parsedToDate.getFullYear();

              exportEmployeeLeaveAuthDetails.push({'Employee ID':this.leaveAuthGridData[x].empIdIn,'Employee Name':this.leaveAuthGridData[x].empName,'Applied Date':exportAppliedDate,'From':exportFromDate,
              'To':exportToDate,'No Of Days':this.leaveAuthGridData[x].noofDays,'Leave Split Detail':this.leaveAuthGridData[x].leaveSplit,'Supervisor':this.leaveAuthGridData[x].supervisor,'Authorised':this.leaveAuthGridData[x].authorised,
              'Availed':this.leaveAuthGridData[x].availed,'Reason':this.leaveAuthGridData[x].reason})
          }
      this.excelService.exportAsExcelFile(exportEmployeeLeaveAuthDetails, 'LeaveAuthorizationDetails');
    }
    
}
