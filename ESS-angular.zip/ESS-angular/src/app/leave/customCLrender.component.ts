import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author Prem kumar T
 */

@Component({
  selector: 'advanced-example-custom-CLtexteditor',
  template: '<input type="text" (ngModelChange)="clBalanceChange($event)" (keypress)="onlyDecimalNumberKey($event)" [(ngModel)]="CLval" class="form-control " maxlength="5"  >',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})
export class CustomCLrender implements OnInit {

    @Input() CLbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: CustomCLrender;
    private clleaveBalance;
    CLval: any;
    constructor() { 
    }
    ngOnInit() {
        this.CLval =  this.value.clleaveBalance;
    }
    clBalanceChange(CLbalance: any){
        if(CLbalance==""){
            this.CLbalance = 0;
        }else{
            this.CLbalance = CLbalance;
        }
        this.save.emit(this.CLbalance);
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
    return true;
    }
}
