import { Component,Host } from '@angular/core';
import { Router }  from '@angular/router';
import { AppComponent } from '../app.component';
import { AppConfiguration } from '../app-config';
import { CommonService } from '../common.service';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { Pipe, PipeTransform } from '@angular/core';
import {MyFilterPipe} from './leavesettingfilter';

/**
 * <h1>leaveauthorization.component.ts</h1>
 * @author Prasanth B
 */
@Component({
   selector: 'Leave-Sett',
  templateUrl: './leavesetting.component.html',
  styleUrls:  ['../leave/leavesetting.component.css']
})
export   class   LeaveSetting  {
    submitAttempt = false;
    toggleButton:  any = false;
    toggleButton1: any = false;
    toggleButton2: any = false;
    toggleButton3: any = false;
    toggleButton4: any = false;
    toggleButton5: any = false;
    rtoggleButton: any = false;
    rtoggleButton1: any = false;
    rtoggleButton2: any = false;
    rtoggleButton3: any = false;
    rtoggleButton4: any = false;
    rtoggleButton5: any = false;
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    pipeFilter = '';
    pipeFilterData:any[] =  [];
    leaveSettingDet:any = { 
                          yearstartMonth:'',monthstartDate: '', maternityLeave:'', paternityLeave:'', employeeType:'', clAvailable:'', clpostedOn:'',
                          clnoOfDays:'', claccumulationAllowed:'', clmaxaccumulationAllowed:'', slAvailable:'', slPostedOn:'', slnoOfDays:'',slaccumulationAllowed:'',slmaxaccumulationAllowed:'',
                          plAvailable:'',plPostedOn:'',plnoOfDays:'', placcumulationAllowed:'', plmaxaccumulationAllowed:''};
    radioValue = {valueAsc: 'Regular', valueDesc: 'Trainee'} ;
    disabled: boolean = false;
 // leaveSettingDet.employeeType = 'Asc';
handleChange(evt) {
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveConfigurationDetails/'; 
              let configurationDetails = this.commonService.commonGetCall(requrl);
              configurationDetails.subscribe((data) => {
              this.data = data.json(); 
              let data1=this.data;
              var myData = [];
                for(let i=0; i<this.data.length; i++){
                    myData.push(this.data[i]);
                }
                for(let i=0; i<myData.length; i++){
                     var empType=myData[i].employeeType;
                   if(empType=="Regular"){
                       this.leaveSettingDet=myData[i];
                       var clflag= this.leaveSettingDet.clAvailable;
                        var clflag1= this.leaveSettingDet.claccumulationAllowed;
                        var slflag= this.leaveSettingDet.slAvailable;
                        var slflag1= this.leaveSettingDet.slaccumulationAllowed;
                        var plflag= this.leaveSettingDet.plAvailable;
                        var plflag1= this.leaveSettingDet.placcumulationAllowed;
                        if(!clflag){
                            this.rtoggleButton="true";
                            this.rtoggleButton1="true";
                        }else{
                             this.rtoggleButton="false";
                            this.rtoggleButton1="false";
                        }
                        if(!clflag1){
                            this.rtoggleButton1="true";
                        }else{
                            this.rtoggleButton1="false";
                        }
                        if(!slflag){
                            this.rtoggleButton2="true";
                            this.rtoggleButton3="true";
                        }else{
                             this.rtoggleButton2="false";
                            this.rtoggleButton3="false";
                        }
                        if(!slflag1){
                            this.rtoggleButton3="true";
                        }else{
                             this.rtoggleButton3="false";
                        } 
                        if(!plflag){
                            this.rtoggleButton4="true";
                            this.rtoggleButton5="true";
                        }else{
                             this.rtoggleButton4="false";
                            this.rtoggleButton5="false";
                        }
                        if(!plflag1){
                            this.rtoggleButton5="true";
                        }else{
                            this.rtoggleButton5="false";
                        }   
                   }
                }
               
                },
               (error)=>{
        });
      
    }


    handleChange1(evt) {
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveConfigurationDetails/'; 
              let configurationDetails = this.commonService.commonGetCall(requrl);
              configurationDetails.subscribe((data) => {
              this.data = data.json(); 
              let data1=this.data;
              var myData = [];
                for(let i=0; i<this.data.length; i++){
                    myData.push(this.data[i]);
                }
                for(let i=0; i<myData.length; i++){
                     var empType=myData[i].employeeType;
                   if(empType=="Trainee"){
                       this.leaveSettingDet=myData[i];
                       var clflag= this.leaveSettingDet.clAvailable;
                        var clflag1= this.leaveSettingDet.claccumulationAllowed;
                        var slflag= this.leaveSettingDet.slAvailable;
                        var slflag1= this.leaveSettingDet.slaccumulationAllowed;
                        var plflag= this.leaveSettingDet.plAvailable;
                        var plflag1= this.leaveSettingDet.placcumulationAllowed;
                        if(!clflag){
                            this.rtoggleButton="true";
                            this.rtoggleButton1="true";
                        }else{
                             this.rtoggleButton="false";
                            this.rtoggleButton1="false";
                        }
                        if(!clflag1){
                            this.rtoggleButton1="true";
                        }else{
                            this.rtoggleButton1="false";
                        }
                        if(!slflag){
                            this.rtoggleButton2="true";
                            this.rtoggleButton3="true";
                        }else{
                             this.rtoggleButton2="false";
                            this.rtoggleButton3="false";
                        }
                        if(!slflag1){
                            this.rtoggleButton3="true";
                        }else{
                             this.rtoggleButton3="false";
                        } 
                        if(!plflag){
                            this.rtoggleButton4="true";
                            this.rtoggleButton5="true";
                        }else{
                             this.rtoggleButton4="false";
                            this.rtoggleButton5="false";
                        }
                        if(!plflag1){
                            this.rtoggleButton5="true";
                        }else{
                            this.rtoggleButton5="false";
                        }    
                   }
                }
                },
               (error)=>{
        });
      
    }

ngOnInit() { 
            this. pipeFilter = '';
             this.pipeFilterData = this.jsonData;
              let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveConfigurationDetails/'; 
              let configurationDetails = this.commonService.commonGetCall(requrl);
              configurationDetails.subscribe((data) => {
              this.data = data.json(); 
              let data1=this.data;
              //this.leaveSettingDet=data1;
              var myData = [];
                for(let i=0; i<this.data.length; i++){
                    this.pipeFilter=(this.data[i].yearstartMonth).toString();
                    myData.push(this.data[i]);
                }
                 for(let i=0; i<myData.length; i++){
                     var empType=myData[i].employeeType;
                   if(empType=="Regular"){
                       this.leaveSettingDet=myData[i];
                       var clflag= this.leaveSettingDet.clAvailable;
                        var clflag1= this.leaveSettingDet.claccumulationAllowed;
                        var slflag= this.leaveSettingDet.slAvailable;
                        var slflag1= this.leaveSettingDet.slaccumulationAllowed;
                        var plflag= this.leaveSettingDet.plAvailable;
                        var plflag1= this.leaveSettingDet.placcumulationAllowed;
                        if(!clflag){
                            this.rtoggleButton="true";
                            this.rtoggleButton1="true";
                        }
                        if(!clflag1){
                            this.rtoggleButton1="true";
                        }
                        if(!slflag){
                            this.rtoggleButton2="true";
                            this.rtoggleButton3="true";
                        }
                        if(!slflag1){
                            this.rtoggleButton3="true";
                        } 
                        if(!plflag){
                            this.rtoggleButton4="true";
                            this.rtoggleButton5="true";
                        }
                        if(!plflag1){
                            this.rtoggleButton5="true";
                        }    
                   }
                }
                },
               (error)=>{
                });
    }
 constructor(private commonService: CommonService,toasterService: ToasterService) {
      this.toasterService = toasterService; 
      this.pipeFilterData = this.jsonData;
 }
  jsonData = [
      {key: 1, value:'1'},
      {key: 2, value:'2'},
      {key: 3, value:'3'},
      {key: 4, value:'4'},
      {key: 5, value:'5'},
      {key: 6, value:'6'},
      {key: 7, value:'7'},
      {key: 8, value:'8'},
      {key: 9, value:'9'},
      {key: 10, value:'10'},
      {key: 11, value:'11'},
      {key: 12, value:'12'},
      {key: 13, value:'13'},
      {key: 14, value:'14'},
      {key: 15, value:'15'},
      {key: 16, value:'16'},
      {key: 17, value:'17'},
      {key: 18, value:'18'},
      {key: 19, value:'19'},
      {key: 20, value:'20'},
      {key: 21, value:'21'},
      {key: 22, value:'22'},
      {key: 23, value:'23'},
      {key: 24, value:'24'},
      {key: 25, value:'25'},
      {key: 26, value:'26'},
      {key: 27, value:'27'},
      {key: 28, value:'28'},
      {key: 29, value:'29'},
      {key: 30, value:'30'},
      {key: 31, value:'31'}
    ];
      private data;
      private yearstartMonth;
      private monthstartDate;
      private maternityLeave ;
      private paternityLeave ;
      private employeeType ;
      private clAvailable;
      private clpostedOn ;
      private clnoOfDays;
      private claccumulationAllowed;
      private clmaxaccumulationAllowed;
      private slAvailable;
      private slpostedOn;
      private slnoOfDays;
      private slaccumulationAllowed;
      private slmaxaccumulationAllowed;
      private plAvailable;
      private plPostedOn;
      private plnoOfDays;
      private placcumulationAllowed;
      private plmaxaccumulationAllowed;
      private valueCheck;
   // this.leaveSettingDet.tslAvailable=false;
//toggleBool: any=true;

    changeEvent(event) {
        if (event.target.checked) {
            this.rtoggleButton= false;

       }
        else {
            this.rtoggleButton= true;
            this.rtoggleButton1= true;
            this.leaveSettingDet.clmaxaccumulationAllowed='';
            this.leaveSettingDet.clnoOfDays='';
            this.leaveSettingDet.claccumulationAllowed="";
            this.leaveSettingDet.clAvailable="";
             this.leaveSettingDet.clpostedOn='';
         }
    }

    changeEvent1(event) {
        if (event.target.checked) {
           this.rtoggleButton1= false;
        }
        else{
         this.rtoggleButton1= true;
         this.leaveSettingDet.clmaxaccumulationAllowed='';
         this.leaveSettingDet.claccumulationAllowed='';
        }
    }

    changeEvent2(event) {
        if (event.target.checked) {
          this.rtoggleButton2= false;
        }
        else{
         this.rtoggleButton2= true;
         this.rtoggleButton3= true;
         this.leaveSettingDet.slmaxaccumulationAllowed='';
         this.leaveSettingDet.slnoOfDays='';
         this.leaveSettingDet.slaccumulationAllowed="";
         this.leaveSettingDet.slAvailable="";
         this.leaveSettingDet.slPostedOn='';
        }
    }
    changeEvent3(event) {
        if (event.target.checked) {
           this.rtoggleButton3= false;
        }
        else{
            this.rtoggleButton3= true;
            this.leaveSettingDet.slmaxaccumulationAllowed='';
            this.leaveSettingDet.slaccumulationAllowed='';
        }
    }
    changeEvent4(event) {
        if (event.target.checked) {
           this.rtoggleButton4= false;
        }
        else{
           this.rtoggleButton4= true;
           this.rtoggleButton5= true;
           this.leaveSettingDet.plmaxaccumulationAllowed='';
           this.leaveSettingDet.plnoOfDays='';
           this.leaveSettingDet.placcumulationAllowed="";
           this.leaveSettingDet.plAvailable="";
           this.leaveSettingDet.plPostedOn='';
        }
    }
    changeEvent5(event) {
        if (event.target.checked) {
           this.rtoggleButton5= false;
           
        }
        else{
          this.rtoggleButton5= true;
          this.leaveSettingDet.plmaxaccumulationAllowed='';
          this.leaveSettingDet.placcumulationAllowed='';
        }
    }


    tchangeEvent(event) {
        if (event.target.checked) {
            this.toggleButton= false;
        }
        else {
            this.toggleButton= true;
        }
    }

    tchangeEvent1(event) {
        if (event.target.checked) {
           this.toggleButton1= false;
        }
        else{
         this.toggleButton1= true;
         this.leaveSettingDet.tclmaxaccumulationAllowed='';
        }
    }
    tchangeEvent2(event) {
        if (event.target.checked) {
          this.toggleButton2= false;
        }
        else{
         this.toggleButton2= true;
        }
    }
    tchangeEvent3(event) {
        if (event.target.checked) {
           this.toggleButton3= false;
        }
        else{
            this.toggleButton3= true;
            this.leaveSettingDet.tslmaxaccumulationAllowed='';
        }
    }
    tchangeEvent4(event) {
        if (event.target.checked) {
           this.toggleButton4= false;
        }
        else{
           this.toggleButton4= true;
        }
    }
    tchangeEvent5(event) {
        if (event.target.checked) {
           this.toggleButton5= false;
        }
        else{
          this.toggleButton5= true;
          this.leaveSettingDet.tplmaxaccumulationAllowed='';
        }
    }
    onlyNumberKey(event) {
          return (event.charCode == 8 ||event.charCode == 46 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
        }
        onlyCharactersKey(event){
        var charCode = (event.which) ? event.which : event.keyCode
            if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123) && charCode != 32 && charCode != 8)
            return false;
            return true;
        }
save()
{ 
       let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveSettingSave/';
                 console.log("employeeType:"+this.leaveSettingDet);
                // this. submitAttempt = true;
                let leavesettingResponse = this.commonService.commonPostCall(requrl,this.leaveSettingDet);
                leavesettingResponse.subscribe((data) => {
                this.leaveSettingDet=data._body ;
                var jsonObject : any = JSON.parse(data._body);
                this.leaveSettingDet=jsonObject;
                this.valueCheck=jsonObject ; 
                console.log("this.valueCheck",this.valueCheck);
               if(this.valueCheck!='')
                {
                    this.toasterService.pop('success', 'Leave Setting Saved Successfully');
                    this.disabled= true;
                    setTimeout(() =>{
                        this.disabled = false; 
                            }, 5000);
                }
               },
        (error)=>{
                console.log("error"+this.leaveSettingDet);
                leavesettingResponse = this.commonService.commonPostCall(requrl,this.leaveSettingDet);
                leavesettingResponse.subscribe((data) => {
                var jsonObject : any = JSON.parse(data._body);
                this.leaveSettingDet=jsonObject;
                },
                (error)=>{
                    console.log("error");
                });
            }); 
       
}
saverange(){
    this.leaveSettingDet.monthstartDate="";
}
}