import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import { Customreasonrender }  from '../leave/customreasonrender.component';
/**
 * <h1>leavedetails.component.ts</h1>
 * @author Gobinath J
 */

@Component({
    moduleId: module.id,
    selector: 'Leave-Detail',
    templateUrl: './leavedetails.component.html',
    styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   LeaveDetails  {
    
    private settings;
    private employee:any;
    private applieddate;
    private fromDate;
    private toDate;
    private noofDays;
    private reason;
    private authorised;
    private supervisor;
    private availed; 
    private data; 
    private employees;
    private status;
    private selectOption: any;
    private employeeId;
    private employeeName;
    private category: Array<any> = []
    private bySupervisorList;
    apiBaseUrl = AppConfiguration.apiBaseUrl;private searchBySupervisor;

    constructor(private _router: Router, private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,private excelService: ExcelService,private auth : AuthGuard) { 
      this.excelService = excelService;
    }
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    }; 
    
    ngOnInit() {
       if(this.app.role == 'ROLE_ADMIN' || this.app.role == 'ROLE_SUPERVISOR')
      {
      this.settings = {
        //selectMode : 'multi',
        mode: 'inline',
        hideSubHeader: true,
        actions: {
          add: false,
          edit:false,
          delete:false,
          //position: 'right'
        },
        pager : {
          display : true,
          perPage:10
        },
        columns: {
          empIdIn: {
            title: 'Emp ID',
            filter: false
          },
          empName: {
            title: 'Emp Name',
            filter: false
          },
          applieddate: {
            title: 'Applied Date',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
          },
          fromDate: {
            title: 'From',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
                   
          },
          toDate: {
            title: 'To',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
          },
          noofDays: {
            title: 'No Of Days',
            filter: false
          },
          reason: {
               title: 'Reason',
              filter: false,
              type: 'custom',
              renderComponent: Customreasonrender,
               valuePrepareFunction: (cell, row) => row,
               onComponentInitFunction(instance) {
                   instance.save.subscribe(event => {
                          let compOff = event;
                          instance.rowData.compOff =compOff;
                          
                  });
               }
          },
          status: {
            title: 'Status',
            filter: false
          },
          supervisor: {
            title: 'Authorised By',
            filter: false
          },
          availed: {
            title: 'Availed',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
              if(cell=='Y'){
                return "Yes";
              }else if(cell=='N'){
                return "No";
              }else{
                return "";
              }
            }
          }
        }
      };
      }
    else{
       this.settings = {
        //selectMode : 'multi',
        mode: 'inline',
        hideSubHeader: true,
        actions: {
          add: false,
          edit:false,
          delete:false,
          //position: 'right'
        },
        pager : {
          display : true,
          perPage:10
        },
        columns: {
          
          applieddate: {
            title: 'Applied Date',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
          },
          fromDate: {
            title: 'From',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
                   
          },
          toDate: {
            title: 'To',
            filter: false,
            valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  } 
          },
          noofDays: {
            title: 'No Of Days',
            filter: false
          },
          reason: {
            title: 'Reason',
            filter: false
          },
          status: {
            title: 'Status',
            filter: false
          },
          supervisor: {
            title: 'Supervisor',
            filter: false
          },
          availed: {
            title: 'Availed',
            filter: false
          }
        }
      };

    }
      /** To Fetch leave details based on Role */
     let requrl= this.apiBaseUrl+'/ESS/api/emplyee/employeeLeavesForRP/';
        let leaveDetails = this.commonService.commonGetCall(requrl);
        leaveDetails.subscribe((data) => {
             this.data = data.json(); 
          
       
        },
        (error)=>{
                 this.auth.canActivate();
                let leaveDetails1 = this.commonService.commonGetCall(requrl);
                leaveDetails1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                   console.log("error");
                });
          
        })
       
      /** Assigning Employee Names in drop-down */
       let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employee=data.json();
           if(this.employee)
            {
              for(let i=0; i<this.employee.length; i++){
              this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});       
              }
            }
        },
        (error)=>{
              this.auth.canActivate();
              let empName1 = this.commonService.commonGetCall(requrlEmp);
              empName1.subscribe((data) => {
                this.employee=data.json();
                if(this.employee)
                {
                  for(let i=0; i<this.employee.length; i++){
                    this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});      
                  }
                }
                },
                (error)=>{
                    console.log("error");
                });
          })
        /** Assigning Status in drop-down */
        this.selectOption = [
           {
              label: " ",
              value: ""
            },
            {
              label: "Authorised",
              value: "Authorised"
            }, {
              
              label: "Not Authorised",
              value: "Not Authorised"
            }, {
              
              label: "Rejected",
              value: "Rejected"
            }, {
              
              label: "Cancelled",
              value: "Cancelled"
            }
    ]

        /* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })
    
   }
  test(event){
    this.employeeName=event.id;
  }
    /** Search Functionality  */
  searchEmpLeaveDetail(){
    let fromDateFinal ;
    let toDateFinal;

    if(this.fromDate){
     let fromDateFormat=this.fromDate.date.year+"/"+this.fromDate.date.month+"/"+this.fromDate.date.day;
      fromDateFinal=new Date(fromDateFormat).getTime();
    }
    
    
    if(this.toDate){
      let toDateFormat=this.toDate.date.year+"/"+this.toDate.date.month+"/"+this.toDate.date.day;
       toDateFinal = new Date(toDateFormat).getTime();
    }
    console.log('this.fromDate',fromDateFinal);
     console.log('this.toDate',toDateFinal);

    if(!this.status){
      this.status="";
    }

    if(!this.employeeName){
      this.employeeName="";
    }

    if(!this.searchBySupervisor){
      this.searchBySupervisor="";
    }

    let searchData ={
     "fromDate" : fromDateFinal,
     "toDate" : toDateFinal,
     "status" : this.status,
     "empIdIn" : this.employeeName,
     "supervisorEmpIds" : this.searchBySupervisor 
    }
     console.log('searchData',searchData);
     let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveHistorySearch/';
     let leaveHistory = this.commonService.commonPostCall(requrl,searchData);
     leaveHistory.subscribe((data) => {
        this.data = data.json();
      },
      
      (error)=>{
           this.auth.canActivate();
           leaveHistory = this.commonService.commonPostCall(requrl,searchData);
            leaveHistory.subscribe((data) => {
              this.data = data.json();
            },
            (error)=>{
                  console.log("error");
            });
        });
 
  }
  /** Reset Operation */
  reset(): void{
    this.employeeName = ''; this.fromDate = ''; this.toDate = '';
    this.status = ""; this.searchBySupervisor = "";
    this.category=[];
    this.ngOnInit();
  }
 exportToExcel(event) {
        var exportLeaveDetails =[];
        /*var appliedDate = null;
         var toDate = null;
         var fromDate = null;*/
        for(var x= 0;x<this.data.length;x++){
          let parsedAppliedDate = new Date(this.data[x].applieddate);
            let appliedDate = parsedAppliedDate.getDate()+"/"+(parsedAppliedDate.getMonth()+1)+"/"+parsedAppliedDate.getFullYear();
            
            let parsedFromDate = new Date(this.data[x].fromDate);
            let fromDate = parsedFromDate.getDate()+"/"+(parsedFromDate.getMonth()+1)+"/"+parsedFromDate.getFullYear();

            let parsedToDate = new Date(this.data[x].toDate);
            let toDate = parsedToDate.getDate()+"/"+(parsedToDate.getMonth()+1)+"/"+parsedToDate.getFullYear();    
           
          exportLeaveDetails.push({'Emp ID':this.data[x].empIdIn,'Emp Name':this.data[x].empName,'Applied Date':appliedDate,'From':fromDate,'To':toDate,
            'No Of Days':this.data[x].noofDays,'Reason':this.data[x].reason,'Status':this.data[x].cancelStatus,'Supervisor':this.data[x].supervisor,
            'Availed':this.data[x].availed})
        }
    this.excelService.exportAsExcelFile(exportLeaveDetails, 'LeaveDetails');
  }
}