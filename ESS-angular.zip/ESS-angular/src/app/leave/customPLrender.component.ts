import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author Prem kumar T
 */

@Component({
  selector: 'advanced-example-custom-PLtexteditor',
  template: '<input type="text" (ngModelChange)="plBalanceChange($event)" (keypress)="onlyDecimalNumberKey($event)" [(ngModel)]="PLval" class="form-control " maxlength="5"  >',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})
export class CustomPLrender implements OnInit {

    @Input() PLbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: CustomPLrender;
    private plleaveBalance;
    PLval: any;
    constructor() { 
    }
    ngOnInit() {
        this.PLval =  this.value.plleaveBalance;
    }
    plBalanceChange(PLbalance: any){
        if(PLbalance==""){
            this.PLbalance = 0;
        }else{
            this.PLbalance = PLbalance;
        }
        this.save.emit(this.PLbalance);
    }

    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
    return true;
    }
}
