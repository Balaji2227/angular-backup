import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author 
 */

@Component({
  selector: 'advanced-example-custom-CLtexteditor',
  template: '<span data-toggle="tooltip" data-placement="top" title="{{this.reason}}">{{this.reason}}</span>',
})
export class Customreasonrender implements OnInit {

    @Input() CLbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: Customreasonrender;
    private reason;

    constructor() { 
    }
    ngOnInit() {
       
        this.reason =  this.value.reason;
        console.log("trhge",this.reason)
    }
   
}
