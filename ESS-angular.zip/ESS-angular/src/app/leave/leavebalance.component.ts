import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import { CustomCLrender } from "./customCLrender.component";
import { CustomSLrender } from "./customSLrender.component";
import { CustomPLrender } from "./customPLrender.component";
import { CustomCompOffrender } from "./customCompOffrender.component";

/**
 * @author Prem kumar T
 */

@Component({
    moduleId: module.id,
    selector: 'Leave-balance',
    templateUrl: './leavebalance.component.html',
    styleUrls:  ['./leaveBalance.component.css']
})

export   class   LeaveBalance  {
  private settings; private leavebalanceGridData; private selected;private bySupervisorList;private toasterService: ToasterService;
  private employeeId; private employeeName;private searchBySupervisor;
    apiBaseUrl = AppConfiguration.apiBaseUrl;

    constructor(private auth: AuthGuard,private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,
                toasterService: ToasterService) {
        this.toasterService = toasterService;
    }
     
    ngOnInit() {
        let requrlGetRole= this.apiBaseUrl+'/ESS/api/emplyee/getEmployeeRole/';
        let roleDetails = this.commonService.commonGetCall(requrlGetRole);
        roleDetails.subscribe((data) => {
            this.app.role = data._body;
        },
        (error)=>{
            this.auth.canActivate();
            let roleDetails1 = this.commonService.commonGetCall(requrlGetRole);
            roleDetails1.subscribe((data) => {
              this.app.role = data.json();
            },
            (error)=>{
                console.log("error: getEmployeeRole");
            });
        })

        this.settings = {
          selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
            },
          pager : {
            display : true,
            perPage:10
          },
          
          columns: {
            empId: {
              title: 'Emp Id',
              filter: false,
              editable:false
            },
            empName: {
              title: 'Emp Name',
              filter: false,
              editable:false
            },
            employeeType: {
              title: 'Emp Type',
              filter: false,
              editable:false
            },
            supervisorName: {
              title: 'Supervisor',
              filter: false,
              editable:false
            },
            clleaveBalance: {
              title: 'CL',
              filter: false,
              editable:false,
              type: 'custom',
              renderComponent: CustomCLrender,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                  instance.save.subscribe(event => {
                    instance.rowData.clleaveBalance = event;
                });
              }
            },
            slleaveBalance: {
              title: 'SL',
              filter: false,
              editable:false,
              type: 'custom',
              renderComponent: CustomSLrender,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                  instance.save.subscribe(event => {
                    instance.rowData.slleaveBalance = event;
                });
              }
            },
            plleaveBalance: {
              title: 'PL',
              filter: false,
              editable:false,
              type: 'custom',
              renderComponent: CustomPLrender,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                  instance.save.subscribe(event => {
                    instance.rowData.plleaveBalance = event;
                });
              }
            },
            comOffBalance: {
              title: 'Comp Off',
              filter: false,
              editable:false,
              type: 'custom',
              renderComponent: CustomCompOffrender,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                  instance.save.subscribe(event => {
                    instance.rowData.comOffBalance = event;
                });
              }
            }
          }
        };
        if(this.app.role !="ROLE_ADMIN"){
            this.settings = {
              //selectMode : 'multi',
              mode: 'inline',
              hideSubHeader: true,
              actions: {
                add: false,
                edit:false,
                delete:false,
                //position: 'right'
                },
              pager : {
                display : true,
                perPage:10
              },
              
              columns: {
                empId: {
                  title: 'Emp Id',
                  filter: false,
                  editable:false
                },
                empName: {
                  title: 'Emp Name',
                  filter: false,
                  editable:false
                },
                employeeType: {
                  title: 'Emp Type',
                  filter: false,
                  editable:false
                },
                clleaveBalance: {
                  title: 'CL',
                  filter: false,
                  editable:false
                },
                slleaveBalance: {
                  title: 'SL',
                  filter: false,
                  editable:false
                },
                plleaveBalance: {
                  title: 'PL',
                  filter: false,
                  editable:false
                },
                comOffBalance: {
                  title: 'Comp Off',
                  filter: false,
                  editable:false
                }
              }
            };
        }
        
        /** To Fetch leave balance details */
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getLeaveBalanceDetails/';
        let leaveBalance = this.commonService.commonGetCall(requrl);
        leaveBalance.subscribe((data) => {
            this.leavebalanceGridData = data.json(); 
            console.log("leavebalanceGridData",this.leavebalanceGridData);
               },
        (error)=>{
            this.auth.canActivate();
            let leaveBalance = this.commonService.commonGetCall(requrl);
            leaveBalance.subscribe((data) => {
              this.leavebalanceGridData = data.json();
            },
            (error)=>{
              console.log("error");
            }); 
        })
          
        /* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })
    }

    onUserRowSelect(event) {
      this.selected = event.selected;
      // for(let i=0; i<=this.selected.length; i++){
      //   alert('Data('+i+')='+this.selected[i].empId);
      // }
    }
    leaveBalanceSearch(): void{
      if(!this.employeeId){
        this.employeeId="";
      }
      if(!this.employeeName){
        this.employeeName="";
      }
      if(!this.searchBySupervisor){
        this.searchBySupervisor="";
      }

      let searchData ={
        "empId" : this.employeeId,
        "empName" : this.employeeName,
        "supervisorEmpIds" : this.searchBySupervisor
      }
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/leaveBalanceSearch/';
      let leaveAuthSearch = this.commonService.commonPostCall(requrl,searchData);
      leaveAuthSearch.subscribe((data) => {
        this.leavebalanceGridData = data.json();
      },

      (error)=>{
        this.auth.canActivate();
        leaveAuthSearch = this.commonService.commonPostCall(requrl,searchData);
        leaveAuthSearch.subscribe((data) => {
          this.leavebalanceGridData = data.json();
        },
        (error)=>{
          console.log("error");
        });
      });
    }
    reset(): void{
      this.employeeId=""; this.employeeName = ""; this.searchBySupervisor = "";
      this.leaveBalanceSearch();
    }
    saveLeaveBalance(): void{
      let allowSave = this.allowSaveLeaveBalance();
        if(allowSave==1){
          let requrl= this.apiBaseUrl+'/ESS/api/emplyee/saveLeaveBalance/';
          let leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
          leaveAuthoriseResponseData.subscribe((data) => {
              this.ngOnInit();
              this.toasterService.pop('success', 'Leave Balance Updated Successfully');
          },
          (error)=>{
              this.auth.canActivate();
              leaveAuthoriseResponseData = this.commonService.commonPostCall(requrl,this.selected);
              leaveAuthoriseResponseData.subscribe((data) => {
                  this.ngOnInit();
                  this.toasterService.pop('success', 'Leave Balance Updated Successfully');
              },
              (error)=>{
                    console.log("error");
              });
          });
        }
    }

    allowSaveLeaveBalance(): number{
      let allowsSaveFlag: number = 1; //1 is allow 0 is not allow
      if(this.selected){
        for(let i=0; i<this.selected.length; i++){
          if(this.selected[i].clAvailable == "true"){
            if(this.selected[i].claccumulationAllowed == "true"){
                if(this.selected[i].clleaveBalance > this.selected[i].clmaxaccumulationAllowed){
                    this.toasterService.pop('error', 'CL Maximum Leaves exceeded');
                    allowsSaveFlag = 0;
                    break;
                }
            }
          }else{
            if(this.selected[i].clleaveBalance > 0){
              this.toasterService.pop('error', 'CL Leave(s) not available');
              allowsSaveFlag = 0;
              break;
            }
          }

          if(this.selected[i].slAvailable == "true"){
            if(this.selected[i].slaccumulationAllowed == "true"){
                if(this.selected[i].slleaveBalance > this.selected[i].slmaxaccumulationAllowed){
                    this.toasterService.pop('error', 'SL Maximum Leaves exceeded');
                    allowsSaveFlag = 0;
                    break;
                }
            }
          }else{
            if(this.selected[i].slleaveBalance > 0){
              this.toasterService.pop('error', 'SL Leave(s) not available');
              allowsSaveFlag = 0;
              break;
            }
          }

          if(this.selected[i].plAvailable == "true"){
            if(this.selected[i].placcumulationAllowed == "true"){
                if(this.selected[i].plleaveBalance > this.selected[i].plmaxaccumulationAllowed){
                    this.toasterService.pop('error', 'PL Maximum Leaves exceeded');
                    allowsSaveFlag = 0;
                    break;
                }
            }
          }else{
            if(this.selected[i].plleaveBalance > 0){
              this.toasterService.pop('error', 'PL Leave(s) not available');
              allowsSaveFlag = 0;
              break;
            }
          }
        }
        return allowsSaveFlag;
      }
    }
}
