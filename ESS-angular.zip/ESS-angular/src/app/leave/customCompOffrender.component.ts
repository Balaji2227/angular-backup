import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author Prem kumar T
 */

@Component({
  selector: 'advanced-example-custom-CompOfftexteditor',
  template: '<input type="text" (ngModelChange)="compOffBalanceChange($event)" (keypress)="onlyDecimalNumberKey($event)" class="form-control " [(ngModel)]="CompOffval" maxlength="5"  >',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})
export class CustomCompOffrender implements OnInit {

    @Input() CompOffbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: CustomCompOffrender;
    private comOffBalance;
    CompOffval: any;
    constructor() { 
    }
    ngOnInit() {
        this.CompOffval =  this.value.comOffBalance;
    }
    compOffBalanceChange(CompOffbalance: any){
        if(CompOffbalance==""){
            this.CompOffbalance = 0;
        }else{
            this.CompOffbalance = CompOffbalance;
        }
        this.save.emit(this.CompOffbalance);
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
    onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
    return true;
    }
}
