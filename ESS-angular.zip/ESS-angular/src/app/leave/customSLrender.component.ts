import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author Prem kumar T
 */

@Component({
  selector: 'advanced-example-custom-SLtexteditor',
  template: '<input type="text" (ngModelChange)="slBalanceChange($event)" (keypress)="onlyDecimalNumberKey($event)" [(ngModel)]="SLval" class="form-control " maxlength="5" >',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})
export class CustomSLrender implements OnInit {

    @Input() SLbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: CustomSLrender;
    private slleaveBalance;
    SLval: any;
    constructor() { 
    }
    ngOnInit() {
        this.SLval =  this.value.slleaveBalance;
    }
    slBalanceChange(SLbalance: any){
        if(SLbalance==""){
            this.SLbalance = 0;
        }else{
            this.SLbalance = SLbalance;
        }
        this.save.emit(this.SLbalance);
    }
    onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
    }
     onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
    return true;
    }
}
