import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent }      from './dashboard/dashboard.component';
import { LoginComponent }      from './login/login.component';
import { AuthGuard }  from './gaurds/auth-guard.service';
import { AttendanceAuth }  from './attendance/attendanceauth.component';
import { AttendanceDetails }  from './attendance/attendancedetails.component';
import { AttendanceSummary }  from './attendance/attensummary.component';
import { LeaveAuth }  from './leave/leaveauthorization.component';
import { LeaveDetails }  from './leave/leavedetails.component';
import { HolidayList }  from './holiday/holidaylist.component';
import { PhoneExtn }  from './phone/phoneextn.component';
import { DesignationMaster }  from './designation/designation.component';
import { ProjectMaster }  from './project/project.component';
import { CalendarMaster }  from './calendar/calendar.component';
import { HolidayMaster }  from './holiday/holidayMaster.component';
import { AddHoliday }  from './holiday/addholiday.component';
import { EmployeeList }  from './employee/employeeList.component';
import { OnsiteList } from './onsite/onsiteList.component';
import { AddOnsiteMaster } from './onsite/addOnsite.component';
import { EditEmployeeMaster } from './employee/editEmployee.component';
import{ CreateEmployeeMaster } from './employee/createEmployee.component';
import { LeaveSetting }  from './leave/leavesetting.component';
import { HolidaysYearWiseEdit } from './holiday/holidaysYearWiseEdit.component';
import { EditOnsiteMaster } from './onsite/editOnsite.component';
import { WorkFromHomeList } from './workfromhome/workfromhomeList.component';
import { AddWorkFromHome } from './workfromhome/addWorkFromHome.component';
import { EditWorkfromhomeMaster } from './workfromhome/editWorkfromhome.component';
import { phoneExtnMaster } from './phone/phoneExtnMaster.component';
import { LeaveBalance } from './leave/leavebalance.component';
import { ActivityMaster }  from './activity/activity.component';
import { statutory }  from './Statutory/Statutory.component';
import { MonthlyReport }  from './attendance/attendancereport.component';
import { TimeSheetMaster } from './timeSheet/timeSheet.component';
/**
 * <h1>app-routing.module.ts</h1>
 * @author Gobinath J
 */

const routes: Routes = [
  {
    path: '', canActivate: [AuthGuard],
      children: [
        { path: '',   component: DashboardComponent },
        { path: 'dashboard',   component: DashboardComponent },
        { path: 'attendanceAuth',   component: AttendanceAuth },
        { path: 'attendanceDetails',   component: AttendanceDetails },
        { path: 'attendanceSummary',   component: AttendanceSummary },
        { path: 'leaveAuth',   component: LeaveAuth },
        { path: 'leaveDetails',   component: LeaveDetails },
        { path: 'holidayList',   component: HolidayList },
        { path: 'phoneExtn',   component: PhoneExtn },
        { path: 'designation',   component: DesignationMaster },
        { path: 'project',   component: ProjectMaster },
        { path: 'calendar',   component: CalendarMaster },
        { path: 'holiday',   component: HolidayMaster },
        { path: 'addholiday/:idmaster',   component: AddHoliday },
        { path: 'employeeList',   component: EmployeeList },
        { path: 'editEmployee/:userId',   component: EditEmployeeMaster },
        {path: 'createEmployee',  component: CreateEmployeeMaster},
        {path: 'leaveSetting',  component: LeaveSetting},
		{ path: 'onsiteList',   component: OnsiteList },
        { path: 'addOnsite',   component: AddOnsiteMaster },
		{ path: 'holiday/:idmaster',   component: HolidayMaster },
        { path: 'holidaysYearWiseEdit/:idmaster/:year',   component: HolidaysYearWiseEdit  },
        { path: 'workfromhomeList',   component: WorkFromHomeList },
        { path: 'addWorkFromHome',   component: AddWorkFromHome },
        { path: 'editOnsite/:transId',   component: EditOnsiteMaster },
        { path: 'editWorkfromhome/:transId',   component: EditWorkfromhomeMaster },
        { path: 'phoneExtnMaster',   component: phoneExtnMaster },
        { path: 'leaveBalance',   component: LeaveBalance },
         { path: 'activityMaster',   component: ActivityMaster },
		 { path: 'statutory',   component: statutory },
         { path: 'attendanceReport',   component: MonthlyReport },  
		 { path: 'timeSheetMaster',   component: TimeSheetMaster },	
      ]
  },
    { path: '',   component: LoginComponent },
  { path: 'login',   component: LoginComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
