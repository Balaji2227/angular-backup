import { Component, OnInit } from '@angular/core';
import { trigger, state, style, transition, animate} from '@angular/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import {IMyDpOptions,IMyDateModel,MyDatePicker} from 'mydatepicker';
import { Router, ActivatedRoute, Params }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AuthGuard } from '../gaurds/auth-guard.service';
@Component({
  selector: 'timeSheet-Master',
  templateUrl: './timeSheet.component.html',
  styleUrls: ['./timeSheet.component.css'],
})
export class TimeSheetMaster implements OnInit {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl; private ViewEmployeeDetail;private toasterService: ToasterService;
    private dropdownList; private projects;projectsList = [];private activites;private projectName;private description;
    private activityName;private time; private empId;private role;private dateList=[];
    timeSheetData:any = { empId:'',projectName:'',description:'',activityName:'',workingHours:'',taskDate:''};
     
    private employeeList;private timeSheetList; 
    public incrementor:number=0; 
    private todaysDate:number;
    private dateheader:String;
    public defaultDate:Date =new Date();
    public hours:number;public minutes:number;
    public startdate:Date;
    constructor(private auth: AuthGuard,private _router: Router,private app: AppComponent, 
        private commonService: CommonService,private route: ActivatedRoute,toasterService: ToasterService,private activatedRoute: ActivatedRoute) { 
            this.toasterService = toasterService; 
        }
    public Selecteddate: any={ date: { year: this.defaultDate.getFullYear(), month:this.defaultDate.getMonth()+1, day: this.defaultDate.getDate() } };      
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    
     ngOnInit() {
         this.timeSheetData.empId=localStorage.getItem("userId")
         this.generateDates();
         this.timeSheetData.taskDate=this.defaultDate;   
        //DropDown projectts
        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
            dropdownDetails.subscribe((data) => {
                this.dropdownList = data.json();
                this.projects = this.dropdownList.projects; 
            });
            //activaties master
        let activityUrl= this.apiBaseUrl+'/ESS/api/Master/getActivitiesList/';
            let designationDetails = this.commonService.commonGetCall(activityUrl);
            designationDetails.subscribe((data) => {
                this.activites = data.json();
            },
            (error)=>{
                    this.auth.canActivate();
                    let dashboardDetails1 = this.commonService.commonGetCall(activityUrl);
                    dashboardDetails1.subscribe((data) => {
                        this.activites = data.json();
                    },
                    (error)=>{
                        console.log("error");
                        
                    });
            }); 
  }
        saveTimeSheet(){
            
            this.timeSheetData.empId=this.empId;   
            this.timeSheetData.workingHours=this.timeSheetData.workingHours.getHours()+":"+this.timeSheetData.workingHours.getMinutes()+":"+this.timeSheetData.workingHours.getSeconds();
            let timeSheetUrl= this.apiBaseUrl+'/ESS/api/Master/saveTimeSheet/';
            let details = this.commonService.commonPostCall(timeSheetUrl,this.timeSheetData);
            details.subscribe((data) => {
                if(data._body == "Sucess"){
                    $('#closepopup').click();
                    var  dd=new Date(this.timeSheetData.taskDate);
                    console.log("==save",this.timeSheetData.taskDate,dd);
                    this.timeSheetData = { empId:'',projectName:'select',description:'',activityName:'',workingHours:'',taskDate:''};
                    this.getTimesheetDetailsByDate(dd);
                }
            },
            (error)=>{
                    this.auth.canActivate();
                    details = this.commonService.commonPostCall(timeSheetUrl,this.timeSheetData);
                    details.subscribe((data) => {
                    },
                    (error)=>{
                        console.log("error");
                    });
            });
     }

     generateDates(){
         var date=new Date();
         var j=1;    
         for(var i=0; i < 7; i++){
                var curdate = new Date(date.getTime() + i * 24 * 60 * 60 * 1000);
               var dateincrementer = new Date(curdate.getFullYear(),(curdate.getMonth()),(curdate.getDate()));
               var currentdate= dateincrementer.getDate()+"/"+(dateincrementer.getMonth()+j)+"/"+dateincrementer.getFullYear();
               var weekday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday",
                        "Friday","Saturday")
                this.dateList[i]={"Day":weekday[dateincrementer.getDay()],"Date":currentdate,"loggingHours":"5hrs","Dateformat":dateincrementer}   
          }
        this.startdate=this.dateList[0].Dateformat;
        this.getTimesheetDetailsByDate(this.startdate);    
     }

    onDateChanged(event: IMyDateModel) {
         var date=event.jsdate;
         var j=1;    
         for(var i=0; i < 7; i++){
                var curdate = new Date(date.getTime() + i * 24 * 60 * 60 * 1000);
               var dateincrementer = new Date(curdate.getFullYear(),(curdate.getMonth()),(curdate.getDate()));
               var currentdate= dateincrementer.getDate()+"/"+(dateincrementer.getMonth()+j)+"/"+dateincrementer.getFullYear();
               var weekday=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday",
                        "Friday","Saturday")
                this.dateList[i]={"Day":weekday[dateincrementer.getDay()],"Date":currentdate,"loggingHours":"5hrs","Dateformat":dateincrementer};
          }
        this.startdate=this.dateList[0].Dateformat;
        this.getTimesheetDetailsByDate(this.startdate);
        // event properties are: event.date, event.jsdate, event.formatted and event.epoc
    }
     
    getTimesheetDetailsByDate(date){
        console.log("===>>>",date);
        this.timeSheetData.taskDate=date;
        let timeSheetUrl= this.apiBaseUrl+'/ESS/api/Master/getTimeSheetDetails/';
            let details = this.commonService.commonPostCall(timeSheetUrl,this.timeSheetData);
            details.subscribe((data) => {
            this.timeSheetList= data.json();
            console.log("===>>",this.timeSheetList[0]);
            },
            (error)=>{
                    this.auth.canActivate();
                    details = this.commonService.commonPostCall(timeSheetUrl,this.timeSheetData);
                    details.subscribe((data) => {
                    },
                    (error)=>{
                        console.log("error");
                    });
            });  
    }
}