import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';

import { LoginService, User } from  './login.service';
import { AppComponent } from '../app.component';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>login.component.ts</h1>
 * @author Gobinath J
 */

@Component({
    moduleId: module.id,
    selector: 'my-app',
    templateUrl: './login.component.html'
})
export   class   LoginComponent {

    options: DatePickerOptions;
    year:any; days:any; fullDay:string; month:string; day:any; monthShortNames:any;
    pwdIncorrect:boolean;
    public loginUser = new User('','');
    private toasterService: ToasterService;
    private invalid;

    constructor(private auth: AuthGuard,toasterService: ToasterService,private router: Router, private app: AppComponent, private loginService:LoginService) {
        this.options = new DatePickerOptions();
        this.toasterService = toasterService;
     }

     public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {
        this.app.isLoggedIn = false;
        var date1 = new Date();
        this.days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var monthShortNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        this.year = date1.getFullYear();
        this.fullDay = this.days[date1.getDay()];
        this.month = monthShortNames[date1.getMonth()];
        this.day = date1.getDate();
     }

    /* Method for Login*/
    login() {
       
       this.loginService.doLogin(this.loginUser).subscribe(data => {
            
            localStorage.setItem("access_token", data.access_token);
            localStorage.setItem("refresh_token", data.refresh_token);
          
            this.app.isLoggedIn = true;
            this.router.navigate(['/dashboard']);
      
        },
         err =>{ 
             console.log("error " , err);
             if(err.status==400 ){
                 this.pwdIncorrect=true;
             }
         }
       );
          
         
    }
}
