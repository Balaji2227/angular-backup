import { Injectable } from '@angular/core';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';

import { AppConfiguration } from '../app-config';

/**
 * <h1>login.service.ts</h1>
 * @author Gobinath J
 */

export class User {
  constructor(
    public userId: string,
    public password: string) { }
}

@Injectable()
export class LoginService {
  
  apiBaseUrl = AppConfiguration.apiBaseUrl;
  private _loginurl = this.apiBaseUrl+'/ESS/oauth/token';

   constructor(private _http: Http, private _router: Router, private commonService: CommonService){}
  
  /* Method for Login*/
  doLogin(user): Observable<any> {
    let headers = new Headers();
    localStorage.setItem("userId", user.userId);
    let queryParam = 'grant_type=password&username='+user.userId+'&password='+user.password;
    headers.append('Authorization', 'Basic bXktdHJ1c3RlZC1jbGllbnQ6c2VjcmV0');
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this._loginurl, queryParam, options)
      .map((response: Response) => <any> response.json())
      .do(data => console.log(JSON.stringify(data)));
  }

  /*This method is used check weather the login is alive or not*/
  checkCredentials(){
    if (localStorage.getItem("access_token") === null){
        this._router.navigate(['/login']);
        return false;
    }
    return true;
  }

  /* Method for Logout*/
  logout() {
    this._router.navigate(['/login']);
    let requrl= this.apiBaseUrl+'/ESS/log/logout';
    let logout = this.commonService.commonGetCall(requrl);
    logout.subscribe((data) => {
        
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("userId");

    },
    (error)=>{
        this._router.navigate(['/login']);
    });
  }
}