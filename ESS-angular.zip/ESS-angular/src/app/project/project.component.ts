import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { DomSanitizer } from '@angular/platform-browser';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
  

/**
 * <h1>project.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Project-Master',
  templateUrl: './project.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   ProjectMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    public projects;
    private settings;
    private projectName = '';
    private status = '';
    private dropdownList;
    private supervisors;
    private projectList;
    private empId;
    disabled: boolean = false;
    private listsup=[{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }];
    constructor(toasterService: ToasterService,private  loginService: LoginService, private commonService: CommonService,private auth : AuthGuard) {
        this.toasterService = toasterService;    
    }
    
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/';
        let dropdownDetails = this.commonService.commonGetCall(requrl1);
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
            var supervisorsData=[];
            if(this.dropdownList.empDet.length > 0){
              for(var i=0; i < this.dropdownList.empDet.length; i++) {
                supervisorsData[i]={ value: this.dropdownList.empDet[i].empId, title:this.dropdownList.empDet[i].employeeName+"("+this.dropdownList.empDet[i].empId+")"  };
              }
            }
            this.supervisors=supervisorsData;
            this.settings = {
                  mode: 'inline',
                  actions: {
                    add: true,
                    edit:true,
                    delete:false,
                    //position: 'right'
                    },
                  pager : {
                    display : true,
                    perPage:10
                  },
                  edit: {
                    confirmSave: true,
                    editButtonContent: '<span class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>',
                    saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
                    cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
                  },
                  add: {
                    confirmCreate: true,
                    addButtonContent: '<span class="btn btn-sm btn-primary">Add</span>',
                    createButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
                    cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
                  },
                  columns: {
                    idmaster:{
                      title: 'Id',
                      filter: false,
                      show: false,
                    },
                    empId: {
                      title: 'Project Name',
                      filter: false,
                      show:false
                    },
                    name: {
                      title: 'Project Name',
                      filter: false,
                    },
                    description: {
                      title: 'Description',
                      filter: false
                    },
                    empName: {
                      title: 'Manager',
                      filter: false,
                      editor: {
                      type: 'list',
                      config: {
                        list:this.supervisors,
                      },
                    },
              
                      
                    },
                    activeStatus: {
                      title: 'Status',
                      filter: false,
                    editor: {
                      type: 'list',
                      config: {
                        list: [{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }],
                      },
                    },
                    },
                  }
                };
         });
        let requrl= this.apiBaseUrl+'/ESS/api/Master/getProjectList/';
        let designationDetails = this.commonService.commonGetCall(requrl);
        designationDetails.subscribe((data) => {
            this.projects = data.json();
            
         },
        (error)=>{
                this.auth.canActivate();
                let dashboardDetails1 = this.commonService.commonGetCall(requrl);
                dashboardDetails1.subscribe((data) => {
                  this.projects = data.json();
              },
                (error)=>{
                    console.log("error");
                  
                });
        });

      

        
    }

    onCreateConfirm(event): void {
         if(this.disabled == false){
        let name = event.newData.name;
        let description = event.newData.description;
        let status = event.newData.activeStatus;
        let empId =event.newData.empName;
         
        if(name == '' || description == ''|| status == ''|| empId ==''){
          this.toasterService.pop('error', 'Fields Should not be empty');
          this.disabled= true;
          setTimeout(() =>{
          this.disabled = false; 
              }, 5000);
        }else{
          let createdData = {
            "name": name,
            "description": description,
            "activeStatus": status,
            "empId": empId,
          }
          let requrl= this.apiBaseUrl+'/ESS/api/Master/saveProject/';
          let project = this.commonService.commonPostCall(requrl,createdData);
          let checkName;
          project.subscribe((data) => {
            checkName=data._body ;
              if(checkName=='Failure'){
                  this.toasterService.pop('error', 'Project name already present'); 
                  this.disabled= true;
                  setTimeout(() =>{
                    this.disabled = false; 
                        }, 5000);
              }
                else{
                    this.toasterService.pop('success', 'Project saved successfully'); 
                    this.ngOnInit();
                }
          },
          (error)=>{
                   this.auth.canActivate();
                  project = this.commonService.commonPostCall(requrl,createdData);
                  project.subscribe((data) => {
                    checkName=data._body ;
                    if(checkName=='Failure'){
                        this.toasterService.pop('error', 'Project name already present'); 
                        this.disabled= true;
                        setTimeout(() =>{
                          this.disabled = false; 
                              }, 5000);
                    }
                      else{
                          this.toasterService.pop('success', 'Project saved successfully'); 
                            this.ngOnInit();
                      }
                  },
                  (error)=>{
                      console.log("error");
                       
                  });
          });
        }
    }
    }

    onEditConfirm(event): void {
      if(this.disabled == false){
      let idmaster = event.newData.idmaster;
      let name = event.newData.name;
      let description = event.newData.description;
      let status = event.newData.activeStatus;
      let empId =event.newData.empName;
        
      if(name == '' || description == ''|| status == '' || empId =='' ){
        this.toasterService.pop('error', 'Fields Should not be empty');
        this.disabled= true;
        setTimeout(() =>{
          this.disabled = false; 
              }, 5000);
      }else{
        let editedData = {
          "idmaster":idmaster,
          "name": name,
          "description": description,
          "activeStatus": status,
           "empId": empId
        }
        let requrl= this.apiBaseUrl+'/ESS/api/Master/updateProject/';
        let designation = this.commonService.commonPostCall(requrl,editedData);
        designation.subscribe((data) => {
          this.ngOnInit();
          this.toasterService.pop('success', 'Project updated successfully');
          this.disabled= true;
          setTimeout(() =>{
          this.disabled = false; 
              }, 5000);
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,editedData);
                designation.subscribe((data) => {
                  this.ngOnInit();
                  this.toasterService.pop('success', 'Project updated successfully');  
                  this.disabled= true;
                  setTimeout(() =>{
                    this.disabled = false; 
                        }, 5000);
                      },
                (error)=>{
                    console.log("error");
                });
        });
      }
    }
    }

    searchProject(): void{
      let searchData = {
        "name":this.projectName,
        "activeStatus": this.status
      }
      let requrl= this.apiBaseUrl+'/ESS/api/Master/searchProject/';
      let designation = this.commonService.commonPostCall(requrl,searchData);
      designation.subscribe((data) => {
        this.projects = data.json();
      },
      (error)=>{
              this.auth.canActivate();
              designation = this.commonService.commonPostCall(requrl,searchData);
              designation.subscribe((data) => {
                this.projects = data.json();
              },
              (error)=>{
                    console.log("error");
              });
      });
    }

 

    reset(): void{
      this.projectName = '';
      this.status = '';
      this.ngOnInit();
    }
}
