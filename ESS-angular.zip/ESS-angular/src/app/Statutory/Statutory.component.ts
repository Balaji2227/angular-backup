import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';


import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>onsiteList.component.ts</h1>
 * @author Mani
 */

@Component({
  selector: 'Statutory-Master',
  templateUrl: './Statutory.component.html',
})

export   class   statutory  {
    private data;  dateIn:Date;
    apiBaseUrl = AppConfiguration.apiBaseUrl;private months;private month;private year;private years;

    constructor(private auth: AuthGuard,private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,private excelService: ExcelService) { 
       this.excelService = excelService;
    }
    private selectOption;private   empWorkedDaysList=[];
     newMonths:any=[{id:"01",name:"January"},{id:"02",name:"February"},{id:"03",name:"March"},{id:"04",name:"April"}
      ,{id:"05",name:"May"},{id:"06",name:"June"},{id:"07",name:"July"},{id:"08",name:"Auguest"},{id:"09",name:"September"},{id:"10",name:"October"}
    ,{id:"11",name:"November"},{id:"12",name:"December"}]
     ngOnInit() {
        this.selectOption = [
           {
              label: " ",
              value: ""
            },
            {
              label:new Date().getFullYear()-3 ,
              value: new Date().getFullYear()-3
            }, {
              
              label: new Date().getFullYear()-2,
              value:new Date().getFullYear()-2
            }, {
              
              label: new Date().getFullYear()-1,
              value: new Date().getFullYear()-1
            }, {
              
              label: new Date().getFullYear(),
              value: new Date().getFullYear()
            }]
        
    
          
      }
    monthChange(value){
      this.month=this.months;
    }
    yearChange(value){
        this.year=this.years;
    }
     reset(): void{
       this.months= '';this.year = '';
      this.ngOnInit();
      
    }
   
 exportToExcel(){

    /* To get the drop down values */
  
    /** To Fetch attendance details based on Role */
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/employeeMonthlyReport/?month='+this.month +'&year='+this.year;
        let attendance = this.commonService.commonGetCall(requrl);
        attendance.subscribe((data) => {
             this.data = data.json();
             console.log("===>>>",this.data);
              if(this.data){

                let workedDaysMap = [,];
                 
                 var conditionCheck;
                 var newNumberList=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
                 var empId;
                 var empIdTemp;
                 var day;
                 var dayCount;
                 var monthlyReportDetails;
                 let daysInMonth = new Date(this.year, this.month, 0).getDate();

                 for(let i=0; i<this.data.length; i++){
                    var workedDaysList=[];
                    var newArrayList = [];
                    var workedDaysList1 = (this.data[i].timeInList.split(','))
                    workedDaysList1.forEach(element => {
                      console.log("element",element);
                      workedDaysList.push(parseInt(element));
                    });
                     var noOfDaysCount=0;
                    for(let l=1;l<=daysInMonth;l++){
                      var dayNo=l;
                     
                      if(workedDaysList.includes(dayNo)) {
                        newArrayList.push('Yes');
                        noOfDaysCount++;
                      }
                      else
                         newArrayList.push('No');
                      
                  }

                  if(daysInMonth == 28) {
                     newArrayList.push(' NA');
                     newArrayList.push('NA');
                     newArrayList.push('NA');
                  } else if(daysInMonth == 29){
                     newArrayList.push('NA');
                     newArrayList.push('NA');
                  } else if(daysInMonth == 30){
                       newArrayList.push('NA');
                  }
                      let objectval = {
                        EmpId  : this.data[i].empId,
                        EmpName  : this.data[i].empName,
                        Designation : this.data[i].designation,
                        NoOfDays:noOfDaysCount,
                        CL: this.data[i].cl,
                        SL: this.data[i].sl,
                        PL: this.data[i].pl,
                        CompOff: this.data[i].compOff,
                        LOP: this.data[i].lop,
                        MT: this.data[i].mt,
                        PT: this.data[i].pt,
                        1:newArrayList[0],
                        2:newArrayList[1],
                        3:newArrayList[2],
                        4:newArrayList[3],
                        5:newArrayList[4],
                        6:newArrayList[5],
                        7:newArrayList[6],
                        8:newArrayList[7],
                        9:newArrayList[8],
                        10:newArrayList[9],
                        11:newArrayList[10],
                        12:newArrayList[11],
                        13:newArrayList[12],
                        14:newArrayList[13],
                        15:newArrayList[14],
                        16:newArrayList[15],
                        17:newArrayList[16],
                        18:newArrayList[17],
                        19:newArrayList[18],
                        20:newArrayList[19],
                        21:newArrayList[20],
                        22:newArrayList[21],
                        23:newArrayList[22],
                        24:newArrayList[23],
                        25:newArrayList[24],
                        26:newArrayList[25],
                        27:newArrayList[26],
                        28:newArrayList[27],
                        29:newArrayList[28], 
                        30:newArrayList[29],
                        31:newArrayList[30],
                     }
                                           
                    this.empWorkedDaysList.push(objectval);
                 }
                  console.log('this.empWorkedDaysList --- ',this.empWorkedDaysList);
                  this.excelService.exportAsExcelFile1(this.empWorkedDaysList, 'LeaveDetails');
                  this.empWorkedDaysList=[]
                  
            } 
      }, (error)=>{
                this.auth.canActivate();
                let attendance1 = this.commonService.commonGetCall(requrl);
                attendance1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                    console.log("error");
                });
         })
         
    }

}
    
