import { Component } from '@angular/core';
import { Router,ActivatedRoute, Params  }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { HolidayEdit } from '../holiday/holidayEdit.component';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>calendar.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Holiday-Master',
  templateUrl: './holidayMaster.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   HolidayMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private idmaster; private msg;private data;private showDialog;private holidayDetails;private year;private reason;private holidayDate;
    private choices = [];
    private day;

    constructor(private loginService : LoginService,private toasterService : ToasterService,private commonService: CommonService,private router: Router,private activatedRoute: ActivatedRoute,private auth : AuthGuard) {
           this.activatedRoute.params.subscribe((params: Params) => {
                this.idmaster = params['idmaster'];
                });
             
              this.toasterService = toasterService; 
       
        
    }
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    settings = {
        mode: 'inline',
        hideSubHeader: true,
        actions: {
            add: false,
            edit:false,
            delete:false,
            custom: [{ title: `<span class="btn btn-sm btn-success glyphicon glyphicon-eye-open"></span>` }],
           
            position: 'right'
        },
        pager : {
            display : true,
            perPage:10
        },
        columns: {
            year: {
                title: 'Year',
                filter: false
            },
            noOfHolidays: {
                title: 'No of Holidays',
                filter: false
            },
            
            idmaster: {
                title: 'Id',
                filter: false,
                show:false,
                valuePrepareFunction: (cell: any, row: any) =>{
                   return row.idmaster.idmaster;
                  }
            },
            edits: {
                title: 'Edit' ,
                filter: false,
                type: 'custom',
                valuePrepareFunction: (cell, row) => row, 
                renderComponent: HolidayEdit,
               
            }
        }
    };
 

    ngOnInit() {
        let requrl= this.apiBaseUrl+'/ESS/api/Master/getYearlyLeaves/'+this.idmaster;
        let holidayMaster = this.commonService.commonGetCall(requrl);
        holidayMaster.subscribe((data) => {
            this.data = data.json();
          
        },
        (error)=>{

                 this.auth.canActivate();

                holidayMaster = this.commonService.commonGetCall(requrl);
                holidayMaster.subscribe((data) => {
                this.data = data.json();
                },
                (error)=>{
                     console.log("error");
                });
          
        });



    }

    route123(event): void{
      
      let reqUrl = this.apiBaseUrl+'/ESS/api/Master/getHolidayDetails/?idmaster= '+this.idmaster + '&year='+event.data.year;
      let ListOfHolidays = this.commonService.commonGetCall(reqUrl);
      ListOfHolidays.subscribe((data) => {
        this.holidayDetails=data.json(); 
        console.log("this.holidayDetails" , this.holidayDetails);
        this.choices=[];
        for(let i=0;i<this.holidayDetails.length;i++){
            
            this.year= this.holidayDetails[i].year;
            
            this.holidayDate=new Date(this.holidayDetails[i].holidayDate);
            
            this.reason=this.holidayDetails[i].reason;

            this.day=this.holidayDetails[i].day;
           
            this.choices.push({holidayDate:this.holidayDate ,year:this.year,reason: this.reason,day:this.day});
           
        }
       },
      (error)=>{
            
                   this.auth.canActivate();
                   ListOfHolidays = this.commonService.commonGetCall(reqUrl);
                   ListOfHolidays.subscribe((data) => {
                    this.holidayDetails=data.json(); 
                    this.choices=[];
                    for(let i=0;i<this.holidayDetails.length;i++){
                        
                        this.year= this.holidayDetails[i].year;
                        
                        this.holidayDate=new Date(this.holidayDetails[i].holidayDate);
                        
                        this.reason=this.holidayDetails[i].reason;
                    
                        this.choices.push({holidayDate:this.holidayDate ,year:this.year,reason: this.reason});
                    }
                   },
                    (error)=>{
                        console.log("error");

                      //  this.loginService.logout();
                    });
              
            });
            this.showDialog = true;
            
    }

    changeRoute(routeValue): void{
       
        this.router.navigate([routeValue, this.idmaster]);
    }
}
