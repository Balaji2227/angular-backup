import { Component, Input, OnInit } from '@angular/core';
import { Router,ActivatedRoute, Params  }  from '@angular/router';
import {IMyOptions,IMyDateModel} from 'mydatepicker';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { NgForm }    from '@angular/forms';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';

@Component({
  selector: 'editor',
  templateUrl: './holidaysYearWiseEdit.component.html'
})
export class HolidaysYearWiseEdit implements OnInit {
    public value: HolidaysYearWiseEdit;
    private selctedDate;
    private idmaster; 
    private year;
    private years;
    private data;
    private days;
    private submitAttempt ;
    public myDatePickerOptions:IMyOptions;
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private choices = [{indexValue:0,date: new Date(),days:'',holidayName:'',hiddenDate:""}]; 

    constructor(private toasterService : ToasterService,private commonService: CommonService,private router: Router,private activatedRoute: ActivatedRoute) { 
        this.activatedRoute.params.subscribe((params: Params) => {
            this.idmaster = params['idmaster'];
        });
        this.activatedRoute.params.subscribe((params: Params) => {
             this.year = params['year'];
        });
        this.toasterService = toasterService; 
   }

    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
        showCloseButton: true, 
        tapToDismiss: false,
        timeout: 0
    });

    ngOnInit() {
        this.year=this.year;
        let reqUrl =this.apiBaseUrl+'/ESS/api/Master/getYearlyHolidaysEdit/?idmaster= '+this.idmaster + '&year='+this.year;
        let holidayEdit = this.commonService.commonGetCall(reqUrl);
        holidayEdit.subscribe((data) => {
            this.data = data.json();
            for(let i=0;i<this.data.length;i++){
                let date = new Date(this.data[i].holidayDate);
                this.selctedDate = { date: { year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate() } };
                let days = (this.data[i].day);
                let holidayName = (this.data[i].reason);
                this.choices[i].days=days;
                this.choices[i].hiddenDate=date.getTime().toString();
                this.choices[i].holidayName=holidayName;
                this.choices[i].date=  this.selctedDate;
                this.addNewChoice(i); 
            }
            this.removeChoice();
            },
            (error)=>{
                holidayEdit = this.commonService.commonGetCall(reqUrl);
                holidayEdit.subscribe((data) => {
                    this.data = data.json();
                    for(let i=0;i<this.data.length;i++){
                        let date = new Date(this.data[i].holidayDate);
                        this.selctedDate = { date: { year: date.getFullYear(), month: date.getMonth(), day: date.getDate() } };
                        let days = (this.data[i].day);
                        let holidayName = (this.data[i].reason);
                        this.choices[i].days=days;
                        this.choices[i].hiddenDate=this.selctedDate;
                        this.choices[i].holidayName=holidayName;
                        this.choices[i].date=  this.selctedDate;
                        this.addNewChoice(i); 
                    }
                    this.removeChoice();
                },
                (error)=>{
                    console.log("error");

                });
            });

         let minyear= this.year-1;
         let maxyear = parseInt (this.year)+1;

        this.myDatePickerOptions = {
         
            dateFormat: 'dd/mm/yyyy',
            showClearDateBtn :false,
            editableDateField : false,
            disableUntil : {year: minyear , month: 12, day: 31},
            disableSince : {year: maxyear, month: 1, day: 1},
            yearSelector:true
            
        };

    }

    onStartDateChanged(event: IMyDateModel,index) {
        let day = new Date(event.jsdate.getDay()).valueOf();
        let fromDateFormat=event.date.year+"/"+event.date.month+"/"+event.date.day;
        let datefinal=new Date(fromDateFormat).getTime().toString();
        var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        this.days=days[day];
        let i=0;
        var flag=false; 
     
      
        if(this.choices.length > 1) {
            let l = this.choices.length;

            for(i = 1; i< l; i++){
                
                
                if(datefinal == this.choices[i-1].hiddenDate){
                  
                    flag=true;
                }
              }
        }
        else{
                  
                this.choices[index].days=this.days;
                this.choices[index].hiddenDate=datefinal;
        }

         

        if(flag==true){
             this.toasterService.pop('error', 'Holiday date is already present.'); 
        }
        else{
                this.choices[index].days=this.days;
                this.choices[index].hiddenDate=datefinal;
        }
         
    }
    
    addNewChoice(index){
      this.choices.push({indexValue:index+1,date:new Date()  ,days:'',holidayName:'',hiddenDate:""});
    }

    removeChoice(){
        var lastItem = this.choices.length - 1;
        this.choices.splice(lastItem);
    }

    removeChoices(index){
        this.choices.splice(index,1);
    }

    SaveDetails(myForm: NgForm): void {
        let saveData;
        var listObj = [];
        let idmaster;
        this.submitAttempt = true;
        let last;
        let formControls = myForm.controls;
        for(let i =0; i<this.choices.length;i++){
            saveData = {
                idmaster : {
                         "idmaster": this.idmaster
                    },
                "holidayDate":this.choices[i].hiddenDate,
                "reason":this.choices[i].holidayName,
                "year":this.year ,
                "day":this.choices[i].days
            }
            listObj.push(saveData);

        }
          
        let reqUrl =this.apiBaseUrl+'/ESS/api/Master/editHoliday/';
        let holidayEdit = this.commonService.commonPostCall(reqUrl,listObj);
        let checkName;
        holidayEdit.subscribe((data) => {
             this.router.navigate(['/holiday',this.idmaster]);
             this.toasterService.pop('success', 'Saved Successfully'); 
                    
        },  (error)=>{
                        holidayEdit = this.commonService.commonPostCall(reqUrl,this.choices);
                        holidayEdit.subscribe((data) => {
                            checkName=data._body ;
                            if(checkName=='Failure'){
                             }
                            else{
                                   this.router.navigate(['/holiday',this.idmaster]);
                                    this.toasterService.pop('success', 'Holiday updated successfully'); 
                            }
                             
                          },
                        (error)=>{
                           console.log("error");
                        });
                   
           
        });

    }
    eventHandler(event: any){
     const pattern = /^[a-zA-Z\s]*$/;
        let inputChar = String.fromCharCode(event.charCode);

            if (!pattern.test(inputChar) && event.charCode != '0') {
                event.preventDefault();
            }
     }
    changeRoute(routeValue): void{
        this.router.navigate([routeValue,this.idmaster]);
    }

}