import { Component, Input, OnInit } from '@angular/core';
import { Router,ActivatedRoute, Params  }  from '@angular/router';

@Component({
  selector: 'editor',
  template: `<span (click)="changeRoute('/holidaysYearWiseEdit')"  routerLinkActive="active"  class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>`,
})
export class HolidayEdit implements OnInit {

  public value: HolidayEdit;
  private idmaster; private year;
  constructor(private router: Router) {  }
    ngOnInit() {
        this.idmaster=this.value.idmaster.idmaster;
        this.year=this.value.year;
          
    }
    changeRoute(routeValue): void{
        this.router.navigate([routeValue,this.idmaster,this.year]);
    }



}