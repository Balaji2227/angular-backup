import { Component } from '@angular/core';
import { Router }  from '@angular/router';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>holidaylist.component.ts</h1>
 * @author Gobinath J
 */

@Component({
    moduleId: module.id,
    selector: 'Holiday-List',
    templateUrl: './holidaylist.component.html'
})

export   class   HolidayList  {

    constructor( private commonService: CommonService,private auth : AuthGuard ) { }
    holidayType :any;
    date: any;
    year: any;
    private data;
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private holidays=[];

    ngOnInit() {
        let date;
        let month;
        let reqUrl =this.apiBaseUrl+'/ESS/api/emplyee/getEmpHolidayDates/';
        let holidayEdit = this.commonService.commonGetCall(reqUrl);
        holidayEdit.subscribe((data) => {
            this.data=data.json();
            this.holidayType=this.data[0].description;
            for(let i =0; i<this.data.length;i++){
                date= new Date(this.data[i].holidayDate ).getDate().toString();
                month= new Date(this.data[i].holidayDate ).getMonth();
                var months = ['JAN','FEB','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
                this.holidays.push({day:this.data[i].day,date:date,month:months[month],reason:this.data[i].reason});
            }
        },
        (error)=>{
          
                this.auth.canActivate();
                holidayEdit = this.commonService.commonGetCall(reqUrl);
                holidayEdit.subscribe((data) => {
                    this.data=data.json();
                    this.holidayType=this.data[0].description;
                    for(let i =1; i<this.data.length;i++){
                        date= new Date(this.data[i].holidayDate ).getDate().toString();
                        month= new Date(this.data[i].holidayDate ).getMonth();
                        var months = ['JAN','FEB','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];
                        this.holidays.push({day:this.data[i].day,date:date,month:months[month],reason:this.data[i].reason});
                       
                    }            

                },
                (error)=>{
                         console.log("error");
                });
          
        });
        this.date = new Date();
        this.year = this.date.getFullYear();
        }

    }
