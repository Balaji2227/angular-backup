import { Component } from '@angular/core';
import { Router,ActivatedRoute, Params  }  from '@angular/router';
import {IMyOptions,IMyDateModel} from 'mydatepicker';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AuthGuard } from '../gaurds/auth-guard.service';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';


/**
 * <h1>calendar.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'key-up4',
  templateUrl: './Addholiday.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   AddHoliday  {
     private date;
     private day;
     private days;
     private holidayName;
     private indexValue=0;
     private idmaster : number;
     private years;
     private yearValue;
     private hiddenDate;
     private submitAttempt;
     private showForm;
     private data;
     private remove=false;
     private isvalue=false;
     private ok=false;
     public myDatePickerOptions:IMyOptions;
    disabled: boolean = false;
    
     private choices = [{indexValue:0,date: "",days:'',holidayName:'',hiddenDate:""}];
     apiBaseUrl = AppConfiguration.apiBaseUrl;
     constructor(private toasterService : ToasterService,private  loginService: LoginService, private commonService: CommonService,private activatedRoute: ActivatedRoute,private router: Router,private auth : AuthGuard) {
        this.activatedRoute.params.subscribe((params: Params) => {
                this.idmaster = params['idmaster'];
                });
      this.toasterService = toasterService; 
     }
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });
        
    ngOnInit() {
       var demo =[];
        var years =[];
       let requrl= this.apiBaseUrl+'/ESS/api/Master/getYearlyLeaves/'+this.idmaster;
        let holidayMaster = this.commonService.commonGetCall(requrl);
        let year=new Date().getFullYear();
        years.push(year,year+1,year+2);
        holidayMaster.subscribe((data) => {
            this.data = data.json();
            for(let i=0;i<this.data.length;i++){

                if(this.data[i].year == year)
                {
                     
                    years.splice(0,1);
                }
                 if(this.data[i].year == year+1)
                {
                     
                    years.splice(0,1);
                }
                 if(this.data[i].year == year+2)
                {
                    
                    years.splice(0,1);
                }
             }
            
          this.years=years;
        },
        (error)=>{
               this.auth.canActivate();
             holidayMaster.subscribe((data) => {
            this.data = data.json();
            for(let i=0;i<this.data.length;i++){

                if(this.data[i].year == year)
                {
                     
                    years.splice(0,1);
                }
                 if(this.data[i].year == year+1)
                {
                     
                    years.splice(0,1);
                }
                 if(this.data[i].year == year+2)
                {
                    
                    years.splice(0,1);
                }
             }
            
          this.years=years;
        },
        (error)=>{
            console.log("error");
        });
            
        });
         
    }      
    
 

    onChange($event){
         this.yearValue=$event.target.value;
        let minyear=this.yearValue-1;
         let maxyear = parseInt($event.target.value)+1;
        
         this.myDatePickerOptions = {
         
            dateFormat: 'dd/mm/yyyy',
            showClearDateBtn :false,
            editableDateField : false,
            disableUntil : {year: minyear , month: 12, day: 31},
            disableSince : {year: maxyear, month: 1, day: 1},
            yearSelector:true
            
        };
        this.showForm=true;
         if(this.yearValue==""){
             
             this.showForm=false;
         }else{
              this.disabled = true;
         }
           
       }
  
     onStartDateChanged(event: IMyDateModel,index) {
        let day = new Date(event.jsdate.getDay()).valueOf();
        let fromDateFormat=event.date.year+"/"+event.date.month+"/"+event.date.day;
        let datefinal=new Date(fromDateFormat).getTime().toString();
        var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        this.days=days[day];
        let i=0;
        var flag=false; 
        if(this.choices.length > 1) {
            let l = this.choices.length;

            for(i = 1; i< l; i++){
                if(datefinal == this.choices[i-1].hiddenDate){
                    flag=true;
                }
              }
        }
        else{
                 
                this.choices[index].days=this.days;
                this.choices[index].hiddenDate=datefinal;
        }
        if(flag==true){
             this.toasterService.pop('error', 'Holiday Date is already present.'); 
        }
        else{
                this.choices[index].days=this.days;
                this.choices[index].hiddenDate=datefinal;
        }
            this.isvalue=true;
        
    }
    addNewChoice(index){
          
      this.choices.push({indexValue:index+1,date:"" ,days:'',holidayName:'',hiddenDate:""});
     }

    removeChoice(){
        var lastItem = this.choices.length - 1;
        this.choices.splice(lastItem);
     }

     removeChoices(index){
         this.choices.splice(index,1);
     }

     eventHandler(event: any){
     const pattern = /^[a-zA-Z\s]*$/;
        let inputChar = String.fromCharCode(event.charCode);

            if (!pattern.test(inputChar) && event.charCode != '0') {
                event.preventDefault();
            }
     }
    
    
    SaveDetails(){
        let saveData;
        var listObj = [];
        let idmaster;
        this.submitAttempt = true;
        let last;
        
        for(let i =0; i<this.choices.length;i++){
               saveData = {
                    idmaster : {
                         "idmaster": this.idmaster
                    },
                    "holidayDate":this.choices[i].hiddenDate,
                    "reason":this.choices[i].holidayName,
                    "year":this.yearValue,
                    "day":this.choices[i].days
                  }
                
                listObj.push(saveData);
                
              }
               last = this.choices[this.choices.length-1];
               if(last.days =="") {
                 this.toasterService.pop('error', 'Please select all fields.'); 
                }
               else{
                   if(saveData.reason && saveData.holidayDate){
                    let requrl= this.apiBaseUrl+'/ESS/api/Master/saveHoliday/';
                    let addHoliday = this.commonService.commonPostCall(requrl,listObj);
                    let checkName;
                    addHoliday.subscribe((data) => {
                          checkName=data._body ;
                            if(checkName=='Failure'){
                                
                                
                            }
                            else{
                                   this.router.navigate(['/holiday',this.idmaster]);
                                    this.toasterService.pop('success', 'Holiday saved successfully'); 
                            }
                 },
                (error)=>{
                        this.auth.canActivate();
                        let requrl= this.apiBaseUrl+'/ESS/api/Master/saveHoliday/';
                        let addHoliday = this.commonService.commonPostCall(requrl,listObj);
                        addHoliday = this.commonService.commonPostCall(requrl,this.choices);
                        addHoliday.subscribe((data) => {
                         checkName=data._body ;
                            if(checkName=='Failure'){
                            }
                            else{
                                this.router.navigate(['/holiday',this.idmaster]);
                                this.toasterService.pop('success', 'Holiday saved successfully'); 
                            }
                             
                          },
                        (error)=>{
                           console.log("error");
                        });
                  
            });
        }
     }
    }

    changeRoute(routeValue): void{
       
        this.router.navigate([routeValue,this.idmaster]);
    }
              
}
