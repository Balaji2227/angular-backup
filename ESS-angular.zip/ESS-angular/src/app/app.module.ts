import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { Operator } from 'rxjs/Operator';
import { Observable } from 'rxjs/Observable';
import {APP_BASE_HREF} from '@angular/common';
import { Ng2DatetimePickerModule } from 'ng2-datetime-picker';
import {CalendarModule} from 'primeng/primeng';
import {AccordionModule} from "ngx-accordion";
import {RouterModule} from '@angular/router';
import { ChartModule }  from 'angular2-highcharts';
import { BrowserAnimationsModule  } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { MyDatePickerModule } from 'mydatepicker';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent }         from './app.component';
import { LoginService } from  './login/login.service';
import { LoginComponent }      from './login/login.component';
import { DashboardComponent }      from './dashboard/dashboard.component';
import { AppRoutingModule }     from './app-routing.module';
import { AuthGuard }            from './gaurds/auth-guard.service';
import { AttendanceAuth }  from './attendance/attendanceauth.component';
import { AttendanceDetails }  from './attendance/attendancedetails.component';
import { AttendanceSummary }  from './attendance/attensummary.component';
import { LeaveAuth }  from './leave/leaveauthorization.component';
import { LeaveDetails }  from './leave/leavedetails.component';
import { HolidayList }  from './holiday/holidaylist.component';
import { PhoneExtn }  from './phone/phoneextn.component';
import { DialogComponent } from './dialog.component';
import { CommonService } from './common.service';
import { DesignationMaster } from './designation/designation.component';
import { ProjectMaster } from './project/project.component';
import { CalendarMaster } from './calendar/calendar.component';
import { HolidayMaster } from './holiday/holidayMaster.component';
import { AddHoliday } from './holiday/addholiday.component';
import { EmployeeList } from './employee/employeeList.component';
import { EditEmployeeMaster } from './employee/editEmployee.component';
import { ExcelService } from './excel.service';
import { HolidayEdit } from './holiday/holidayEdit.component';
import { HolidaysYearWiseEdit } from './holiday/holidaysYearWiseEdit.component';
import{ CreateEmployeeMaster } from './employee/createEmployee.component';
import { OnsiteList } from './onsite/onsiteList.component';
import { AddOnsiteMaster } from './onsite/addOnsite.component';
import { LeaveSetting }  from './leave/leavesetting.component';
import { customeditrender }  from './attendance/customeditrender.component';
import { customdayoutrender }  from './attendance/customdayoutrender.component';
import { customtimeoutrender }  from './attendance/customtimeoutrender.component';
import { customdayinrender }  from './attendance/customdayinrender.component';
import { NKDatetimeModule } from 'ng2-datetime/ng2-datetime';
import { WorkFromHomeList } from './workfromhome/workfromhomeList.component';
import { AddWorkFromHome } from './workfromhome/addWorkFromHome.component';
import { EditOnsiteMaster } from './onsite/editOnsite.component';
import { EditWorkfromhomeMaster } from './workfromhome/editWorkfromhome.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import * as $ from 'jquery';
export {NKDatetimeModule} //export the ng2 module from the vendor.ts file.
import {SelectModule} from 'ng2-select';
import { customdropdown }  from './attendance/customdropdown.component';
import { customremarktextbox }  from './attendance/customremarktextbox.component';
import { statutory }  from './Statutory/Statutory.component';

import 'jquery/dist/jquery.min.js'
import 'bootstrap/dist/js/bootstrap.js';
import 'bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js';
import 'bootstrap-timepicker/js/bootstrap-timepicker.min.js';
import 'bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css';
import 'bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js';
import { MyFilterPipe }  from './leave/leavesettingfilter';
import { phoneExtnMaster } from './phone/phoneExtnMaster.component'; 
import{ BirthdayComponent } from './birthday/birthday.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { LeaveBalance }  from './leave/leavebalance.component';
import { CustomCLrender }  from './leave/customCLrender.component';
import { CustomSLrender }  from './leave/customSLrender.component';
import { CustomPLrender }  from './leave/customPLrender.component';
import { CustomCompOffrender }  from './leave/customCompOffrender.component';
import { ActivityMaster }  from './activity/activity.component';
import { MonthlyReport }  from './attendance/attendancereport.component';
import { Customremarkrender }  from './leave/customremarkrender.component';
import { Customreasonrender }  from './leave/customreasonrender.component';
import { Customattremarkrender }  from './attendance/customattremarkrender.component';
import { TimeSheetMaster } from './timeSheet/timeSheet.component';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

/**
 * <h1>app.module.ts</h1>
 * @author Gobinath J
 */

@NgModule({
  imports: [
    BrowserModule,RouterModule, FormsModule,ReactiveFormsModule, AppRoutingModule, Ng2DatetimePickerModule, CalendarModule, AccordionModule, 
    BrowserAnimationsModule , HttpModule, Ng2SmartTableModule, ToasterModule, MyDatePickerModule,NKDatetimeModule,AngularMultiSelectModule
    ,SelectModule,PerfectScrollbarModule
  ],
  declarations: [
    AppComponent, LoginComponent, DashboardComponent,  AttendanceAuth, AttendanceDetails, 
    AttendanceSummary, LeaveAuth,  LeaveDetails, HolidayList, PhoneExtn, DialogComponent, DesignationMaster,
    ProjectMaster, CalendarMaster, HolidayMaster, AddHoliday, EmployeeList, EditEmployeeMaster,CreateEmployeeMaster,
    LeaveSetting,AddOnsiteMaster,OnsiteList,customtimeoutrender,customdayinrender, customdayoutrender,
    customeditrender,HolidayEdit,HolidaysYearWiseEdit,EditOnsiteMaster,WorkFromHomeList,AddWorkFromHome,EditWorkfromhomeMaster,MyFilterPipe,
    phoneExtnMaster,BirthdayComponent,customdropdown,customremarktextbox,
	LeaveBalance,CustomCLrender,CustomSLrender,CustomPLrender,CustomCompOffrender,ActivityMaster,statutory,MonthlyReport,Customremarkrender,Customreasonrender,Customattremarkrender,TimeSheetMaster
  ],
   entryComponents: [customeditrender,customtimeoutrender,customdayinrender,customdayoutrender,HolidayEdit,customdropdown,customremarktextbox,CustomCLrender,CustomSLrender,CustomPLrender,CustomCompOffrender,Customremarkrender,Customreasonrender,Customattremarkrender],
  providers: [
    {provide: APP_BASE_HREF, useValue : '#' },
    AuthGuard, LoginService, CommonService, ExcelService
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
