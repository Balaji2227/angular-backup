import { Component, OnInit } from '@angular/core';
import { trigger, state, style, transition, animate} from '@angular/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { Router,ActivatedRoute }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AuthGuard } from '../gaurds/auth-guard.service';

@Component({
  selector: 'birthday-Master',
  templateUrl: './birthday.component.html',
  styleUrls: ['./birthday.component.css'],
})
export class BirthdayComponent implements OnInit {
    apiBaseUrl = AppConfiguration.apiBaseUrl; private ViewEmployeeDetail;private toasterService: ToasterService;
    private employeeList;private birthdayList; 
   public incrementor:number=0; 
   private todaysDate:number;
   private dateheader:String;
   constructor(private auth: AuthGuard,private _router: Router, 
        private commonService: CommonService,private route: ActivatedRoute,toasterService: ToasterService) { 
            this.toasterService = toasterService; 
        }

  ngOnInit() {
   var incrementor=0;
   var theDate = Date.now();
    this.todaysDate=theDate;
    let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getEmployeeBirthdayDetails/';
        let employeeDetails = this.commonService.commonGetCall(requrl);
        employeeDetails.subscribe((data) => {
            this.employeeList = data.json();
            this.birthdayList=this.EmployeeBirthdayDetails(this.employeeList,this.todaysDate);
        },
        (error)=>{
                this.auth.canActivate();
                let employeeDetails1 = this.commonService.commonGetCall(requrl);
                employeeDetails1.subscribe((data) => {
                this.employeeList = data.json();
                },
                (error)=>{
                  console.log("error");
                });
            
        });
        
  }
     
       previousBirthDayList(){
            this.todaysDate=this.todaysDate-86400000;
            this.birthdayList=[];
            this.birthdayList= this.EmployeeBirthdayDetails(this.employeeList, this.todaysDate);
       }  
       upcomingBirthDayList(){
         this.todaysDate=this.todaysDate+86400000;
         this.birthdayList=[];
        this.birthdayList= this.EmployeeBirthdayDetails(this.employeeList,this.todaysDate);
       }   

       EmployeeBirthdayDetails(empList,birthdayDate) {
            var dirthdayData=[];
            var date= new Date(birthdayDate);
            this.dateheader= date.getDate()+'/'+(date.getMonth() +1)+'/'+date.getFullYear();
            var j=0;    
            var imgURL;
            var imgBase64="data:image/png;base64,";
             if(empList.length > 0){
                  for(var i=0; i < empList.length ; i++) {
                      var dt = new Date(empList[i].dob);
                      if( date.getDate() == dt.getDate() && dt.getMonth() == date.getMonth() ){
                          if(empList[i].profileImage==null){
                              imgURL="assets/images/ext-profile.png";
                          }else{
                              imgURL = imgBase64 + empList[i].profileImage;
                          }
                         dirthdayData[j]={"empId":empList[i].empId,"employeeName":empList[i].employeeName,"designation":empList[i].designation,"profileImage":imgURL} 
                         j++;
                      }
                  }
           }
                 return dirthdayData;
        }   
}