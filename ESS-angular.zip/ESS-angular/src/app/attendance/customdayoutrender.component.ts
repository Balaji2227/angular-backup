

import { Component,  Input,Output, EventEmitter,OnInit } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';


@Component({
  selector: 'advanced-example-custom-editor',
  template: '<span class="atten-auth-addon"><datetime  [timepicker]="false"  [datepicker]="datepickerOpts" (ngModelChange)="handleDateOutChange($event)"  [(ngModel)]="date2"></datetime></span>',
})
export class customdayoutrender implements OnInit {
    date2: Date;
    private timeOut;private timeIn;
    @Input() dateFrom: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    @Output() sendInformationTOANI: EventEmitter<any> = new EventEmitter();
   public value: customdayoutrender;
 constructor() {  }
ngOnInit() {
    if(this.value.timeOut == null){
      
      this.date2=new Date(this.value.timeIn);
    }
    else{
      
       this.date2 =  new Date(this.value.timeOut);
       
    }
     
}

handleDateOutChange(dateFrom: Date){

     this.dateFrom = dateFrom;
     this.save.emit(this.dateFrom);

}
datepickerOpts = {
    
    autoclose: true,
    todayBtn: 'linked',
    todayHighlight: true,
    assumeNearbyYear: true,
    format: 'dd/mm/yy'
}


}
