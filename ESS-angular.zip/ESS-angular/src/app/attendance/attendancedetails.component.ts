import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import { Customattremarkrender }  from '../attendance/customattremarkrender.component';

/**
 * <h1>attendancedetails.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Attendance-Details',
  templateUrl: './attendancedetails.component.html',
  styleUrls:  ['./attendancedetails.component.css']

})

export   class   AttendanceDetails  {

    private selected; private settings; private employee:any;  private toDate:any;
    private authorised; private status;private employees;private data;private employeeId;private employeeName;
    private category: Array<any> = []; private searchBySupervisor; private bySupervisorList;
    apiBaseUrl = AppConfiguration.apiBaseUrl;public defaultDate:Date =new Date();private noToDateYear;private noToDateMonth;private noToDateDay;
    private fromDate:any={ date: { year: this.defaultDate.getFullYear(), month:this.defaultDate.getMonth()+1, day: this.defaultDate.getDate() } };      
    
    constructor(private auth: AuthGuard,private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,private excelService: ExcelService) { 
       this.excelService = excelService;
    }
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    ngOnInit() {
      this.searchAttDetail();
      if(this.app.role == 'ROLE_ADMIN' || this.app.role == 'ROLE_SUPERVISOR')
      {
        this.settings = {
          //selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
          },
          pager : {
            display : true,
            perPage:10
          },
          columns: {
            empId: {
              title: 'Emp Id',
              filter: false,
              editable:false
            },
            empName: {
              title: 'Emp Name',
              filter: false,
              editable:false
            },
            timeIn: {
              title: 'Day In',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell){
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
                    var date = parsedDate.getDate();
                    this.noToDateYear=parsedDate;
                    this.noToDateMonth=month;
                    this.noToDateDay=date;
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
                  else{
                    return '';
                  }
                }
                
            },
            timeIn1: {
              title: 'Time In',
              filter: false,
               valuePrepareFunction: (cell: any, row: any) =>{
                 if(cell){
                    let parsedDate = new Date(cell);
                    return parsedDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
                    }
                  else{
                    return '';
                  }
                  }
            },
            timeOut: {
              title: 'Day Out',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell){
                    let parsedDate = new Date(cell);
                   
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                }
                  else{
                     this.noToDateYear;
                    this.noToDateMonth;
                    this.noToDateDay;
                    return ( this.noToDateDay < 10 ? '0' +  this.noToDateDay :  this.noToDateDay)+"/"+( this.noToDateMonth < 10 ? '0' + this.noToDateMonth : this.noToDateMonth)+"/"+this.noToDateYear.getFullYear();
                  
                  }
                }
            },
            timeOut1: {
              title: 'Time Out',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell){
                    let parsedDate = new Date(cell);
                    return parsedDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
                  }
                  else{
                    return '00:00' ;
                }
              }
            },
             hoursWorked: {
              title: 'Addn Hours',
              filter: false
            }, 
            hoursWithAdd: {
              title: 'Hours',
              filter: false
            },
            
            status: {
              title: 'Status',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell=='NULL'){
                    return 'Present' ;
                  }
                  else{
                    return cell;
                }
              }
            },
            authorised: {
              title: 'Authorized',
              filter: false
            },
            authorisedBy: {
              title: 'Authorized By',
              filter: false
            },
            remarks: {
                title: 'Remark',
              filter: false,
              type: 'custom',
              renderComponent: Customattremarkrender,
               valuePrepareFunction: (cell, row) => row,
               onComponentInitFunction(instance) {
                   instance.save.subscribe(event => {
                          let compOff = event;
                          instance.rowData.compOff =compOff;
                          
                  });
               }
            }
          }
        };
      }
      else{
          this.settings = {
          //selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
          },
          pager : {
            display : true,
            perPage:10
          },
          columns: {
            empId: {
              title: 'Emp Id',
              filter: false,
              show: false
            },
          timeIn: {
              title: 'Day In',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                  }
            },
            timeIn1: {
              title: 'Time In',
              filter: false,
               valuePrepareFunction: (cell: any, row: any) =>{
                    let parsedDate = new Date(cell);
                    return parsedDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
                  }
            },
            timeOut: {
              title: 'Day Out',
              filter: false,
              editable:false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell){
                    let parsedDate = new Date(cell);
                    var month = parsedDate.getMonth() + 1;
	                  var date = parsedDate.getDate();
                    return (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+parsedDate.getFullYear();
                }
                  else{
                    this.noToDateYear;
                    this.noToDateMonth;
                    this.noToDateDay;
                    return ( this.noToDateDay < 10 ? '0' +  this.noToDateDay :  this.noToDateDay)+"/"+( this.noToDateMonth < 10 ? '0' + this.noToDateMonth : this.noToDateMonth)+"/"+this.noToDateYear.getFullYear();
                  
                  }
              }
            },
            timeOut1: {
              title: 'Time Out',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell){
                    let parsedDate = new Date(cell);
                    return parsedDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', hour12: false});
                  }
                  else{
                    return '00:00' ;
                }
              }
            },
             hoursWorked: {
              title: 'Addn Hours',
              filter: false
            },
            hoursWithAdd: {
              title: 'Hours',
              filter: false
            },
             
            status: {
              title: 'Status',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                if(cell=='NULL'){
                    return 'Present' ;
                  }
                  else{
                    return cell;
                }
              }
            },
              authorised: {
              title: 'Authorized',
              filter: false
            },
            authorisedBy: {
              title: 'Authorized By',
              filter: false
            },
            remarks: {
              title: 'Remark',
              filter: false
            }
          }
        };
      }
        /** Assigning Employee Names in drop-down */
        let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employee=data.json();
            if(this.employee){
              for(let i=0; i<this.employee.length; i++){
                  
                this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});    
                }
           }
        },
        (error)=>{
            this.auth.canActivate();
            let empName1 = this.commonService.commonGetCall(requrlEmp);
            empName1.subscribe((data) => {
            this.employee=data.json();
            if(this.employee){
              for(let i=0; i<this.employee.length; i++){
                this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});   
              }
            }
            },
            (error)=>{
              console.log("error");
            });
           
        })

         /** To Fetch attendance details based on Role */
    /* let requrl= this.apiBaseUrl+'/ESS/api/emplyee/attendanceDetailsByRoleForReport/';
        let attendance = this.commonService.commonGetCall(requrl);
        attendance.subscribe((data) => {
             this.data = data.json(); 
               },
        (error)=>{
                this.auth.canActivate();
                let attendance1 = this.commonService.commonGetCall(requrl);
                attendance1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                    console.log("error");
                });
         })*/

          /* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        }) 
       }

    test(event){
      this.employeeName=event.id;
    }

    searchAttDetail()
    {
      console.log("this.fromDate",this.fromDate);
      let finalfromDate; let finaltoDate;

      if(this.fromDate){
       let fromDateFormat=this.fromDate.date.year+"/"+this.fromDate.date.month+"/"+this.fromDate.date.day;
        finalfromDate =  new Date(fromDateFormat).getTime();
      }else{
        finalfromDate="";
      }
      
      if(this.toDate){
        let toDateFormat=this.toDate.date.year+"/"+this.toDate.date.month+"/"+this.toDate.date.day;
        finaltoDate =  new Date(toDateFormat).getTime();
      }else{
        finaltoDate="";
      }
     
      if(!this.employeeName){
        this.employeeName="";
      }
      if(!this.status){
        this.status="";
      }
      if(!this.authorised){
        this.authorised="";
      }
      if(!this.searchBySupervisor){
          this.searchBySupervisor="";
      }

      
      let searchData = {
        "empId" : this.employeeName, 
        "timeIn" : finalfromDate,
        "timeOut" : finaltoDate,
        "authorised" : this.authorised,
        "status" : this.status,
        "supervisorEmpIds" : this.searchBySupervisor
      }
       
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/empAttendanceReportDetailsSearch/';

     
      let attendance = this.commonService.commonPostCall(requrl,searchData);

      attendance.subscribe((data) => {
        this.data = data.json();
        console.log("thissasaasadsaddsadsa", this.data);
          
      },
      (error)=>{
              this.auth.canActivate();
              attendance = this.commonService.commonPostCall(requrl,searchData);
              attendance.subscribe((data) => {
                this.data = data.json();
              },
              (error)=>{
                   console.log("error");
              });
           
      });
    }

    reset(): void{
      this.employeeName = ''; this.fromDate = { date: { year: this.defaultDate.getFullYear(), month:this.defaultDate.getMonth()+1, day: this.defaultDate.getDate() } }; this.toDate = '';
      this.authorised = ''; this.status = '';this.searchBySupervisor = ''; this.category=[];
      this.ngOnInit();
    }
     exportToExcel(event) {
       var exportAttandenceDetails =[];
       var dayIn ;
       var dayTimeIn =null;
       var dayOut ;
       var dayTimeOut = null;
        for(var x= 0;x<this.data.length;x++){
          if(this.data[x].timeIn != null){
             let parsedFromDate = new Date(this.data[x].timeIn);
              dayIn = parsedFromDate.getDate()+"/"+(parsedFromDate.getMonth()+1)+"/"+parsedFromDate.getFullYear();
          }
          if(this.data[x].timeIn1 != null){
            
              dayTimeIn =  (new Date(this.data[x].timeIn1)).toLocaleString([], { hour: '2-digit', minute:'2-digit', hour12: false });
          }
          else
            {
              dayTimeIn ='00:00'
            }
          if(this.data[x].timeOut != null){
              let parsedToDate =  new Date(this.data[x].timeOut);
               dayOut = parsedToDate.getDate()+"/"+(parsedToDate.getMonth()+1)+"/"+parsedToDate.getFullYear();
          }
          if(this.data[x].timeOut1 != null){
              dayTimeOut = (new Date(this.data[x].timeOut1)).toLocaleString([], { hour: '2-digit', minute:'2-digit', hour12: false });
          }
          else{
               dayTimeOut ='00:00'
            }
          var appliedDate = new Date(this.data[x].applieddate);
          var fromDate = new Date(this.data[x].fromDate);
          var toDate = new Date(this.data[x].toDate);
          
            exportAttandenceDetails.push({'Emp Id':this.data[x].empId,'Emp Name':this.data[x].empName ,'Day In':dayIn,'Time In':dayTimeIn,'Day Out':dayOut,'Time Out':dayTimeOut,'Addn Hours':this.data[x].hoursWorked,'Hours':this.data[x].hoursWithAdd,
                'Status':this.data[x].status,'Authorized':this.data[x].authorised,'Authorized By':this.data[x].authorisedBy,'Remark':this.data[x].remarks
            })
        }
    this.excelService.exportAsExcelFile(exportAttandenceDetails, 'AttendanceDetails');
  }
}
