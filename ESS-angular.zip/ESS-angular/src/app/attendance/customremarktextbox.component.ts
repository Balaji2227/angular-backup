import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

@Component({
  selector: 'advanced-example-custom-dropdown',
  template: '<input type="text"  (ngModelChange)="handleRemarksChange($event)" [(ngModel)]="remarks1" name="remarks" class="form-control" id="remarks" required="" data-toggle="tooltip" data-placement="top" title="{{remarks1}}">',
})
export class customremarktextbox implements OnInit {

@Input() remarks: any;
@Output() save: EventEmitter<any> = new EventEmitter();
   
public value: customremarktextbox;
private remarks1;
constructor() { 
}
ngOnInit() {
  this.remarks1=  this.value.remarks;
  
    
}
handleRemarksChange(remarks: string){
     this.remarks = remarks;
     this.save.emit(this.remarks);
}



}
