import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';
import { DomSanitizer } from '@angular/platform-browser';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { customeditrender }  from '../attendance/customeditrender.component';
import { customdayoutrender }  from '../attendance/customdayoutrender.component';
import { customtimeoutrender }  from '../attendance/customtimeoutrender.component';
import { customdayinrender }  from '../attendance/customdayinrender.component';
import { NKDatetimeModule } from 'ng2-datetime/ng2-datetime';
import { AuthGuard } from '../gaurds/auth-guard.service';
import { customdropdown }  from '../attendance/customdropdown.component';
import { customremarktextbox }  from '../attendance/customremarktextbox.component';

/**
 * <h1>attendanceauth.component.ts</h1>
 * @author Gobinath J
 */

@Component({
    moduleId: module.id,
  selector: 'Attendance-Auth',
  templateUrl: './attendanceauth.component.html',
  styleUrls:  ['./attendanceAuth.component.css']
})

export   class   AttendanceAuth  {

    private selected; private settings; private employee:any; private fromDate:any; private toDate:any;
    private authorised; private status;private employees;private data;private employeeId;private empName;
    private toasterService: ToasterService; private bySupervisorList;private searchBySupervisor;
    apiBaseUrl = AppConfiguration.apiBaseUrl;

    constructor(private auth: AuthGuard,private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,toasterService: ToasterService)
     {
        this.toasterService = toasterService; 
     }
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
 
    ngOnInit() { 
   this.settings = {
      selectMode : 'multi',
      mode: 'inline',
      hideSubHeader: true,
      actions: {
        add: false,
        edit:false,
        delete:false,
        //position: 'right'
        },
      pager : {
        display : true,
        perPage:10
      },
      edit: {
        confirmSave: true,
        editButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-pencil"></span>',
        saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      
      columns: {
      
        transId: {
              title: 'transId',
              filter: false,
              show : false
        },
        empId: {
          title: 'Emp Id',
          filter: false,
          editable:false
        },
        empName: {
          title: 'Emp Name',
          filter: false,
          editable:false
        },
         timeIn: {
              title: 'Day In',
              filter: false,
               type: 'custom',
               renderComponent: customdayinrender,
               valuePrepareFunction: (cell, row) => row,
               onComponentInitFunction(instance) {
                      instance.save.subscribe(event => {
                        let dateFormating = new Date(event);
                        let monthFormating:number = dateFormating.getMonth()+1;
                        instance.rowData.timeIn = Date.parse(dateFormating.getFullYear()+'/'+monthFormating+'/'+dateFormating.getDate());
                      
                 });
            }
          },
          timeIn1: {
              title: 'Time In',
              filter: false,
                type: 'custom',
                  renderComponent: customeditrender,
                  valuePrepareFunction: (cell, row) => row,
                  onComponentInitFunction(instance) {
                      instance.save.subscribe(event => {
                      let timeFormating = new Date(event);
                      instance.rowData.timeIn1 = Date.parse(timeFormating.getFullYear()+'/'+timeFormating.getMonth()+'/'+timeFormating.getDate()+' '+timeFormating.getHours()+':'+timeFormating.getMinutes()+':'+timeFormating.getSeconds());
      
              });
           }
          },
          timeOut: {
              title: 'Day Out',
              filter: false,
                type: 'custom',
                 renderComponent: customdayoutrender,
                 valuePrepareFunction: (cell, row) => row,
                 onComponentInitFunction(instance) {
                      instance.save.subscribe(event => {
                      let dateFormating = new Date(event);
                      let monthFormating:number = dateFormating.getMonth()+1;
                      instance.rowData.timeOut = Date.parse(dateFormating.getFullYear()+'/'+monthFormating+'/'+dateFormating.getDate());
                     
                });
              }
            },
            timeOut1: {
              title: 'Time Out',
              filter: false,
              type: 'custom',
              renderComponent: customtimeoutrender,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                      instance.save.subscribe(event => {
                      let timeFormating = new Date(event);
                      instance.rowData.timeOut1 = Date.parse(timeFormating.getFullYear()+'/'+timeFormating.getMonth()+'/'+timeFormating.getDate()+' '+timeFormating.getHours()+':'+timeFormating.getMinutes()+':'+timeFormating.getSeconds());
                });
               }
            },
             hoursWorked: {
              title: 'Addn Hours',
              filter: false
            },  
            hoursWithAdd: {
              title: 'Hours',
              filter: false
            },
            authorised: {
              title: 'Authorized',
              filter: false
            },
            authorisedBy: {
              title: 'Authorized By',
              filter: false
            },
            remarks: {
              title: 'Remark',
              filter: false,
              type: 'custom',
              renderComponent: customremarktextbox,
              valuePrepareFunction: (cell, row) => row,
               onComponentInitFunction(instance) {
                      instance.save.subscribe(event => {
                      let remarks = event;

                      instance.rowData.remarks =remarks;
                      });
               }
            },
             status: {
              title: 'Status',
              filter: false
            },
            compOff: {
              title: 'Comp Off',
              filter: false,
              type: 'custom',
              width: '100px',
              renderComponent: customdropdown,
              valuePrepareFunction: (cell, row) => row,
              onComponentInitFunction(instance) {
                          instance.save.subscribe(event => {
                          let compOff = event;
                          instance.rowData.compOff =compOff;
                          
                  });
               }
            },
            
       
      
      }
    };

         /** To Fetch attendance details based on Role */
       let requrl= this.apiBaseUrl+'/ESS/api/emplyee/attendanceDetailsByRole/';
        let attendance = this.commonService.commonGetCall(requrl);
        attendance.subscribe((data) => {
             this.data = data.json(); 
             console.log("json data", this.data);
               },
        (error)=>{
                this.auth.canActivate();
                let attendance1 = this.commonService.commonGetCall(requrl);
                attendance1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                  console.log("error");
                });
             
        })

        		/* To get the By Supervisor list*/
        let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
        let bySupervisordetails = this.commonService.commonGetCall(requrl1);
        bySupervisordetails.subscribe((data) => {
             this.bySupervisorList = data.json()
        },
        (error)=>{
            this.auth.canActivate();
            let bySupervisordetails = this.commonService.commonGetCall(requrl1);
            bySupervisordetails.subscribe((data) => {
              this.bySupervisorList = data.json()
            },
            (error)=>{
                console.log("error: getBySupervisorList");
            }); 
        })
   
    }

    resetSearch(){
       let requrl= this.apiBaseUrl+'/ESS/api/emplyee/attendanceDetailsByRole/';
        let attendance = this.commonService.commonGetCall(requrl);
        attendance.subscribe((data) => {
             this.data = data.json(); 
             console.log("json data", this.data);
               },
        (error)=>{
                this.auth.canActivate();
                let attendance1 = this.commonService.commonGetCall(requrl);
                attendance1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                  console.log("error");
                });
             
        })
   
    }
  
    onUserRowSelect(event) {
      this.selected = event.selected;
      console.log("event=======", event);
      console.log("selected=======", event.selected[0].transId);
      console.log("fjgkhgklnj", event.cell );
      
              
    }
     reset(): void{
        this.employeeId=""; this.fromDate = ""; this.toDate = "";
        this.empName = ""; this.status = ""; this.authorised = "";this.searchBySupervisor = '';
        this.resetSearch();
      }
    attendanceSearch(){
      let finalfromDate; let finaltoDate;

      if(this.fromDate){
       let fromDateFormat=this.fromDate.date.year+"/"+this.fromDate.date.month+"/"+this.fromDate.date.day;
        finalfromDate =  new Date(fromDateFormat).getTime();
      }else{
        finalfromDate="";
      }
      
      if(this.toDate){
        let toDateFormat=this.toDate.date.year+"/"+this.toDate.date.month+"/"+this.toDate.date.day;
        finaltoDate =  new Date(toDateFormat).getTime();
      }else{
        finaltoDate="";
      }
      if(!this.employeeId){
        this.employeeId="";
      }
      if(!this.status){
        this.status="";
      }
      if(!this.authorised){
        this.authorised="";
      }
      if(!this.empName){
        this.empName="";
      }
       if(!this.searchBySupervisor){
          this.searchBySupervisor="";
      }

      let searchData = {
        "empId" : this.employeeId, 
        "timeIn" : finalfromDate,
        "timeOut" : finaltoDate,
        "authorised" : this.authorised,
        "status" : this.status,
        "empName" :  this.empName,
        "supervisorEmpIds" : this.searchBySupervisor

      }
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/attendanceAuthorizationSearch/';

     
      let attendance = this.commonService.commonPostCall(requrl,searchData);

      attendance.subscribe((data) => {
        this.data = data.json();
          
      },
      (error)=>{
              this.auth.canActivate();
              attendance = this.commonService.commonPostCall(requrl,searchData);
              attendance.subscribe((data) => {
                this.data = data.json();
              },
              (error)=>{
                 
              });
          
      });
      console.log("search data",searchData);
      
    }
  

    authorize(){
      let data;
      var myData = [];
      let attendanceDetails;
      for(let i=0; i<this.selected.length; i++){
         let dateIn = new Date(this.selected[i].timeIn);
         let timeIn = new Date(this.selected[i].timeIn1);
         let dateOut ;
         if(this.selected[i].timeOut){
           dateOut = new Date(this.selected[i].timeOut);
         }
        else{
          dateOut=new Date();

        }
         let timeOut ;
          if(this.selected[i].timeOut1){
           timeOut = new Date(this.selected[i].timeOut1);
         }
        else{
          timeOut=new Date();

        }
         let remarks = this.selected[i].remarks;
         let compOff = this.selected[i].compOff;
         let inMonth:number = dateIn.getMonth()+1;
         let dateTimeIn = Date.parse(dateIn.getFullYear()+'/'+inMonth+'/'+dateIn.getDate()+' '+timeIn.getHours()+':'+timeIn.getMinutes()+':'+timeIn.getSeconds());
         let outMonth:number = dateIn.getMonth()+1;
         let dateTimeOut = Date.parse(dateOut.getFullYear()+'/'+outMonth+'/'+dateOut.getDate()+' '+timeOut.getHours()+':'+timeOut.getMinutes()+':'+timeOut.getSeconds());
         
          attendanceDetails={
           "transId":this.selected[i].transId,
           "timeIn":dateTimeIn,
           "timeOut":dateTimeOut,
           "remarks":remarks,
           "compOff":compOff,
         }
         myData.push(attendanceDetails);
      }
        console.log("inside data",myData);
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/empAttendaceAuthorization';
      let attendance = this.commonService.commonPostCall(requrl,myData);
      attendance.subscribe((data) => {
        this.data = data.json();
        this.toasterService.pop('success', 'Authorised Successfully');
       },
        (error)=>{
           console.log("errorLog "); 
        });
       }
}
