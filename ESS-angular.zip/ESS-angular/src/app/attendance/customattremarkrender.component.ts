import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

/**
 * @author
 */

@Component({
  selector: 'advanced-example-custom-CLtexteditor',
  template: '<span data-toggle="tooltip" data-placement="top" title="{{this.remarks}}">{{this.remarks}}</span>',
})
export class Customattremarkrender implements OnInit {

    @Input() CLbalance: any;
    @Output() save: EventEmitter<any> = new EventEmitter();
    
    public value: Customattremarkrender;
    private remarks;

    constructor() { 
    }
    ngOnInit() {
       
        this.remarks =  this.value.remarks;
        console.log("trhge",this.remarks)
    }
   
}
