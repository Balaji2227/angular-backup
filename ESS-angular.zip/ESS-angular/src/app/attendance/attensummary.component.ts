import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {IMyDpOptions} from 'mydatepicker';

import { AppComponent } from '../app.component';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { CommonService } from '../common.service';
import { ExcelService } from '../excel.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>attensummary.component.ts</h1>
 * @author Gobinath J
 */

@Component({
    moduleId: module.id,
    selector: 'Attendance-Summary',
    templateUrl: './attensummary.component.html',
    styleUrls:  ['./attendancedetails.component.css']
})

export   class   AttendanceSummary  {

    
    private employee:any; private fromDate:any; private toDate:any; private settings;private employees;private data;private employeeId; 
    private employeeName;
    private category: Array<any> = []
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    constructor(private auth: AuthGuard,private app: AppComponent,private commonService: CommonService,private  loginService: LoginService,private excelService: ExcelService) { 
      this.excelService = excelService;
    }

    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };

    
   

    ngOnInit() {
      if(this.app.role == 'ROLE_ADMIN' || this.app.role == 'ROLE_SUPERVISOR')
      {
        this.settings = {
          //selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
          },
          pager : {
            display : true,
            perPage:10
          },
          columns: {
            empId: {
              title: 'Emp Id',
              filter: false
            },
            empName: {
              title: 'Emp Name',
              filter: false
            },
            workedDays: {
              title: 'Days Worked',
              filter: false
            },
            leaveDays: {
              title: 'Leave Days',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                     if(cell==null) {
                       return 0;
                     }else{
                    return cell;
                    }
                  }
            },
            lopDays: {
              title: 'LOP Days',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                     if(cell==null) {
                       return 0;
                     }else{
                    return cell;
                    }
                  }
            }
          }
        };
      }
      else{
        this.settings = {
          //selectMode : 'multi',
          mode: 'inline',
          hideSubHeader: true,
          actions: {
            add: false,
            edit:false,
            delete:false,
            //position: 'right'
          },
          pager : {
            display : true,
            perPage:10
          },
          columns: {
            workedDays: {
              title: 'Days Worked',
              filter: false
            },
            leaveDays: {
              title: 'Leave Days',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                     if(cell==null) {
                       return 0;
                     }else{
                    return cell;
                    }
                  }
            },
            lopDays: {
              title: 'LOP Days',
              filter: false,
              valuePrepareFunction: (cell: any, row: any) =>{
                     if(cell==null) {
                       return 0;
                     }else{
                    return cell;
                    }
                  }
            }
          }
        };
      }
       /** Assigning Employee Names in drop-down */
       let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
        let empName = this.commonService.commonGetCall(requrlEmp);
        empName.subscribe((data) => {
           this.employee=data.json();
          
           if(this.employee)
            {
              for(let i=0; i<this.employee.length; i++){
                this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});       
              }
            }
        },
        (error)=>{
                this.auth.canActivate();
                let empName1 = this.commonService.commonGetCall(requrlEmp);
                empName1.subscribe((data) => {
                 this.employee=data.json();
                  if(this.employee){
                   for(let i=0; i<this.employee.length; i++){
                    this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});       
                   }
                  }
                },
                (error)=>{
                     console.log("error");
                });
             
        })

        /** To Fetch attendance details based on Role */
     let requrl= this.apiBaseUrl+'/ESS/api/emplyee/attendanceSummaryByRole/';
        let attendance = this.commonService.commonGetCall(requrl);
        attendance.subscribe((data) => {
             this.data = data.json(); 
               },
        (error)=>{
                this.auth.canActivate();
                let attendance1 = this.commonService.commonGetCall(requrl);
                attendance1.subscribe((data) => {
                  this.data = data.json();
                },
                (error)=>{
                      console.log("error");
                });
            
        })
    }
    test(event){
      this.employeeName=event.id;
    }

    searchAttSummary(){
      let finalfromDate; let finaltoDate;

      if(this.fromDate){
        let newfromDate = this.fromDate.date.month+"/"+this.fromDate.date.day+"/"+this.fromDate.date.year;
        finalfromDate =  new Date(newfromDate).getTime();
      }
      else{
        this.fromDate = '';
      }
      if(this.toDate){
        let newtoDate = this.toDate.date.month+"/"+this.toDate.date.day+"/"+this.toDate.date.year;
        finaltoDate =  new Date(newtoDate).getTime();
      }
      else{
        this.toDate = '';
      }

      if(!this.employeeName){
        this.employeeName="";
      }

      let searchData = {
        "empId": this.employeeName,
        "timeIn": finalfromDate,
        "timeOut": finaltoDate
      }

      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/empAttendanceSummarySearch/';
      let attendance = this.commonService.commonPostCall(requrl,searchData);
      attendance.subscribe((data) => {
        this.data = data.json();
          
      },
      (error)=>{
              this.auth.canActivate();
              attendance = this.commonService.commonPostCall(requrl,searchData);
              attendance.subscribe((data) => {
                this.data = data.json();
              },
              (error)=>{
                   console.log("error");
              });
          
      });
    }

    reset(): void{
      this.employeeName= ''; this.fromDate = ''; this.toDate = ''; this.category=[];
      this.ngOnInit();
      
    }
     exportToExcel(event) {
      var attendenceSummary =[];
      if(this.app.role == 'ROLE_ADMIN' || this.app.role == 'ROLE_SUPERVISOR')
      { 
        for(var x= 0;x<this.data.length;x++){
            attendenceSummary.push({'Emp Id':this.data[x].empId,'Emp Name':this.data[x].empName,'Days Worked':this.data[x].workedDays,'Leave Days':this.data[x].leaveDays,
              'LOP Days':this.data[x].lopDays
            })
        }
      }else{
        for(var x= 0;x<this.data.length;x++){
            attendenceSummary.push({'Days Worked':this.data[x].workedDays,'Leave Days':this.data[x].leaveDays,'LOP Days':this.data[x].lopDays
            })
        }
      }
     this.excelService.exportAsExcelFile(attendenceSummary, 'AttendanceSummary');
  }
}
