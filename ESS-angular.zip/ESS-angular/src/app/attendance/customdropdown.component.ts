import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';

@Component({
  selector: 'advanced-example-custom-dropdown',
  template: '<select class="form-control"  [(ngModel)]="this.compOff" (ngModelChange)="handleCompOffChange($event)"  name="authorized" ><option selected="selected">No</option><option>0.5</option><option>1</option></select>',
})
export class customdropdown implements OnInit {

@Input() compOff1: any;
@Output() save: EventEmitter<any> = new EventEmitter();
   
public value: customdropdown;
private compOff;private compOffOld;
constructor() { 
}
ngOnInit() {
     if(this.value.compOff){
     this.compOff =  this.value.compOff;
     this.compOffOld =  this.value.compOff;
     }
    else
      {
        this.compOff = "No";
        this.compOffOld =  0;
      }
 
}
    handleCompOffChange(compOff:Number){
       this.compOff1 = compOff;
       if( this.compOffOld == this.compOff1  )
        {
          this.compOff1 = 0;
          this.save.emit(this.compOff1);
        }
        else if(this.compOff1>this.compOffOld){
          this.compOff1 = this.compOff1-this.compOffOld;
          this.save.emit(this.compOff1);
        }
        else if(this.compOff1 == 'No')
        {
           this.compOff1 = -this.compOffOld;
           this.save.emit(this.compOff1);
        }
        else if(this.compOffOld > this.compOff1)
        {
           this.compOff1 =this.compOff1 - this.compOffOld;
           this.save.emit(this.compOff1);
        }
    }



}
