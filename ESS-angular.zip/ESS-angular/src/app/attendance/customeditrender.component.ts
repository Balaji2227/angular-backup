
import { Component, Input,Output, EventEmitter, OnInit } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';


@Component({
  selector: 'advanced-example-custom-editor',
  template: '<span class="atten-auth-addon"><datetime [datepicker]="false" (ngModelChange)="handleTimeInChange($event)" [timepicker]="{ showMeridian: false,  minuteStep: 1 }" [(ngModel)]="timein"></datetime></span>',
})
export class customeditrender implements OnInit {
   @Input() dateFrom: any;
   @Output() save: EventEmitter<any> = new EventEmitter();

   public value: customeditrender;
   private timeIn1;
   timein: Date;

   constructor() {

    }
    ngOnInit() {
      this.timein =  new Date(this.value.timeIn1);
    }
    handleTimeInChange(dateFrom: TimeRanges){
        this.dateFrom = dateFrom;
        this.save.emit(this.dateFrom);
    }

 

}
