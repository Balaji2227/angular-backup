
import { Component, Input,Output, EventEmitter, OnInit } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';


@Component({
  selector: 'advanced-example-custom-editor1',
  template: '<span class="atten-auth-addon"><datetime [datepicker]="false" (ngModelChange)="handleTimeOutChange($event)"   [timepicker]="{ showMeridian: false, minuteStep: 1 }" [(ngModel)]="timein"></datetime></span>',
})
export class customtimeoutrender implements OnInit {
private timeOut1;
timein: Date;
@Input() dateFrom: any;
@Output() save: EventEmitter<any> = new EventEmitter();
public value: customtimeoutrender;
constructor() {  }
ngOnInit() {
   if(this.value.timeOut1 == null){
      
      this.timein = new Date();
      this.timein.setHours(0,0,0);
    }
    else{
      
       this.timein =  new Date(this.value.timeOut1);
    }
      
    
}
handleTimeOutChange(dateFrom: TimeRanges){
     this.dateFrom = dateFrom;
     this.save.emit(this.dateFrom);
}

}
