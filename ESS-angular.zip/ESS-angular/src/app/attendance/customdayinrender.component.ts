
import { Component,OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ViewCell } from 'ng2-smart-table';


@Component({
  selector: 'advanced-example-cusssstom-dateeditor',
  template: '<span class="atten-auth-addon"><datetime [timepicker]="false "  [datepicker]="datepickerOpts" (ngModelChange)="handleDateFromChange($event)" [(ngModel)]="date2"></datetime></span>',
})
export class customdayinrender implements OnInit {

@Input() dateFrom: any;
@Output() save: EventEmitter<any> = new EventEmitter();
   
public value: customdayinrender;
private timeIn;
date2: Date;
constructor() { 
}
ngOnInit() {
    this.date2 =  new Date(this.value.timeIn);
}
handleDateFromChange(dateFrom: Date){
     this.dateFrom = dateFrom;
     this.save.emit(this.dateFrom);
}
datepickerOpts = {
    autoclose: true,
    todayBtn: 'linked',
    todayHighlight: true,
    assumeNearbyYear: true,
     format: 'dd/mm/yy'
}

}
