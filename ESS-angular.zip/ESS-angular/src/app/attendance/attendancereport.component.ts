import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';
import {SelectModule,SelectItem } from 'ng2-select';
import { ExcelService } from '../excel.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
 import 'rxjs/Rx';
 import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
 import { ResponseContentType } from '@angular/http';
 import { saveAs } from 'file-saver';
/**
 * <h1>attendancereport.component.ts</h1>
 * @author Prasanth
 */
@Component({
  selector: 'Full-Report',
  templateUrl: './attendancereport.component.html'
  //styleUrls:  ['./attendancedetails.component.css']
})
export class MonthlyReport
{
                public employee;
                public empId;
                private apiBaseUrl = AppConfiguration.apiBaseUrl;
                private category: Array<any> = [];
                private bySupervisorList;
                private finalFromDate; 
                private finalToDate;
                private searchBySupervisor;
                private settings;
                private report;
                private data;
                constructor(private router: Router, private app: AppComponent,private  loginService: LoginService, private commonService: CommonService,
                private auth : AuthGuard,private excelService: ExcelService,private _http: Http){
                }
 
ngOnInit() {
                let requrlEmp= this.apiBaseUrl+'/ESS/api/emplyee/employeeNames/';
                let empName = this.commonService.commonGetCall(requrlEmp);
                empName.subscribe((data) => {
                this.employee=data.json();
                if(this.employee){
                for(let i=0; i<this.employee.length; i++){
                this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName+' ('+this.employee[i].empId+')'});   
             }
           }
         },
        (error)=>{
                this.auth.canActivate();
                let empName1 = this.commonService.commonGetCall(requrlEmp);
                empName1.subscribe((data) => {
                this.employee=data.json();
                if(this.employee){
                 for(let i=0; i<this.employee.length; i++){
                    this.category.push({"id":this.employee[i].empId,"text":this.employee[i].employeeName});   
                     }
                   }
                },
                (error)=>{
                     console.log("error");
                });
          
        })

     /* To get the  Supervisor list*/
                let requrl1= this.apiBaseUrl+'/ESS/api/emplyee/getBySupervisorList/';
                let bySupervisordetails = this.commonService.commonGetCall(requrl1);
                bySupervisordetails.subscribe((data) => {
                    this.bySupervisorList = data.json()
                },
      (error)=>{
                this.auth.canActivate();
                let bySupervisordetails = this.commonService.commonGetCall(requrl1);
                bySupervisordetails.subscribe((data) => {
                this.bySupervisorList = data.json()
                },
                (error)=>{
                    console.log("error: getBySupervisorList");
             }); 
          })
}
test(event){
     this.empId=event.id;
       }
 
 reset(){
        this.empId = ''; this.finalFromDate = ''; this.finalToDate = ''; this.searchBySupervisor='';
     } 
  exportToExcel(event) {
      let fromDate; let toDate; let empId;let bySupervisor;
if(this.finalFromDate){
        fromDate=(this.finalFromDate.date.year+"-"+this.finalFromDate.date.month+"-"+this.finalFromDate.date.day);
      }else{
       fromDate="";
      }
if(this.finalToDate){
        toDate=(this.finalToDate.date.year+"-"+this.finalToDate.date.month+"-"+this.finalToDate.date.day);
        //finalToDate =  new Date(toDateFormat).getTime();
      }else{
        toDate="";
      }

if(this.empId){
       empId=this.empId  
      }
if(this.searchBySupervisor){
      bySupervisor= this.searchBySupervisor;
      }  
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/get?fromDate='+fromDate +'&toDate='+toDate +'&empId='+empId +'&bySupervisor='+bySupervisor;
      let empName = this.commonService.commonGetCall(requrl);
      empName.subscribe(res => {
      window.open("assets/downloads/Report.xls",'_self');
    })
}

}

  

