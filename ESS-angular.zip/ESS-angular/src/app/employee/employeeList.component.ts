import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { ExcelService } from '../excel.service';
import { ActivatedRoute } from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { AuthGuard } from '../gaurds/auth-guard.service';
/**
 * <h1>employeeList.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'EmployeeList-Master',
  templateUrl: './employeeList.component.html',
  styleUrls:  ['./employee.component.css']
})

export   class   EmployeeList  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl; private ViewEmployeeDetail;private toasterService: ToasterService;
    empId = ''; empName = ''; project = ''; designation = ''; ageFrom = ''; ageTo = ''; 
    supervisor = ''; status = ''; showDialog = false; private employeeList; private dropdownList;
    private settings; private supervisors; private projects; private designations; age : number[] = [];
    viewEmpId = ''; viewEmpName = ''; viewProject = ''; viewDesignation = ''; viewMobile = ''; viewEmail = '';
    viewDOB:any; viewAge = ''; viewSupervisor = ''; viewAddress = ''; viewPersonalEmail = '';viewProfileImage = '';
    private sub: any;
    public count:number;
    public CountafterSync:number;
    id: number;
    projectsList = [];
    selectedItems = [];
    dropdownSettings = {};
    constructor(private auth: AuthGuard,private _router: Router,private  loginService: LoginService,private app: AppComponent,
        private commonService: CommonService,private excelService: ExcelService,private route: ActivatedRoute,toasterService: ToasterService,private http:Http) { 
              this.excelService = excelService;
            this.toasterService = toasterService; 
            
        }
       
    ngOnInit() {


        let employeeRequrl= this.apiBaseUrl+'/ESS/api/emplyee/employeeCount/';
        let employeeCount = this.commonService.commonGetCall(employeeRequrl);
        employeeCount.subscribe((data) => {
        console.log(data);
        this.count=data.json();
          
        });
       this.sub = this.route.params.subscribe(params => {
            this.id = +params['flag']; 
       });
        for(var i = 1; i <= 100; i++){
            this.age.push(i);
        }
        if(this.app.role == 'ROLE_ADMIN')
        {
        this.settings = {
            mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                    {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
            columns: {
                empId:{
                    title: 'Employee ID',
                    filter: false,
                    //show: false,
                },
                employeeName: {
                    title: 'Employee Name',
                    filter: false,
                    //show: false,
                },
               
                designation: {
                    title: 'Designation',
                    filter: false
                },
                mobileNumber: {
                    title: 'Mobile No',
                    filter: false
                },
                age: {
                    title: 'Age',
                    filter: false,
                    valuePrepareFunction: (cell: any, row: any) =>{
                    if(cell) {
                        return cell;
                        }
                    else{
                        return '';
                        }
                    }
                },
                reportingPerson: {
                    title: 'Supervisor',
                    filter: false
                },
                calender: {
                    title: 'Calendar',
                    filter: false
                },
                status: {
                    title: 'Status',
                    filter: false
                }
            }
        };
        }
        else{
            this.settings = {
            mode: 'inline',
            hideSubHeader: true,
            actions: {
                add: false,
                edit:false,
                delete:false,
                custom: [
                    {
                        name: 'edit',
                        title: '<span class="glyphicon glyphicon-pencil"></span> ',
                    },
                    {
                        name: 'view',
                        title: '<span class="glyphicon glyphicon-eye-open"></span>',
                    },
                ],
                position: 'right'
                },
            pager : {
                display : true,
                perPage:10
            },
            columns: {
                empId:{
                    title: 'Employee ID',
                    filter: false,
                    //show: false,
                },
                employeeName: {
                    title: 'Employee Name',
                    filter: false,
                    //show: false,
                },
                
                designation: {
                    title: 'Designation',
                    filter: false
                },
                mobileNumber: {
                    title: 'Mobile No',
                    filter: false
                },
                age: {
                    title: 'Age',
                    filter: false
                },
                reportingPerson: {
                    title: 'Supervisor',
                    filter: false
                },
                calender: {
                    title: 'Calendar',
                    filter: false
                }
            }
        };
        }
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getAllEmployeeDetails/';
        let employeeDetails = this.commonService.commonGetCall(requrl);
        employeeDetails.subscribe((data) => {
            this.employeeList = data.json();
            if(this.id == 1){
             this.toasterService.pop('success', 'Employee details updated Successfully'); 
            }
            
           this.id = 0; 
        },
        (error)=>{
                this.auth.canActivate();
                let employeeDetails1 = this.commonService.commonGetCall(requrl);
                employeeDetails1.subscribe((data) => {
                this.employeeList = data.json();
                },
                (error)=>{
                  console.log("error");
                });
            
        });
        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
            this.supervisors = this.dropdownList.empDet;
            this.projects = this.dropdownList.projects;
            this.designations = this.dropdownList.designation;
            var ProjectsListData=[];
            for(var i=0; i < this.dropdownList.projects.length; i++) {
                ProjectsListData[i]={"id":this.dropdownList.projects[i].idmaster,"itemName":this.dropdownList.projects[i].name};
            }
                this.projectsList = ProjectsListData ;   
        });
             this.selectedItems = [ ];
        
        this.dropdownSettings = 
        { 
        singleSelection: false, 
        text:"Select Project",
        selectAllText:'Select All',
        unSelectAllText:'UnSelect All',
        enableSearchFilter: true,
        classes:"myclass custom-class"
         };
    }
    onItemSelect(item:any){
    }
    OnItemDeSelect(item:any){
    }
    onSelectAll(items: any){
    }
    onDeSelectAll(items: any){
    }  
    searchEmployee(){
        var projectArrayName=[];
        for(var i=0; i < this.selectedItems.length; i++) {
            projectArrayName[i]= this.selectedItems[i].id ;
            
        }
        var proj = projectArrayName.sort().toString();
         
        let searchData = {
            "empId":this.empId,
            "employeeName": this.empName,
            "projectName":proj,
            "designationId": this.designation,
            "ageFrom":this.ageFrom,
            "ageTo": this.ageTo,
            "reportingPersonId":this.supervisor,
            "status": this.status
        }
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getAllEmployeeDetails/';
        let designation = this.commonService.commonPostCall(requrl,searchData);
        designation.subscribe((data) => {
            this.employeeList = data.json();
            
        },
        (error)=>{
            
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,searchData);
                designation.subscribe((data) => {
                    this.employeeList = data.json();
                },
                (error)=>{
                        console.log("error");
                });
                
        });
}

    reset(): void{
        this.empId = ''; this.empName = ''; this.project = ''; this.designation = ''; this.ageFrom = ''; 
        this.ageTo = ''; this.supervisor = ''; this.status = ''; this.id=0;
        this.ngOnInit();
       
    }
    public imgURL:any;
    public imgBase64="data:image/png;base64,";
    customAction(event): void{
        let action = event.action;
        let empId = event.data.empId;
        if(action == 'view')
        {
            let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getEmplyeeDetailsById/'+empId;
            let employeeDetails = this.commonService.commonGetCall(requrl);
            employeeDetails.subscribe((data) => {
                this.ViewEmployeeDetail = data.json();
                this.viewEmpId = this.ViewEmployeeDetail.empId; 
                this.viewEmpName = this.ViewEmployeeDetail.employeeName; 
                this.viewProfileImage = this.ViewEmployeeDetail.profileImage; 
                if(this.viewProfileImage==null){
                    this.imgURL="assets/images/ext-profile.png";
                }else{
                    this.imgURL = this.imgBase64 + this.viewProfileImage;
                }
                this.viewProject = this.ViewEmployeeDetail.projectName;
                this.viewDesignation = this.ViewEmployeeDetail.designation; 
                this.viewMobile = this.ViewEmployeeDetail.mobileNumber; 
                this.viewEmail = this.ViewEmployeeDetail.mailId;
                let dateofbirth = new Date(this.ViewEmployeeDetail.dob);
                var month = dateofbirth.getMonth() + 1;
	            var date = dateofbirth.getDate();
                this.viewDOB = (date < 10 ? '0' + date : date)+"/"+( month < 10 ? '0' + month : month)+"/"+dateofbirth.getFullYear();
                this.viewAge = this.ViewEmployeeDetail.age; 
                this.viewSupervisor = this.ViewEmployeeDetail.reportingPerson; 
                this.viewAddress = this.ViewEmployeeDetail.permanentAddress; 
                this.viewPersonalEmail = this.ViewEmployeeDetail.personalMailId;
            },
            (error)=>{
                    this.auth.canActivate();
                    let employeeDetails1 = this.commonService.commonGetCall(requrl);
                    employeeDetails1.subscribe((data) => {
                    this.ViewEmployeeDetail = data.json();
                    this.viewEmpId = this.ViewEmployeeDetail.empId; 
                    this.viewEmpName = this.ViewEmployeeDetail.employeeName; 
                    this.viewProject = this.ViewEmployeeDetail.projectName;
                     this.viewDesignation = this.ViewEmployeeDetail.designation; 
                    this.viewMobile = this.ViewEmployeeDetail.mobileNumber;
                     this.viewEmail = this.ViewEmployeeDetail.mailId;
                    let dateofbirth = new Date(this.ViewEmployeeDetail.dob);
                    this.viewDOB = dateofbirth.getDate();
                    this.viewAge = this.ViewEmployeeDetail.age;
                     this.viewSupervisor = this.ViewEmployeeDetail.reportingPerson; 
                    this.viewAddress = this.ViewEmployeeDetail.permanentAddress;
                     this.viewPersonalEmail = this.ViewEmployeeDetail.personalMailId;
                    },
                    (error)=>{
                         console.log("error");
                    });
                 
            });
            this.showDialog = true;
        }
        else{
            this._router.navigate(['/editEmployee', empId]);
        }
    }
    exportToExcel(event) {
        var exportEmployeeDetails =[];
        for(var x= 0;x<this.employeeList.length;x++){
            exportEmployeeDetails.push({'Employee ID':this.employeeList[x].empId,'Employee Name':this.employeeList[x].employeeName,'Designation':this.employeeList[x].designation,
            'Mobile No':this.employeeList[x].mobileNumber,'Age':this.employeeList[x].age,'Supervisor':this.employeeList[x].reportingPerson,'Calendar':this.employeeList[x].calender,'Status':this.employeeList[x].status})
        }
    this.excelService.exportAsExcelFile(exportEmployeeDetails, 'EmployeeList');
  }
  private oldPassword;
    private newPassword;
    private dataCheck;
    ResetPassword(empId){
        let ResetpasswordData = {
        "empId":empId,
        "empPassword":empId,
        "newPassword":empId
       }
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/resetPassword/';
      let userCridentialsResponseData = this.commonService.commonPostCall(requrl,ResetpasswordData);
      userCridentialsResponseData.subscribe((data) => {
              this.dataCheck=data._body ;
            if(this.dataCheck=='Success'){
                this.toasterService.pop('success', 'Password Changed Successfully'); 
               }
       },
      (error)=>{
              this.auth.canActivate();
              userCridentialsResponseData = this.commonService.commonPostCall(requrl,ResetpasswordData);
              userCridentialsResponseData.subscribe((data) => {
                 this.toasterService.pop('success', 'Password Changed Successfully'); 
              },
              (error)=>{
                    console.log("error");
              });
          
      });
    }
    //Button added for cron jobs
    sync(){
        
        let url = `http://172.17.2.93:8090/EssMigrationCron/rest/onDemand`;
        this.http.get(url)
         .subscribe ((data: Response) => {
    },
        (error)=>{
              
              let employeeRequrl= this.apiBaseUrl+'/ESS/api/emplyee/employeeCount/';
              let employeeCountafterSync = this.commonService.commonGetCall(employeeRequrl);
              employeeCountafterSync.subscribe((data) => {
                  this.CountafterSync=data.json();
                  console.log("this.count1", this.CountafterSync);
                  if(this.count==this.CountafterSync)
                    {
                 this.toasterService.pop('success', 'No Employee Added'); 
                    }
                else{
                    this.toasterService.pop('success', ' Employee Added Successfully'); 
                }
              },
              (error)=>{
                    console.log("error");
              });
          
      });


    }



}
