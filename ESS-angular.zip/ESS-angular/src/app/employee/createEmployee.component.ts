import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import {IMyDpOptions} from 'mydatepicker';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { AuthGuard } from '../gaurds/auth-guard.service';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
@Component({
  selector: 'createEmployee-Master',
  templateUrl: './createEmployee.component.html',
  styleUrls:  ['./employee.component.css']
})

export   class   CreateEmployeeMaster  {
  apiBaseUrl = AppConfiguration.apiBaseUrl; private empId;private calendars;private role;private employeeTypeIds;private toasterService: ToasterService;
    private dropdownList; private settings; private supervisors; private projects; private designations;private bloodGroupIds;
    createEmployeeDet:any = {empId:'',employeeName: '', mobileNumber:'', mailId:'', designationId:'', projectId:'', calenderId:'',
        dob:'', reportingPersonId:'', permanentAddress:'', temporaryAddress:'', personalMailId:'', status:'',profileImage:'',employeeTypeId:'',projectListID:[],bloodGroup:'',sex:''};
        gender = ['Male', 'Female'];
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    public dob: any;
    public dob1: any;
	projectsList = [];
    selectedItems = [];
    dropdownSettings = {};
    constructor(private auth: AuthGuard,private router: Router,private activatedRoute: ActivatedRoute, private app: AppComponent,
        private  loginService: LoginService, private commonService: CommonService,toasterService: ToasterService) {
            this.toasterService = toasterService; 
         }

    ngOnInit() {
        this.role = this.app.role;
        this.activatedRoute.params.subscribe((params: Params) => {
        this.empId = params['userId'];
        });
        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
            this.supervisors = this.dropdownList.empDet;
            this.projects = this.dropdownList.projects;
            this.designations = this.dropdownList.designation;
            this.calendars = this.dropdownList.calendar; 
            this.employeeTypeIds= this.dropdownList.employeeTypeId; 
            this.bloodGroupIds=this.dropdownList.bloodGroupId;
            var ProjectsListData=[];
            for(var i=0; i < this.dropdownList.projects.length; i++) {
                ProjectsListData[i]={"id":this.dropdownList.projects[i].idmaster,"itemName":this.dropdownList.projects[i].name};
            }
                this.projectsList = ProjectsListData ;     
        });
		this.selectedItems = [ ];
        
		this.dropdownSettings = { 
                                  singleSelection: false, 
                                  text:"Select Project",
                                  selectAllText:'Select All',
                                  unSelectAllText:'UnSelect All',
                                  enableSearchFilter: true,
                                  classes:"myclass custom-class"
                                };    
		
    }
        onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
        }
        onlyCharactersKey(event){
        var charCode = (event.which) ? event.which : event.keyCode
            if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123) && charCode != 32 && charCode != 8)
            return false;
            return true;
        }
	 onItemSelect(item:any){
                    }
                    OnItemDeSelect(item:any){
                    }
                    onSelectAll(items: any){
                    }
                    onDeSelectAll(items: any){
                    }  
    // tempAddressChange(ev) {
    //     this.editEmployeeDet.temporaryAddress = ev.target.value;
    // }

    
  handleFileSelect(event){ 
      var files = event.target.files;
      var file = files[0];

    if (files && file) {
        var reader = new FileReader();

        reader.onload =this._handleReaderLoaded.bind(this);

        reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt) {
     var binaryString = readerEvt.target.result;
            this.base64textString= btoa(binaryString);
    }

    public base64textString:any;
    
    permAddressChange(ev) {
        this.createEmployeeDet.permanentAddress = ev.target.value;
    }
    saveEmployee(){
        let newDate=this.dob.date.month+"/"+this.dob.date.day+"/"+this.dob.date.year;
        this.createEmployeeDet.dob =  new Date(newDate).getTime();
        this.createEmployeeDet.imageDataUrl = this.base64textString;
		 for(var i=0; i < this.selectedItems.length; i++) {
                    this.createEmployeeDet.projectListID[i]={"idmaster":this.selectedItems[i].id,"name":this.selectedItems[i].itemName};
                     }
        console.log('employeeSave',this.createEmployeeDet);
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/employeeSave/';
        let designation = this.commonService.commonPostCall(requrl,this.createEmployeeDet);
        designation.subscribe((data) => {
          if(data._body =="Success"){
               this.router.navigate(['/employeeList',{flag:2}]); 
          }else{
                this.toasterService.pop('error', 'Employee Id already exsist');
          }
            
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,this.createEmployeeDet);
                designation.subscribe((data) => {
                    this.router.navigate(['/employeeList',{flag:2}]);
                },
                (error)=>{
                     console.log("error");
                });
             
        });
    }

}