import { Component } from '@angular/core';
import { Router, ActivatedRoute, Params }  from '@angular/router';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import {IMyDpOptions} from 'mydatepicker';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { AuthGuard } from '../gaurds/auth-guard.service';
/**
 * <h1>employeeList.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'EditEmployee-Master',
  templateUrl: './editEmployee.component.html',
  styleUrls:  ['./employee.component.css']
})

export   class   EditEmployeeMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl; private empId;private calendars;private role;private toasterService: ToasterService;
    private dropdownList; private settings; private supervisors; private projects; private designations;private employeeTypeIds;private bloodGroupIds;
    editEmployeeDet:any = {employeeName: '', mobileNumber:'', mailId:'', designationId:'', projectId:'', calenderId:''
        ,dob:'', reportingPersonId:'', permanentAddress:'', temporaryAddress:'', personalMailId:'', status:'',profileImage:'',employeeTypeId:'',projectIds:'',projectListID:[],projectName:'',bloodGroup:'',};

    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd/mm/yyyy',
        showClearDateBtn :false,
        editableDateField : false
    };
    public dob: any;
    public dob1: any;
    showDialog = false
    constructor(private auth: AuthGuard,private router: Router,private activatedRoute: ActivatedRoute, private app: AppComponent,
        private  loginService: LoginService, private commonService: CommonService, toasterService: ToasterService) {
            this.toasterService = toasterService; 
         }
    gender = ['Male', 'Female'];
    projectsList = [];
    selectedItems = [];
    dropdownSettings = {};     
    ngOnInit() {
        this.role = this.app.role;
        this.activatedRoute.params.subscribe((params: Params) => {
        this.empId = params['userId'];
        });
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/getEmplyeeDetailsById/'+this.empId;
        let employeeDetails = this.commonService.commonGetCall(requrl);
        employeeDetails.subscribe((data) => {

            this.editEmployeeDet = data.json();
            let gender=this.editEmployeeDet.sex;
            if(gender=='M'){
                this.editEmployeeDet.sex ="Male"
            }
            if(gender=='F'){
                this.editEmployeeDet.sex ="Female"
            }
            let responsevalue = data.json();
            let dobDate = new Date(responsevalue.dob);
            this.dob = { date: { year: dobDate.getFullYear(), month: (dobDate.getMonth()+1), day: dobDate.getDate() } };
            this.dob1 = dobDate.getDate()+'/'+dobDate.getMonth()+'/'+dobDate.getFullYear();
            
        },
        (error)=>{
                this.auth.canActivate();
                let employeeDetails1 = this.commonService.commonGetCall(requrl);
                employeeDetails1.subscribe((data) => {
                this.editEmployeeDet = data.json();
                },
                (error)=>{
                     console.log("error");
                });
           
        });
        let dropdownDetails = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/emplyee/employeeSearch/');
        dropdownDetails.subscribe((data) => {
            this.dropdownList = data.json();
           // this.supervisors = this.dropdownList.empDet;
            this.projects = this.dropdownList.projects;
            this.designations = this.dropdownList.designation;
            this.calendars = this.dropdownList.calendar;
            this.employeeTypeIds= this.dropdownList.employeeTypeId; 
            this.bloodGroupIds=this.dropdownList.bloodGroupId;
            var ProjectsListData=[];
            var supervisorsData=[];
            var j=0;
            if(this.dropdownList.empDet.length > 0){
                for(var i=0; i < this.dropdownList.empDet.length; i++) {
                    if((this.dropdownList.empDet[i].empId) != (this.empId)){
                    supervisorsData[j]={"empId":this.dropdownList.empDet[i].empId,"employeeName":this.dropdownList.empDet[i].employeeName,"role":this.dropdownList.empDet[i].role}; 
                        j++;
                    }
                }
            }
            this.supervisors=supervisorsData;
            for(var i=0; i < this.dropdownList.projects.length; i++) {
                ProjectsListData[i]={"id":this.dropdownList.projects[i].idmaster,"itemName":this.dropdownList.projects[i].name};
            }
            this.projectsList = ProjectsListData ;  
           if(this.editEmployeeDet.projectIds != null ){
                 var PrjtIds =this.editEmployeeDet.projectIds.split(',');
                 var PrjtNames=this.editEmployeeDet.projectName.split(',');
                var PrjtsIdList=[];
                for(var i = 0; i < PrjtIds.length; i++)
                    {
                    PrjtsIdList[i]={"id":parseInt(PrjtIds[i]),"itemName":PrjtNames[i]};
                    }
                    this.selectedItems = PrjtsIdList ;
           }
           
            });
        this.dropdownSettings = { 
                                  singleSelection: false, 
                                  text:"Select Project",
                                  selectAllText:'Select All',
                                  unSelectAllText:'UnSelect All',
                                  enableSearchFilter: true,
                                  classes:"myclass custom-class"
                                }; 
    }

                    onItemSelect(item:any){
                      
                    }
                    OnItemDeSelect(item:any){
                    
                    }
                    onSelectAll(items: any){
                    }
                    onDeSelectAll(items: any){
                     
                    }
    // tempAddressChange(ev) {
    //     this.editEmployeeDet.temporaryAddress = ev.target.value;
    // }
        onlyNumberKey(event) {
        return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
        }
        onlyCharactersKey(event){
        var charCode = (event.which) ? event.which : event.keyCode
            if ((charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 123) && charCode != 32 && charCode != 8)
            return false;
            return true;
        }    
    
  handleFileSelect(event){ 
      var files = event.target.files;
      var file = files[0];

    if (files && file) {
        var reader = new FileReader();

        reader.onload =this._handleReaderLoaded.bind(this);

        reader.readAsBinaryString(file);
    }
  }

  _handleReaderLoaded(readerEvt) {
     var binaryString = readerEvt.target.result;
            this.base64textString= btoa(binaryString);
    }

    public base64textString:any;
    
    permAddressChange(ev) {
        this.editEmployeeDet.permanentAddress = ev.target.value;
    }
    saveEmployee(){
        let newDate=this.dob.date.month+"/"+this.dob.date.day+"/"+this.dob.date.year;
        this.editEmployeeDet.dob =  new Date(newDate).getTime();
        this.editEmployeeDet.imageDataUrl = this.base64textString;
        this.editEmployeeDet.projectListID=[];
        for(var i=0; i < this.selectedItems.length; i++) {
                    this.editEmployeeDet.projectListID[i]={"idmaster":this.selectedItems[i].id,"name":this.selectedItems[i].itemName};
            }
        let requrl= this.apiBaseUrl+'/ESS/api/emplyee/updateEmployeeDetails/';
        let designation = this.commonService.commonPostCall(requrl,this.editEmployeeDet);
        designation.subscribe((data) => { 
         this.router.navigate(['/employeeList',{flag:1}]);
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,this.editEmployeeDet);
                designation.subscribe((data) => {
                    this.router.navigate(['/employeeList',{flag:1}]);
                },
                (error)=>{
                      console.log("error");
                });
            
        });
    }
    private oldPassword;
    private newPassword;
    private dataCheck;
    ResetPassword(){
        let ResetpasswordData = {
        "empId":this.empId,
        "empPassword":this.empId,
        "newPassword":this.empId
       }
      let requrl= this.apiBaseUrl+'/ESS/api/emplyee/resetPassword/';
      let userCridentialsResponseData = this.commonService.commonPostCall(requrl,ResetpasswordData);
      userCridentialsResponseData.subscribe((data) => {
              this.dataCheck=data._body ;
            if(this.dataCheck=='Success'){
                this.toasterService.pop('success', 'Passord Changed Successfully'); 
               }
       },
      (error)=>{
              this.auth.canActivate();
              userCridentialsResponseData = this.commonService.commonPostCall(requrl,ResetpasswordData);
              userCridentialsResponseData.subscribe((data) => {
                 this.toasterService.pop('success', 'Passord Changed Successfully'); 
              },
              (error)=>{
                    console.log("error");
              });
          
      });
    }

}
