import { Injectable } from '@angular/core';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Router } from '@angular/router';

import { AppConfiguration } from './app-config';

/**
 * <h1>common.service.ts</h1>
 * @author Gobinath J
 */

@Injectable()
export class CommonService {

    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private _loginurl= this.apiBaseUrl+'/ESS/oauth/token';
    constructor(private _http: Http, private _router: Router){}
    
    /* Method for Common Get Call*/
    commonGetCall(reqUrl): any {
        let headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem("access_token"))
        headers.append('Accept', 'application/json');
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this._http.get(reqUrl, options);
    }

    /* Method for Referesh the token using Referesh Token*/
    refereshToken(): any {
        let headers = new Headers();
        let queryParam = 'grant_type=refresh_token&refresh_token='+localStorage.getItem("refresh_token");
        headers.append('Authorization', 'Basic bXktdHJ1c3RlZC1jbGllbnQ6c2VjcmV0');
        headers.append('Accept', 'application/json');
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._loginurl, queryParam, options)
            .map((response: Response) => <any> response.json())
            .do(data => console.log(JSON.stringify(data)));
    }

    /* Method for Common Post Call*/
    commonPostCall(reqUrl,bodyObj): any {
        let body = JSON.stringify(bodyObj);
        let headers = new Headers();
        headers.append('Authorization', 'bearer ' + localStorage.getItem("access_token"));
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(reqUrl, body, options);
    }
}