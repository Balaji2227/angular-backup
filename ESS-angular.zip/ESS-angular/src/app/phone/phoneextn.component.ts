import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import { CommonService } from '../common.service';
import { AppComponent } from '../app.component';
import { AppConfiguration } from '../app-config';
import { AuthGuard } from '../gaurds/auth-guard.service';

@Component({
    moduleId: module.id,
    selector: 'Phone-Extn',
    templateUrl: './phoneextn.component.html'
})

export   class   PhoneExtn  {
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private  auth: AuthGuard;
    private phonExtlist;
    private list;
    private showDialog = false;
    phoneExtn:any = {name:'',dept:'',number:'' }
    phoneExtnData:any = {name:'',description:'',activeStatus:'',masterType:''}
    constructor(private _router: Router,private commonService: CommonService) {}
    ngOnInit() {
         let extnList = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/Master/getExtn/');
         extnList.subscribe((data) => {
            this.list = data.json();
            this.phonExtlist = this.list;
            let ph;
            this.phonExtlist.forEach(l => {
               var nameArray =  l.description.split(",");
               l.description = nameArray[0];
               l.dept = nameArray[1];
            });           
         })
    }

    search(a): void{
        
       let requrl= this.apiBaseUrl+'/ESS/api/Master/filterPhoneExtn/';
      let phone = this.commonService.commonPostCall(requrl,a);
      phone.subscribe((data) => {
        this.list = data.json();
           this.phonExtlist = this.list;
            let ph;
            this.phonExtlist.forEach(l => {
               var nameArray =  l.description.split(",");
               l.description = nameArray[0];
               l.dept = nameArray[1];
            }); 
      });
    }

    
}
