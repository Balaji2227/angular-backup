import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>project.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'phoneExtnMasterr',
  templateUrl: './phoneExtnMaster.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   phoneExtnMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    public extensions;
    private list;
    private settings;
    private projectName = '';
    private status = '';
    private  auth: AuthGuard;
    private descriptionExtn;
    private dept='';
    private extn='';

    constructor(toasterService: ToasterService,private  loginService: LoginService, private commonService: CommonService) {
        this.toasterService = toasterService;    
    }
    
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {

      this.settings = {
      mode: 'inline',
      actions: {
        add: true,
        edit:true,
        delete:false,
        //position: 'right'
        },
      pager : {
        display : true,
        perPage:10
      },
      edit: {
        confirmSave: true,
        editButtonContent: '<span class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>',
        saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      add: {
        confirmCreate: true,
        addButtonContent: '<span class="btn btn-sm btn-primary">Add</span>',
        createButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      columns: {
        idmaster:{
          title: 'Id',
          filter: false,
          show: false,
        },
        description: {
          title: 'Name',
          filter: false,
          
        },
        dept: {
          title: 'Department',
          filter: false,
        },
        name: {
          title: 'Extn',
          filter: false,
          editable:false
        },
        activeStatus: {
          title: 'Status',
          filter: false,
          editor: {
            type: 'list',
            config: {
              list: [{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }],
            },
          },
        }
      }
    };

      let extnList = this.commonService.commonGetCall(this.apiBaseUrl+'/ESS/api/Master/getExtn/');
      extnList.subscribe((data) => {
        this.list = data.json();
        this.extensions = this.list;
        let ph;
        this.extensions.forEach(l => {
            var nameArray =  l.description.split(",");
            l.description = nameArray[0];
            l.dept = nameArray[1];
        });           
      })

      
    }

    onCreateConfirm(event): void {
         let name = event.newData.name;
         let description = event.newData.description;
         let status = event.newData.activeStatus;
         let dept = event.newData.dept;
        if(name == '' || description == ''|| status == ''|| dept == ''){
          this.toasterService.pop('error', 'Fields should not be empty');
        }else{
          
            let extnDetails = {
                "description": description+','+dept,
                "name": name,
                "activeStatus":status,
                "masterType":"Extn"
              }
        console.log("===>>>",extnDetails);
        let requrl= this.apiBaseUrl+'/ESS/api/Master/saveExtn/';
        let extnData = this.commonService.commonPostCall(requrl, extnDetails);
        extnData.subscribe((data) => {
           
            let dataCheck=data._body ;
            console.log("hhhhhhh : ",dataCheck);
            if(dataCheck=='Success'){
			 this.toasterService.pop('success', 'Phone extension added successfully'); 
              this.ngOnInit();
            } else if(dataCheck=='Failure'){
              this.toasterService.pop('error', 'Phone extension already exists'); 
            }      
        },
        (error)=>{
             this.auth.canActivate();
             let requrl= this.apiBaseUrl+'/ESS/api/Master/saveExtn/';
             let extnData = this.commonService.commonPostCall(requrl, extnDetails);
             extnData.subscribe((data) => {
                 let dataCheck=data._body ;
                 console.log("hhhhhhh : ",dataCheck);
                 if(dataCheck=='Success'){
				  this.toasterService.pop('success', 'Phone extension added successfully'); 
                   this.ngOnInit();
                 } else if(dataCheck=='Failure'){
                     this.toasterService.pop('error', 'Phone extension already exists'); 
                 }   
             },
             (error)=>{
                 
             });
        });    
      }
    }

    onEditConfirm(event): void {
      let name = event.newData.name;
         let description = event.newData.description;
         let status = event.newData.activeStatus;
         let dept = event.newData.dept;
        if(name == '' || description == ''|| status == ''|| dept == ''){
          this.toasterService.pop('error', 'Fields should not be empty');
        }else{
          
             let extnDetails = {
                "description": description+','+dept,
                "name": name,
                "activeStatus":status,
                "masterType":"Extn"
              }
        console.log("===>>>",extnDetails);
        let requrl= this.apiBaseUrl+'/ESS/api/Master/editExtn/';
        let extnData = this.commonService.commonPostCall(requrl, extnDetails);
        extnData.subscribe((data) => {
            this.ngOnInit();
            
        },
        (error)=>{
             this.auth.canActivate();
             let requrl= this.apiBaseUrl+'/ESS/api/Master/editExtn/';
             let extnData = this.commonService.commonPostCall(requrl, extnDetails);
             extnData.subscribe((data) => {
                 
             },
             (error)=>{
                 
             });
        });    
      }
    }

    searchProject(): void{
      let depart = '';
      if(this.dept != ''){
          depart = ','+this.dept;
      }
      let searchData = {
        "description":this.descriptionExtn+depart,
        "activeStatus": this.status,
        "name":this.extn
      }
      let requrl= this.apiBaseUrl+'/ESS/api/Master/searchPhoneExtn/';
      let phone = this.commonService.commonPostCall(requrl,searchData);
      phone.subscribe((data) => {
        this.list = data.json();
        this.extensions = this.list;
        let ph;
        this.extensions.forEach(l => {
            var nameArray =  l.description.split(",");
            l.description = nameArray[0];
            l.dept = nameArray[1];
        });    
      });
     }

    reset(): void{
      this.descriptionExtn = '';
      this.status = '';
      this.dept = '';
      this.searchProject();
    }
}
