import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>calendar.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Calendar-Master',
  templateUrl: './calander.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   CalendarMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    private calendars;
    private settings;
    private calendarName = '';
    private status = '';

    constructor(private  auth: AuthGuard, toasterService: ToasterService,private  loginService: LoginService, private commonService: CommonService, private _router: Router) {
        this.toasterService = toasterService;    
    }
    
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {
      this.settings = {
        mode: 'inline',
        actions: {
          add: true,
          edit:true,
          delete:false,
          custom: [{ title: `<span class="btn btn-sm btn-success glyphicon glyphicon-eye-open"></span>` }]
          //position: 'right'
          },
        pager : {
          display : true,
          perPage:10
        },
        edit: {
          confirmSave: true,
          editButtonContent: '<span class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>',
          saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
         cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
        },
        add: {
         confirmCreate: true,
        addButtonContent: '<span class="btn btn-sm btn-primary">Add</span>',
        createButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
        },
        columns: {
          idmaster:{
            title: 'Id',
            filter: false,
            show: false,
          },
          name: {
            title: 'Calendar Name',
            filter: false
          },
          description: {
            title: 'Description',
            filter: false
          },
          activeStatus: {
            title: 'Status',
            filter: false,
          editor: {
            type: 'list',
            config: {
              list: [{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }],
            },
          },
          }
        }
      };
      let requrl= this.apiBaseUrl+'/ESS/api/Master/getCalendrList/';
      let designationDetails = this.commonService.commonGetCall(requrl);
        designationDetails.subscribe((data) => {
            this.calendars = data.json();
        },
        (error)=>{
          this.auth.canActivate();
          let dashboardDetails1 = this.commonService.commonGetCall(requrl);
          dashboardDetails1.subscribe((data) => {
            this.calendars = data.json();
          },
          (error)=>{
            console.log("error");
          });
        });
    }

    onCreateConfirm(event): void {
        let name = event.newData.name;
        let description = event.newData.description;
        let status = event.newData.activeStatus;
        if(name == '' || description == ''|| status == ''){
          this.toasterService.pop('error', 'Fields Should not be empty');
        }
        else{
          let createdData = {
            "name": name,
            "description": description
          }
          let requrl= this.apiBaseUrl+'/ESS/api/Master/saveCalendar/';
          let designation = this.commonService.commonPostCall(requrl,createdData);
          let checkName;
          designation.subscribe((data) => {
              checkName=data._body ;
              if(checkName=='Failure'){
                  this.toasterService.pop('error', 'Calendar name already present'); 
              }
              else{
                  this.toasterService.pop('success', ' Calendar saved successfully'); 
                    this.ngOnInit();
              }
          },
          (error)=>{
              this.auth.canActivate();
              designation = this.commonService.commonPostCall(requrl,createdData);
              designation.subscribe((data) => {
              checkName=data._body ;
                if(checkName=='Failure'){
                    this.toasterService.pop('error', 'Calendar name already present'); 
                }
                else{
                    this.toasterService.pop('success', 'Calendar saved successfully'); 
                      this.ngOnInit();
                } 
          },
          (error)=>{
              console.log("error");
          });
              
        });
      }
    }

    onEditConfirm(event): void {
      let idmaster = event.newData.idmaster;
      let name = event.newData.name;
      let description = event.newData.description;
      let status = event.newData.activeStatus;
      
      if(name == '' || description == ''|| status == ''){
        this.toasterService.pop('error', 'Fields Should not be empty');
      }else{
        let editedData = {
          "idmaster":idmaster,
          "name": name,
          "description": description,
          "activeStatus": status
        }
        let requrl= this.apiBaseUrl+'/ESS/api/Master/updateCalendar/';
        let designation = this.commonService.commonPostCall(requrl,editedData);
        designation.subscribe((data) => {
          this.ngOnInit();
          this.toasterService.pop('success', 'Calendar updated successfully');
        },
        (error)=>{
                this.auth.canActivate();
                let requrl= this.apiBaseUrl+'/ESS/api/Master/updateCalendar/';
                let designation = this.commonService.commonPostCall(requrl,editedData);
                designation = this.commonService.commonPostCall(requrl,editedData);
                designation.subscribe((data) => {
                  this.ngOnInit();
                  this.toasterService.pop('success', 'Calendar updated successfully');  
                },
                (error)=>{
                   console.log("error");
                });
            
        });
      }
    }

    searchCalendar(): void{
      let searchData = {
        "name":this.calendarName,
        "activeStatus": this.status
      }
      let requrl= this.apiBaseUrl+'/ESS/api/Master/searchCalendar/';
      let designation = this.commonService.commonPostCall(requrl,searchData);
      designation.subscribe((data) => {
        this.calendars = data.json();
      },
      (error)=>{
        this.auth.canActivate();
        designation = this.commonService.commonPostCall(requrl,searchData);
        designation.subscribe((data) => {
          this.calendars = data.json();
        },
        (error)=>{
            console.log("error");
        });
      });
    }

    reset(): void{
      this.calendarName = '';
      this.status = '';
      this.searchCalendar();
    }

    route123(event): void{
      let idmaster= event.data.idmaster;
      this._router.navigate(['/holiday', idmaster]);
    }
}
