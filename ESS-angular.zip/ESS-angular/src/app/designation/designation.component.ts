import { Component } from '@angular/core';
import { Router }  from '@angular/router';
import {ToasterContainerComponent, ToasterService, ToasterConfig} from 'angular2-toaster';
import { Http , Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';

import { AppComponent } from '../app.component';
import { CommonService } from '../common.service';
import { AppConfiguration } from '../app-config';
import { LoginService, User } from  '../login/login.service';
import { AuthGuard } from '../gaurds/auth-guard.service';

/**
 * <h1>designation.component.ts</h1>
 * @author Gobinath J
 */

@Component({
  selector: 'Designation-Master',
  templateUrl: './designation.component.html',
  styleUrls:  ['../attendance/attendancedetails.component.css']
})

export   class   DesignationMaster  {
    
    apiBaseUrl = AppConfiguration.apiBaseUrl;
    private toasterService: ToasterService;
    private designation;
    private settings;
    private designationName = '';
    private status = '';
    disabled: boolean = false;
    constructor(private auth: AuthGuard,private _http: Http, private _router: Router,private  loginService: LoginService, toasterService: ToasterService, private commonService: CommonService) {
        this.toasterService = toasterService;   
    }
    
    public toasterconfig : ToasterConfig = 
        new ToasterConfig({
            showCloseButton: true, 
            tapToDismiss: false,
            timeout: 0
    });

    ngOnInit() {

      this.settings = {
      mode: 'inline',
      actions: {
        add: true,
        edit:true,
        delete:false,
        //position: 'right'
        },
      pager : {
        display : true,
        perPage:10
      },
      edit: {
        confirmSave: true,
        editButtonContent: '<span class="btn btn-sm btn-primary glyphicon glyphicon-pencil"></span>',
        saveButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
    add: {
        confirmCreate: true,
        addButtonContent: '<span class="btn btn-sm btn-primary">Add</span>',
        createButtonContent: '<span class="btn btn-sm btn-success glyphicon glyphicon-ok"></span>',
        cancelButtonContent: '<span class="btn btn-sm btn-danger glyphicon glyphicon-remove"></span>'
      },
      columns: {
        idmaster:{
          title: 'Id',
          filter: false,
          show: false,
        },
        name: {
          title: 'Designation Name',
          filter: false,
          //show: false,
        },
        description: {
          title: 'Description',
          filter: false
        },
        activeStatus: {
          title: 'Status',
          filter: false,
        editor: {
          type: 'list',
          config: {
            list: [{ value: 'Active', title: 'Active' }, { value: 'Inactive', title: 'Inactive' }],
          },
        },
        }
      }
    };

      let requrl= this.apiBaseUrl+'/ESS/api/Master/getDesignationList/';
      let designationDetails = this.commonService.commonGetCall(requrl);
        designationDetails.subscribe((data) => {
            this.designation = data.json();
        },
        (error)=>{
                this.auth.canActivate();
                let dashboardDetails1 = this.commonService.commonGetCall(requrl);
                dashboardDetails1.subscribe((data) => {
                  this.designation = data.json();
                },
                (error)=>{
                });
            
        });
    }

    onCreateConfirm(event): void {
        if(this.disabled == false){
        let name = event.newData.name;
        let description = event.newData.description;
        let status = event.newData.activeStatus;
        if(name == '' || description == ''|| status == ''){
          this.toasterService.pop('error', 'Fields Should not be empty');
          this.disabled= true;
            setTimeout(() =>{
              this.disabled = false; 
                  }, 5000);
        }else{
          let createdData = {
            "name": name,
            "description": description,
            "activeStatus": status
          }
          let requrl= this.apiBaseUrl+'/ESS/api/Master/saveDesignation/';
          let designation = this.commonService.commonPostCall(requrl,createdData);
          let checkName;
          designation.subscribe((data) => {
              checkName=data._body ;
              if(checkName=='Failure'){
                  this.toasterService.pop('error', 'Designation already present'); 
                  this.disabled= true;
                  setTimeout(() =>{
                    this.disabled = false; 
                        }, 5000);
                  
              }
                else{
                    this.toasterService.pop('success', 'Designation saved successfully'); 
                     this.ngOnInit();
                }
          },
          (error)=>{
                  this.auth.canActivate();
                  designation = this.commonService.commonPostCall(requrl,createdData);
                  designation.subscribe((data) => {
                    checkName=data._body ;
                    if(checkName=='Failure'){
                        this.toasterService.pop('error', 'Designation already present'); 
                        this.disabled= true;
                        setTimeout(() =>{
                          this.disabled = false; 
                              }, 5000);
                    }
                      else{
                          this.toasterService.pop('success', 'Designation saved successfully'); 
                           this.ngOnInit();
                      }
                  },
                  (error)=>{
                       
                  });
              
          });
        }
    }
    }

    onEditConfirm(event): void { 
      if(this.disabled == false){
      let idmaster = event.newData.idmaster;
      let name = event.newData.name;
      let description = event.newData.description;
      let status = event.newData.activeStatus;
      
      if(name == '' || description == ''|| status == ''){
        this.toasterService.pop('error', 'Fields Should not be empty');
           this.disabled= true;
            setTimeout(() =>{
              this.disabled = false; 
                  }, 5000);
      }else{
        let editedData = {
          "idmaster":idmaster,
          "name": name,
          "description": description,
          "activeStatus": status
        }
        let requrl= this.apiBaseUrl+'/ESS/api/Master/updateDesignation/';
        let designation = this.commonService.commonPostCall(requrl,editedData);
        designation.subscribe((data) => {
          this.ngOnInit();
          this.toasterService.pop('success', 'Designation updated successfully');
           this.disabled= true;
            setTimeout(() =>{
              this.disabled = false; 
                  }, 5000);
        },
        (error)=>{
                this.auth.canActivate();
                designation = this.commonService.commonPostCall(requrl,editedData);
                designation.subscribe((data) => {
                  this.ngOnInit();
                  this.toasterService.pop('success', 'Designation updated successfully'); 
                   this.disabled= true; 
                  setTimeout(() =>{
                    this.disabled = false; 
                        }, 5000);
                },
                (error)=>{
                     
                });
             
        });
      }
    }
    }

    searchDesignation(): void{
      let searchData = {
        "name":this.designationName,
        "activeStatus": this.status
      }
      let requrl= this.apiBaseUrl+'/ESS/api/Master/searchDesignation/';
      let designation = this.commonService.commonPostCall(requrl,searchData);
      designation.subscribe((data) => {
        this.designation = data.json();
      },
      (error)=>{
              this.auth.canActivate();
              designation = this.commonService.commonPostCall(requrl,searchData);
              designation.subscribe((data) => {
                this.designation = data.json();
              },
              (error)=>{
                  
              });
          
      });
    }

    reset(): void{
      this.designationName = '';
      this.status = '';
      this.searchDesignation();
    }
}
