import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppService } from './app.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChildComponent } from './child/child.component';
import { RouterModule} from '@angular/router';
import { AppPipe } from './app.pipe';
import { AppDirective } from './app.directive'
import { LoginComponent } from './login/login.component';
import { Component } from '@angular/Core';

@NgModule({
  declarations: [
    AppComponent,
    ChildComponent,
    LoginComponent,
    AppPipe,
    AppDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
         {
            path: '',
            component: LoginComponent
         },
          {
            path: 'welcome',
            component: ChildComponent
          }
      ])
  ],
  providers: [AppService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [FormsModule, ReactiveFormsModule]
})
export class AppModule { }
