import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appBlockCutCopyPaste]'
})
export class AppDirective {

  constructor() { }

  @HostListener('paste', ['$event']) blockToPaste(e: KeyboardEvent) {
    e.preventDefault();
  }

  @HostListener('copy', ['$event']) blockToCopy(e: KeyboardEvent) {
    e.preventDefault();
  }

  @HostListener('cut', ['$event']) blockToCut(e: KeyboardEvent) {
    e.preventDefault();
  }

}
