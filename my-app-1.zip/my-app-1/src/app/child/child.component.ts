import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import { AppService } from '../app.service';
import { filter, map } from 'rxjs/operators';
import {Router} from "@angular/router";

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  public users: any;
  public wish: string = 'Morning';
  public collection: string[] = ['karthi', 'sathish', 'praba', 'praveen', 'mahesh', 'mani'];
   constructor(public appService: AppService, public router: Router) {
  }

  ngOnInit() {
    this.appService.getUsers().subscribe(res => {
      console.log(res)
      this.users = res;
    })
  }

  logout(){
    this.router.navigate(['']);
  }
}
