import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() parentCount: number;

  constructor() { }

  @Output()
 change: EventEmitter<number> = new EventEmitter<number>();
this.change.emit(11);

  ngOnInit() {
}
}
