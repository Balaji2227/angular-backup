import {Injectable} from '@angular/core';
import {  HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
@Injectable()
export class AppService {
      baseUrl = 'http://localhost:8080/login';
    constructor(public http:HttpClient){

    }



doLogin(user1){
    console.log('user',user1);
//   let headers = new Headers();
//   localStorage.setItem("userId", user.userId);
//   let queryParam = 'grant_type=password&username=' + user.userId + '&password=' + user.password;
//   headers.append('Authorization', 'Basic bXktdHJ1c3RlZC1jbGllbnQ6c2VjcmV0');
//   headers.append('Accept', 'application/json');
//   headers.append('Content-Type', 'application/x-www-form-urlencoded');
//   let options = new RequestOptions({ headers: headers });
//   return this.http.post(this.baseUrl, queryParam, options);
}
}