import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { DemoComponent } from './demo/demo.component';
import { ManualComponent } from './manual/manual.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {AppService} from './app.service';
const routes: Routes = [
  { path: 'manual', component: ManualComponent },
  { path: 'demo', component: DemoComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    DemoComponent,
    ManualComponent
    
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes) ,
    HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
  ],
   exports: [ RouterModule ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
