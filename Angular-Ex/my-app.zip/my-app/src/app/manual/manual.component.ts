
import { Component, OnInit, ViewChild,AfterViewInit } from '@angular/core';

import { Router } from '@angular/router';
import { DemoComponent } from '../demo/demo.component';

@Component({
  selector: 'app-manual',
  templateUrl: './manual.component.html',
  styleUrls: ['./manual.component.css']
})
export class ManualComponent implements AfterViewInit {
  @ViewChild(DemoComponent) demo;
  constructor() { }

  public parentMsg = "Success";
  
  public msg="";
  ngAfterViewInit(){
    let call = this.demo.message;
    console.log(this.demo.message);
    
  }
}
