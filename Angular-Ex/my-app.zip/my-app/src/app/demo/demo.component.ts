
import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';

import { AppComponent } from '../app.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
  ngOnInit() {
   }
  message = 'welcome to angular';

  @Input() childMsg;
  
  @Output() parentEvent = new EventEmitter();
public send(){
this.parentEvent.emit('Changep0nd');
}
}
