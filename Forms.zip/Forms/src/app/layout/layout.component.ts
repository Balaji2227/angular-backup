import { Component, SimpleChanges, Input } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent {

  @Input() message: string;

  // constructor() {
  //   console.log('constructorLog');
  // }

  // ngOnChanges(changes: SimpleChanges) {
  //   for (let propName in changes) {
  //     let change = changes[propName];
  //     let curVal = JSON.stringify(change.currentValue);
  //     let prevVal = JSON.stringify(change.previousValue);
  //     console.log('ngOnChangeLog ', `${propName}: currentValue = ${curVal}, previousValue = ${prevVal}`);
  //   }
  // }

  // ngOnInit() {
  //   console.log('ngOnInitLog');
  // }

  // ngDoCheck() {
  //   console.log('ngDoCheckLog');
  // }

  // ngAfterContentInit() {
  //   console.log('ngAfterContentInitLog');
  // }

  // ngAfterContentChecked() {
  //   console.log('ngAfterContentCheckedLog');
  // }

  // ngAfterViewInit() {
  //   console.log('ngAfterViewInitLog');
  // }

  // ngAfterViewChecked() {
  //   console.log('ngAfterViewCheckedLog');
  // }

  // ngOnDestroy() {
  //   console.log('ngOnDestroyLog');
  // }

}
