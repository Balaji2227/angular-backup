import { LayoutDirective } from './layout.directive';

describe('LayoutDirective', () => {
  it('should create an instance', () => {
    const directive = new LayoutDirective();
    expect(directive).toBeTruthy();
  });
});
