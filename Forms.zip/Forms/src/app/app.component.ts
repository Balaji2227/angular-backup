import { Component, SimpleChanges, Inject } from '@angular/core';
import { AppService } from './app.service';
import { UserService } from './user.service';
import { filter, map } from 'rxjs/operators';
import { inject } from '@angular/core/src/render3';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  public message: string;

  public items = [1,2,3];

  public currentDate = new Date();

  public value = 100;

  public users: any;

  public settings: any;

  constructor(@Inject(UserService)public appService: AppService, public userService: UserService) {
  }

  ngOnInit() {
    this.userService.getUsers().pipe(map(res => res.filter(res => res.username == 'Bret'))).subscribe(res => {
      console.log('res')
      this.users = res;
    })

    this.settings = {
      columns: {
        id: {
          title: 'ID',
          filter: false
        },
        name: {
          title: 'Full Name',
          filter: false
        },
        username: {
          title: 'User Name',
          filter: false
        },
        email: {
          title: 'Email',
          filter: false
        }
      }
    };
  }

}
