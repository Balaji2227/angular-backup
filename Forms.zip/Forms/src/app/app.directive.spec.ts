import { AppDirective } from './app.directive';

describe('AppDirective', () => {
  it('should create an instance', () => {
    const directive = new AppDirective();
    expect(directive).toBeTruthy();
  });
});
