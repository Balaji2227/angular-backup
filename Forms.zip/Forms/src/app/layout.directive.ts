import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appLayout]'
})
export class LayoutDirective {

  constructor(private viewContainer: ViewContainerRef,
    private templateRef: TemplateRef<any>) { }

  @Input() set appLayout(condition: boolean) {
    if (condition) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }

}
