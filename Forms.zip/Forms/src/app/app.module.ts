import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { UserModule } from './user/user.module'
import { LayoutModule } from './layout/layout.module';
import { AppDirective } from './app.directive';
import { LayoutDirective } from './layout.directive';
import { AppPipe } from './app.pipe';
import { AppService } from './app.service';
import { UserService } from './user.service';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';

@NgModule({
  declarations: [
    AppComponent,
    AppDirective,
    LayoutDirective,
    AppPipe,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    UserModule,
    LayoutModule,
    HttpClientModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [FormsModule, ReactiveFormsModule]
})
export class AppModule { }
