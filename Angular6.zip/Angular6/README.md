# Angular6Example

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.3.

Angular 8 just got released this May and here is the article for [Angular 8 CRUD example](https://www.devglan.com/angular/angular-8-crud-example).

